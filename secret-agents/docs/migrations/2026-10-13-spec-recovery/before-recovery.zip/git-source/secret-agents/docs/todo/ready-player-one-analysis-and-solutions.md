# Ready Player One: Problem Analysis & Proposed Solutions

**Date:** 2026-08-29  
**Analysis Context:** Skill targets multiple harnesses (Claude/Codex/Copilot) but exhibits Claude-first design patterns that cause Codex execution to fail or behave incorrectly.

---

## 1. The Problem Statement

The `ready-player-one` skill exists to validate that an environment is ready to execute expensive multi-step tasks before tokens are wasted. It detects the active harness, runs harness-specific preflight checks, and outputs either `ready` or a numbered remediation list.

**The Problem:** The skill is "balking on Codex" because key portions of its logic assume Claude as the primary/default harness, causing:
- Codex-specific checks to fail or produce incorrect guidance
- Model detection logic that doesn't reliably identify Codex harness environment
- A structure that feels like Codex support was bolted on after Claude was feature-complete

---

## 2. Root Causes (Specific Code Locations)

### 2.1 Model Detection & Recommendation (Lines 75–99)

**The Issue:** The model recommendation table (lines 82–85) is **correct** but the context around it reveals the underlying problem:

```
| **claude** | `claude-haiku-4-5` | mechanical checklist — no reasoning needed |
| **codex** | `o4-mini` | mechanical checklist — no reasoning needed |
```

However:
- **Lines 75–77:** The skill says "only report model if harness exposes trustworthy session model string. Do not guess." But:
  - Claude's `CLAUDE_CODE_SESSION_ID` env var *does* exist in Claude sessions
  - Codex may not expose an equally reliable model-identification signal
  - The fallback to `unknown` was designed with Claude in mind; the recommendation table then feels disconnected

- **Line 26 (harness detection):** Claude detection is tried **first** in the list (`CLAUDE_CODE_SESSION_ID`), making it the happy path. Codex comes second, but the detection logic doesn't have symmetrical weight — if a Codex user has *any* Claude signal (e.g., a leftover `.claude/` directory from a prior project), Claude wins.

### 2.2 Check 1 — Skill Visibility (Lines 103–139)

**The Structure Issue:**
- Lines 108–119: Claude fix is 6 lines of prose + clear table
- Lines 120–129: Codex fix is 5 lines of prose + table
- Lines 131–138: Copilot is a **placeholder** ("still unknown")

**Why It Breaks on Codex:**
- The Codex registration paths assume `~/.agents/skills/` or `~/.codex/skills/` but there's no validation that these paths are actually where the harness looks
- The prose says "verify ... is present" but doesn't tell Codex *which* primary path to check first (the operator has to try both)
- The link/symlink requirement is mentioned but not clearly distinguished from file-copy alternatives

### 2.3 Check 2 — Execution Trust (Lines 147–280)

**The Design Flaw:**
This check is genuinely harness-specific and structured well *within each branch*, but:
- **Lines 157–206:** Claude check reads `.claude/settings.json` (project and global) — straightforward
- **Lines 214–256:** Codex check reads `~/.codex/config.toml` — more complex (TOML parsing, case-folding, project path matching)
  - The Linux/Mac fallback uses Python's `tomllib` (3.11+), but doesn't handle Python < 3.11 or missing `tomllib`
  - The Windows PowerShell regex is intricate and fragile (regex escaping of file paths)
  - **Most critically:** The "Pass" condition (line 259) is correct, but the check doesn't explain what "trusted" means in Codex or how trust relates to approval prompts — it leaps to "add to config.toml" without context

- **Lines 279:** The skip template for Copilot is a placeholder

### 2.4 Check 3 — uv Health (Lines 284–348)

**Why It Breaks:** This check is **harness-agnostic** (all OSes, all harnesses), but:
- **Lines 294, 299:** The command is identical across both PowerShell and bash (`uv run python -c "print('uv ok')"`)
- **Line 314:** Derive project exe from directory name — this is a **heuristic** that breaks if:
  - The project is in a non-standard location (not `/c/git/projectname`)
  - The executable has a different name than the folder
  - No override mechanism is provided in the skill itself
- **Lines 318–327:** The lock-detection logic is project-name-based and fragile on Windows (process names can have version suffixes, be case-sensitive, etc.)

---

## 3. Why This Matters for the Harness Profiles Goal

The `ready-player-one` skill is a **concrete example of the sprawl problem** documented in [`harness-profiles-and-adapter-discussion.md`](harness-profiles-and-adapter-discussion.md):

- **Harness-specific knowledge scattered:** Each check has inline `if claude / if codex` branching, which is exactly what the HarnessProfile registry is designed to prevent.
- **Maintenance sprawl:** Adding Copilot support requires editing 4+ sections (model detection, Check 1, Check 2, output templates), each with its own prose/table/code.
- **No single source of truth:** Where should the "Codex looks for skills at `~/.codex/skills`" fact live? Currently it's embedded in Check 1 prose. If that path changes, the skill prose needs updating. A `HarnessProfile` registry (with a `skill_registration_paths` facet) would centralize it.

---

## 4. Proposed Solutions

### Solution A: Refactor with HarnessProfile (Recommended Long-term)

**Goal:** Move all per-harness facts into a `HarnessProfile`-based registry; skill script becomes harness-agnostic.

**Changes:**

1. **Extend `HarnessProfile` in `harness_profiles.py`:**
   ```python
   @dataclass(frozen=True)
   class HarnessProfile:
       projections: tuple[_ProjectionSpec, ...]
       model_id: str  # e.g., "claude-haiku-4-5" or "o4-mini"
       skill_registration_paths: tuple[str, ...]  # OS-expanded at resolution time
       config_path: str  # path to harness config file (e.g., ~/.claude/settings.json)
       trust_setting_key: str  # key path in config to check for trust (e.g., "permissions.defaultMode")
   ```

2. **Create projection-time substitution for skill prose:**
   - When projecting to Codex, substitute `{{RECOMMENDED_MODEL}}` in SKILL.md bodies with `o4-mini`
   - Substitute registration paths based on the harness profile
   - This moves the branching from *runtime* (the skill script) to *projection time* (the harness setup layer)

3. **Refactor the skill script to be harness-agnostic:**
   - Remove all `if claude / if codex` branches
   - Consume values from resolved projections or a harness-profile accessor
   - Example Check 2 becomes: `read_config($HARNESS_CONFIG_PATH); check_key_exists($TRUST_SETTING_KEY, "trusted")`

4. **Add Copilot profile data once it's known** (no code churn, just a new profile entry)

**Trade-offs:**
- **Pros:** Single skill source for all harnesses; easier to add Copilot; maintenance centralizes in one place
- **Cons:** Requires bigger refactor of projection layer; temporal dependency: content resolution must happen at projection time, not runtime

**Effort:** Medium (2-3 days of design + implementation)

---

### Solution B: Improve Codex Paths & Validation (Short-term / Incremental)

**Goal:** Fix Codex-specific issues without refactoring the core structure; make the skill more robust immediately.

**Changes:**

1. **Check 0c — Model Detection:**
   - Add explicit fallback order for Codex: check `CODEX_ACTIVE_MODEL` env var (if that exists), then check `~/.codex/config.toml` for a default, then report `unknown`
   - Clarify in prose: "If your exact model ID is not available, this check reports `unknown` — that's expected."

2. **Check 1 — Skill Visibility (Codex):**
   - Add sub-checks: try each registration path in order, report which one worked or which should be tried first
   - Expand the Codex fix to include both "file copy" and "symlink" examples, with a note on which is preferred

3. **Check 2 — Execution Trust (Codex):**
   - Harden the TOML parsing:
     - Python 3.11+: use `tomllib`
     - Python < 3.11: fall back to a simpler regex-based check or warn "Python 3.11+ required to verify trust"
   - Fix the PowerShell regex to handle backslashes correctly (test the regex against real paths first)
   - Add a line of context: "In Codex, 'trusted' means the harness will auto-approve tool calls. Without it, you'll be prompted repeatedly."

4. **Check 3 — uv Health (All):**
   - Add an override mechanism: if the project's root has a `.readyrc` or environment variable override, use it instead of deriving from directory name
   - Improve lock-detection robustness on Windows: use `Get-Process` with exact name matching, not wildcards

5. **Overall:** Add a "harness detection confidence" score in the summary — if Codex detection is uncertain (e.g., mixed signals), warn the user to verify manually

**Trade-offs:**
- **Pros:** Smaller, testable changes; no architectural refactor; ships immediately
- **Cons:** Doesn't solve the root sprawl problem; Copilot support still requires repeating the pattern; leaves technical debt

**Effort:** Low (2-3 hours)

---

### Solution C: Hybrid (Recommended Near-term)

**Approach:** Do Solution B (fix Codex robustness immediately), then design the projection-time content-resolution mechanism (identified as an open question in harness-profiles doc), then gradually migrate to Solution A.

**Phases:**

1. **Phase 1 (this week):** Land Solution B fixes. Codex stops failing on common cases; all checks work.
2. **Phase 2 (planning):** Design content-resolution syntax and integration with the projection layer. Settle whether `{{VARIABLE}}` / `{{ Variable }}` / YAML frontmatter / JSON includes are used.
3. **Phase 3 (after harness-profile migration):** Migrate `ready-player-one` to use resolved projections. Model detection, registration paths, config keys all come from the profile.

**Trade-offs:**
- **Pros:** Immediate relief for Codex users; doesn't block other harness-profile work; Solution B changes are preserved and become template examples for other skills' future migrations
- **Cons:** Temporary technical debt; requires a third refactor eventually (Solution B → Solution A)

**Effort:** Low (Phase 1) + Medium (Phase 2–3)

---

## 5. Recommended Path Forward

1. **Immediate (today):** Implement Solution B (Codex robustness fixes). The goal is "Codex doesn't break anymore."
2. **Design phase:** Use the brainstorming skill to settle the content-resolution mechanism identified in open questions (step 7 of harness-profiles doc). This unblocks Solution A.
3. **Migration phase:** After content-resolution is designed, migrate `ready-player-one` first as a proof-of-concept for the pattern. It's a self-contained skill; success here validates the design before migrating larger skills.

---

## 6. Implementation Checklist (for Solution B)

- [ ] Add `CODEX_ACTIVE_MODEL` detection to Check 0c
- [ ] Harden TOML parsing in Check 2 (Codex) with Python version checks
- [ ] Fix PowerShell regex in Check 2 (Codex); test against real paths
- [ ] Expand Codex skill visibility fix with both copy and symlink examples
- [ ] Add context to "trust" setting in Check 2 prose
- [ ] Add override mechanism to Check 3 (`.readyrc` or env var for project exe name)
- [ ] Improve lock-detection logic on Windows (exact matching, not wildcards)
- [ ] Add "harness detection confidence" indicator to summary
- [ ] Test on Codex with at least one real scenario (skill running, checking permissions, etc.)
- [ ] Update SKILL.md to note that Copilot checks remain placeholders

---

## Appendix: Long-Term Vision

Once the HarnessProfile registry and content-resolution layer are in place, `ready-player-one` becomes:

```
# Ready Player One

Runs preflight environment checks for batched prompts and expensive tasks.

## How to run
/ready-player-one

## What it checks
- Skill is visible in the active harness
- Permissions/trust allow autonomous execution
- Build environment (uv, no locked executables) is ready

## Output
"ready" or a remediation list (OS/harness specific)
```

All harness-specific prose disappears; it's replaced by references to resolved values. The script reads from environment at runtime or from a projection-time substitution pass. Adding Copilot is a single profile entry + data, not a code change.

This is the state the harness-profiles initiative is working toward.
