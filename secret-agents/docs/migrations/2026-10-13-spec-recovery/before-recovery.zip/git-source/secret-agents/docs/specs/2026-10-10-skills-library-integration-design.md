# Skills Library Integration and Fast Catalog Design

**Date:** 2026-10-10. **Status:** approved conversational design; awaiting written-spec review.

## Product requirement

Merge the skills in `C:\git\worky\worky\Agent\skills` into
`secret-agents/skills` without losing useful behavior. Unify duplicate workflows,
prune unnecessary instruction load, give every canonical workflow a directly
invokable short name, and provide a categorized skills table of contents that is
fast to query and cannot silently drift from the library.

Success means:

- every useful source and target capability has one canonical implementation;
- old skill names remain directly invokable when they represent retained behavior;
- every canonical skill has a category, preferred shorthand, and updated date;
- preferred shorthands are unique, begin with their category prefix, and contain at
  least one initial for every word in the canonical skill name;
- `/qas` normally reads no `SKILL.md` bodies and returns the categorized TOC;
- an added, edited, or removed skill cannot cause `/qas` to print a known-stale TOC;
- `install-skills --update` refreshes the same catalog before syncing skill links;
- deterministic validation catches catalog, metadata, and alias drift in CI.

Vocabulary from the repository-root `CONTEXT.md` applies. The target agent root is
`secret-agents/`; canonical skills remain direct children of `secret-agents/skills`.

## Decisions and rejected alternatives

### Incremental catalog with a correctness check

Use a tracked catalog plus a machine-local stat cache. Each query lists immediate
skill directories and checks `SKILL.md` size and nanosecond modification time. It
reads only new or changed files, reusing tracked records for unchanged skills.

Rejected alternatives:

- **Update-only static TOC:** fastest query, but a manual edit can silently leave the
  TOC stale.
- **Parse every skill on every query:** correct but needlessly reads every skill body.
- **A manually touched global stamp:** fast but cannot detect edits that forget to
  touch the stamp, so it cannot uphold the freshness contract.
- **No validation at query time:** zero work and guaranteed eventual drift are the
  same choice; the requirement favors the smallest reliable check.

The direct-child listing and stat calls are the minimum dependable freshness cost.
No recursive resource scan occurs on the fast path.

### Generated, directly invokable aliases

Every canonical workflow declares one preferred shorthand. A deterministic updater
creates a minimal skill directory for each preferred shorthand and compatibility
alias. Alias skills forward arguments and behavior to the canonical skill; they do
not repeat its workflow.

Rejected alternatives:

- **Display-only aliases:** fail the directly-invokable requirement.
- **Hand-authored alias bodies:** duplicate behavior and drift from canonical skills.
- **Directory symlinks as aliases:** expose the canonical frontmatter name beneath a
  different directory, violating name/directory validation and confusing discovery.
- **One router command requiring an alias argument:** saves directories but prevents
  direct `/alias` invocation.

Generated aliases are adapters, not canonical workflows, and therefore do not
recursively require their own shorthands.

### One catalog owner

One Python 3.11+ standard-library program owns discovery, metadata validation,
incremental refresh, date maintenance, alias generation, catalog serialization, and
TOC rendering. `query-all-skills`, `qas`, `update-skills-readme`, and
`install-skills --update` invoke that program rather than implementing variants.

Rejected alternatives:

- **Separate query and installer indexes:** two sources of truth.
- **Model-authored TOC refreshes:** slow, nondeterministic, and expensive.
- **Adding the feature to the rejected transactional installer architecture:** binds
  a small indexing concern to receipts, uninstall, backups, and planning machinery
  that the current repository design has already rejected.

### Create-only installation semantics

The imported `install-skills` capability will follow the target repository's link
model: canonical content stays in the agent root, foreign packs coexist in real
mixing directories, and updates create missing per-skill links without overwriting
conflicts.

The source skill's hard-coded Mac path, copy-overwrite behavior, and whole-directory
replacement are discarded. These are unsafe or incompatible with the target's
multi-machine, multi-harness design and provide no desired unique functionality.

### Preserve dirty work and existing approved direction

Existing uncommitted edits to `AGENTS.md`, `README.md`, `README.html`, and
`python-quality-gate/SKILL.md` are user work. Integration must preserve their
semantics and may touch those files only through a deliberate merge.

`ready-player-one` remains the canonical preflight in accordance with its approved
rewrite. The new direct-alias requirement supersedes only the earlier decision to
delete `agent-preflight`: it becomes a generated compatibility alias rather than a
second implementation.

## Canonical library

The merged library has 19 canonical workflows:

| Category | Display name | Canonical name | Preferred shorthand |
|---|---|---|---|
| Agent Workflow | Agent Plan | `agent-plan` | `ap` |
| Code Quality | Clean Code Architecture Guards | `clean-code-architecture-guards` | `ccag` |
| Code Quality | Clean Code Error Handling | `clean-code-error-handling` | `cceh` |
| Code Quality | Python Quality Gate | `python-quality-gate` | `cpqg` |
| Jira | Human Jira Ticket Creation | `jira-human-ticket-create` | `jhtc` |
| Maintenance | Claude Pricing Update | `update-claude-pricing-doc` | `mucpd` |
| Maintenance | Model Routing Update | `update-model-routing` | `mumr` |
| Preflight | Ready Player One — Agent Preflight | `ready-player-one` | `prpo` |
| Query & Discovery | Query All Skills | `query-all-skills` | `qas` |
| Reporting | Work Receipt | `report-receipt` | `rrec` |
| Reporting | Report Rollup | `report-rollup` | `rrol` |
| Reporting | Status Report | `report-status` | `rs` |
| Skill Management | Install Skills | `install-skills` | `sis` |
| Skill Management | Update Skills README | `update-skills-readme` | `susr` |
| Testing | Python TDD Cycle | `python-tdd-cycle` | `tptc` |
| Testing | Mac Coverage | `run-mac-coverage` | `trmc` |
| Testing | Run Unit Tests | `run-unit-tests` | `trut` |
| Unreal | Unreal Build Environment Reset | `unreal-reset-build-env` | `urbe` |
| Unreal | Unreal UGS PCB Release | `unreal-ugs-release` | `uur` |

The category prefixes are `a`, `c`, `j`, `m`, `p`, `q`, `r`, `s`, `t`, and `u`.
They are unique, so no multi-character category disambiguator is currently needed.
If a future category shares an initial, the new category receives the shortest unused
case-insensitive prefix; existing category prefixes and aliases remain reserved unless
the user explicitly approves a breaking migration.

Preferred shorthand derivation is stable and mnemonic:

1. Take at least the first character of every hyphen-separated canonical-name word,
   in order: `jira-human-ticket-create` becomes `jhtc`, leaving
   `jira-agent-ticket-create` available as `jatc`.
2. If those initials do not start with the category prefix, prepend it:
   `python-quality-gate` in Code Quality becomes `cpqg`.
3. If the result is already reserved, extend the word abbreviation that best
   distinguishes the colliding names without removing or reordering any initials.
   The current `report-receipt` / `report-rollup` collision therefore uses `rrec`
   and `rrol`.

Adding a skill never silently renames an existing shorthand. The new skill extends
its own derived alias until unique.

## Compatibility aliases

The following old names remain directly invokable and forward to a canonical skill:

| Compatibility alias | Canonical skill |
|---|---|
| `agent-preflight` | `ready-player-one` |
| `architecture-guards` | `clean-code-architecture-guards` |
| `jira-ht` | `jira-human-ticket-create` |
| `reset-unreal-build-environment` | `unreal-reset-build-env` |
| `rut` | `run-unit-tests` |
| `status-report-create` | `report-status` |
| `ugs-pcb-release` | `unreal-ugs-release` |
| `work-receipt-create` | `report-receipt` |

Compatibility aliases appear only in a secondary note in the TOC. The parenthesized
name after each display name is always the preferred category-aligned shorthand.

## Skill header contract

Every canonical `SKILL.md` keeps standard `name` and `description` frontmatter and
places one parseable human header immediately after its H1:

```markdown
# Run Unit Tests

**Category:** Testing · **Short:** trut · **Updated:** 2026-10-10 · **Aliases:** rut
```

`Aliases` is omitted when empty. This line is the only source of category,
preferred shorthand, compatibility names, and updated date. It remains body content
so frontmatter stays portable and limited to discovery fields.

Generated alias skills carry a visibly generated header naming their category,
canonical skill, and generation date. A machine-readable marker authorizes the
updater to replace or remove that alias. A directory without the marker is
human-owned and never overwritten or deleted.

The canonical H1 supplies the display name. The frontmatter description supplies the
one-line TOC description after being checked for reasonable length and a useful
trigger condition.

## Components and state ownership

### Catalog updater

One `SkillCatalog` application owns:

- the canonical skills root;
- parsing and validating canonical headers;
- classifying canonical and generated-alias directories;
- comparing local stat signatures with cached signatures;
- computing normalized SHA-256 content hashes;
- updating changed skills' dates;
- deriving alias documents;
- producing immutable catalog records;
- atomically writing generated artifacts.

Its command surface is:

```text
show      Refresh only if drift is detected, then print TOC.md
update    Force a complete validation and refresh
check     Detect drift without changing files; nonzero on any mismatch
```

The implementation lives with `query-all-skills`, which owns catalog querying.
Other skills invoke its command-line contract and do not import its internals. This
keeps one implementation without requiring cross-skill Python imports.

### Tracked catalog

`skills/catalog.json` stores only portable semantic state:

- schema version;
- generated date;
- ordered category records and prefixes;
- canonical name, display name, description, category, preferred shorthand,
  compatibility aliases, updated date, normalized semantic hash, and exact file
  hash;
- generated alias-to-canonical mapping.

It contains no absolute paths, filesystem timestamps, or machine identity.

### Local stat cache

`~/.agents/cache/secret-agents-skill-catalog.json` stores:

- the resolved agent-root identity;
- catalog schema version;
- for each observed `SKILL.md`, relative path, size, and `mtime_ns`;
- the tracked catalog hash used for that observation.

The cache is expendable. Missing, malformed, mismatched-root, or stale-schema cache
data triggers one full refresh and replacement; it never makes the command fail.

### Generated TOC

`skills/TOC.md` is sorted by declared category order, then display name. Its compact
shape is:

```markdown
# Skills

Generated 2026-10-10. Run `/<short>` or `/<canonical-name>`.

## Testing (t)

- Run Unit Tests (`trut`) — Run a Python project's unit and pre-commit checks.
```

Compatibility aliases are listed once beneath their canonical entry when present.
Generated alias skills never receive independent TOC entries.

### Installer integration

`install-skills --update` executes catalog `update` before link reconciliation. If
catalog update fails, installation does not begin. Link reconciliation uses the
repository's create-only per-skill policy: validate all destinations first, preserve
foreign entries, leave correct links unchanged, and refuse conflicts before creating
new links.

The lean skill retains the useful source selection surface while replacing copy
semantics:

```text
install-skills [--all | <canonical-or-alias> ...] [--update]
               [--harness claude|codex|copilot|all | --target <directory>]
               [--help]
```

- no names or `--all`: reconcile every canonical and generated alias skill;
- named skills: resolve aliases to canonical workflows and include their generated
  aliases so either invocation remains available;
- `--harness`: use the repository's harness layouts; default `all` preserves the
  existing target CLI convention;
- `--target`: use one explicit mixing directory instead of harness layouts and link
  skills individually;
- `--update`: force catalog regeneration before resolving the install set;
- every mode is idempotent and create-only; removal and pruning remain out of scope.

`--target` and `--harness` are mutually exclusive. Relative targets resolve from the
current repository root. Missing named skills are invalid input and prevent all
mutation rather than allowing a partial install.

No catalog code owns harness paths or link creation. No installer code parses skill
metadata beyond consuming the validated catalog. This keeps catalog truth and
installation state under separate owners.

## Refresh algorithm

`show` performs these steps:

1. Read the small local stat cache and tracked `catalog.json`.
2. List direct children of the skills root and locate each direct `SKILL.md`.
3. Reject non-generated skill directories missing `SKILL.md`; ignore documented
   non-skill files such as README and TOC documents.
4. Compare directory names plus each skill file's size and `mtime_ns` with the cache.
5. If signatures and the tracked catalog hash match, print `TOC.md` immediately.
6. Otherwise read new or changed files and reuse unchanged records from
   `catalog.json`.
7. Compute a semantic hash that excludes only the mutable `Updated` value. If a
   canonical skill's semantic hash changed, replace its updated date with today's
   local date. Then compute the exact file hash used for drift detection. A
   timestamp-only filesystem change leaves the date and both tracked hashes
   unchanged.
8. Validate the complete logical catalog before any generated write.
9. Render every expected generated alias in memory. Refuse collisions with
   human-owned directories.
10. Prepare all temporary files before replacement. Replace changed canonical date
    lines and generated aliases first, then publish `catalog.json` and `TOC.md` last.
    Remove obsolete alias directories only when their generated marker is valid and
    they contain no unexpected files.
11. Write the expendable local stat cache last.
12. Print the current TOC.

`update` follows the same algorithm but reads and validates every canonical skill.
`check` follows the full-read path, renders expected outputs in memory, and reports
every difference without mutation.

## Validation and failure behavior

Validation fails on:

- an empty canonical scan;
- missing or malformed standard frontmatter;
- folder/frontmatter name mismatch;
- missing, misplaced, or malformed skill header;
- unknown category;
- invalid date;
- duplicate canonical names, preferred shorthands, or aliases;
- a preferred shorthand that does not begin with its category prefix or omits the
  ordered initial of any canonical-name word;
- an alias equal to a canonical name;
- alias cycles or chains rather than direct canonical forwarding;
- generated alias drift or collision with human content;
- a stale or nondeterministic catalog/TOC render under `check`.

Expected input problems produce one contextual diagnostic and a nonzero exit code.
Programmer invariants fail fast. Validation failure performs no generated writes. An
I/O failure during publication may leave some generated sources refreshed, but the
catalog and TOC publish last and the local cache is not written; the next invocation
therefore detects and repairs or reports the incomplete refresh. `/qas` does not print
the previous TOC after detecting drift it could not safely resolve; it prints the
failure and remediation instead.

Obsolete generated aliases are recoverable Git changes. The updater never removes a
human-owned directory, unknown file, canonical skill, or foreign pack.

## Skill merge and pruning rules

For each canonical workflow:

1. Treat the source and target files as behavior specifications, not text to
   concatenate.
2. Inventory triggers, arguments, safety constraints, outputs, failure behavior,
   platform branches, and reusable resources.
3. Keep the union of useful behaviors and the stricter compatible safety rule.
4. Resolve contradictions against the approved target architecture and record any
   discarded source behavior in the implementation plan.
5. Remove stale absolute paths, duplicated procedures, narrative history, repeated
   examples, and explanations that do not change agent behavior.
6. Keep core ordered actions in `SKILL.md`; move only branch-specific heavy reference
   behind an explicit pointer.
7. Prefer deterministic scripts for repeated parsing, generation, or validation.
8. Preserve user-authored dirty changes by merging their intent rather than replacing
   files wholesale.

The useful-behavior inventory is an acceptance checklist for each merge. Word count
is a diagnostic, not a quota: a shorter skill is accepted only when its checklist is
still satisfied.

## Tests and acceptance criteria

### Catalog unit tests

Cover:

- metadata parsing and precise malformed-header diagnostics;
- cold cache, cache hit, cache corruption, and schema change;
- proof that an unchanged `show` reads no `SKILL.md` body;
- proof that a one-skill edit reads only that skill plus generated outputs;
- new, edited, removed, and timestamp-only cases;
- normalized hash and automatic date bump behavior;
- deterministic category and entry ordering;
- preferred alias prefix, uniqueness, and reserved-name validation;
- generated alias creation, forwarding, regeneration, and safe retirement;
- refusal to replace a human-owned alias collision;
- atomic failure behavior;
- empty-scan failure.

### Repository drift guard

A test invokes catalog `check` against the real `skills` directory. It fails if any
canonical header, preferred alias, generated alias, `catalog.json`, or `TOC.md` is
missing or stale. The test also fails if it scans zero canonical skills.

### Merge verification

Each canonical skill receives a behavior checklist derived from both originals.
Verification confirms every accepted behavior remains represented and every rejected
behavior matches a recorded architectural decision. Exact-name overlaps receive an
explicit two-input comparison; semantic renames receive the same comparison before
the old name becomes an alias.

### Integration tests

Cover:

- `/qas`-equivalent output from a cold and warm cache;
- `install-skills --update` refreshing the catalog before link reconciliation;
- catalog failure preventing any link mutation;
- new generated aliases becoming install candidates;
- correct links remaining unchanged and conflicts blocking before mutation.

### Final gate

Run the repository-documented Python gate in order and require every command to pass.
Run the existing README renderer/guard after merging its current dirty changes and
teach it to treat generated aliases as inline aliases, not independent canonical
documentation sections.

## Performance target

On the current library size, a warm `/qas` invocation must:

- perform no recursive directory walk;
- read no canonical `SKILL.md` body;
- read only the local stat cache, `catalog.json`, and `TOC.md` plus file metadata;
- complete within 100 ms on the reference Windows checkout after Python startup is
  excluded, measured over at least ten runs with the median reported.

The time bound is a regression tripwire, not a promise for network filesystems.
Correctness takes precedence: detected drift uses the slower incremental refresh.

## Scope boundaries

Included:

- merge and optimization of the 19 canonical workflows;
- generated preferred and compatibility aliases;
- categorized TOC, tracked catalog, local cache, and drift guard;
- `qas`, query, README-update, and installer-update integration;
- preservation of existing dirty work;
- compatibility with the approved `ready-player-one` direction.

Excluded:

- vendoring foreign skill packs;
- live network update checks;
- redesigning the entire rejected receipt/backup/uninstall installer;
- deleting unrelated historical code solely because the new catalog does not use it;
- changing harness discovery paths outside the existing runbook and approved
  preflight design;
- rewriting non-skill repository documentation except where generated inventory
  validation requires it.

## Implementation order

1. Build the catalog updater test-first against temporary skill trees.
2. Add canonical metadata and generate aliases/catalog/TOC.
3. Merge and prune exact-name overlaps, then semantic renames, then source-only
   skills; validate after each canonical workflow.
4. Wire `query-all-skills`, `qas`, `update-skills-readme`, and
   `install-skills --update` to the catalog contract.
5. Reconcile README validation without discarding the current dirty edits.
6. Run catalog drift checks, integration tests, the full repository suite, and the
   Python quality gate.
