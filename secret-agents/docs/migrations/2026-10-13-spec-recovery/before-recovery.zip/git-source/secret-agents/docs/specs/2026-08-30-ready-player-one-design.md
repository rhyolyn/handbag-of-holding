# ready-player-one: Preflight Design

**Date:** 2026-08-30. **Status:** approved design, not yet implemented.
**Product requirement:** before an expensive batched prompt runs, prove in one invocation that every skill the user relies on is loaded, the harness will not stop for permission, and the environment is wired — or fix what is safely fixable and list exactly what remains. Binary verdict: `ready` or `NOT READY`.

Vocabulary used here is defined in the repo-root [CONTEXT.md](../../../CONTEXT.md). Per-machine wiring steps live in the [harness-setup runbook](../../runbooks/harness-setup/harness-setup.md).

## Decisions (with rejected alternatives)

1. **One self-contained skill named `ready-player-one`.** The `agent-preflight` skill and the wrapper that file-reads it are deleted. *Rejected:* wrapper + real skill — a relative-path read (`..\agent-preflight\SKILL.md`) breaks under per-skill linking, and the deployed copy had already collapsed the pair anyway.
2. **The vault is `handbag-of-holding`** — public GitHub repo and Obsidian vault, synced to all six machines by Obsidian, pushed to GitHub from one designated machine. Agent root stays `secret-agents/`. *Rejected:* keeping `worky\Agent` — entangled with a personal vault that can never be shared; archived by the user, no tooling references it.
3. **The vault contains only the user's own skills.** Foreign packs (superpowers, mattpocock-skills, future packs) are installed per-machine through each pack's official mechanism and are never present as files in the vault. *Rejected:* vendored copies — unversioned, indistinguishable from own skills, and how the original write-through mess happened.
4. **Per-machine pointer file `~/.agents/root`** (one line: absolute path of the vault) is the only per-machine configuration; every path derives from it. *Rejected:* moving the vault to a uniform path on all machines — six-machine churn that still can't unify drive-letter preferences.
5. **Mixing directories are real directories with per-skill links — never whole-directory junctions.** A whole-dir junction from a harness path into the vault turns every third-party installer into a vault writer (the write-through trap). Exception: Claude's `~/.claude/skills` may remain a whole-dir junction *only because* Claude foreign content arrives via its plugin system, not via file installs. Tripwire: the vault-purity check below; if a future pack has no Claude plugin route, convert the junction to a real dir with per-skill links before installing it.
6. **ready-player-one is offline.** It never touches the network. Freshness data comes from a local version cache written by the companion skill `update-agent-stack`. *Rejected:* live update checks in the preflight — slow, network-dependent, and the user explicitly split update into its own skill.
7. **Autofix what is safely fixable** (create-only links, additive settings keys, writing the pointer file after confirming the path). Everything else — anything requiring network, elevation, overwriting existing content, or a session restart — is a remediation line with the exact command. *Rejected:* report-only (costs the user a round-trip per fix) and aggressive fixing (violates the never-displace-user-content rule).
8. **One implementation: a single Python 3 stdlib script.** Fleet is 2 Windows / 3 macOS / 1 Linux; paired ps1+bash means every fix written twice. The script lives in the skill directory so Obsidian syncs it. *Rejected:* the `secret_agents_setup` installer CLI as the fixer — that project is retired; salvage only its cross-platform link know-how (`links.py`, its tests) where lifting a piece does not import its architecture.
9. **Checks dropped by user decision:** active-model check, git status/branch sanity, network freshness. The uv check survives only conditionally (see Check 7).

## The manifest

`secret-agents/packs.json` — synced by the vault, read by both skills. Declares what "all skills ready" means so the check is a diff, not a vibe. Adding a future pack is one entry.

```json
{
  "mine": { "source": "vault-skills-dir", "expect": "*" },
  "superpowers": {
    "install": {
      "claude":  "plugin: /plugin install superpowers (claude-plugins-official)",
      "codex":   "plugin: /plugins -> search superpowers -> install",
      "copilot": "plugin: copilot plugin install superpowers@superpowers-marketplace"
    },
    "expect": ["brainstorming", "writing-plans", "systematic-debugging", "..."]
  },
  "mattpocock-skills": {
    "install": {
      "claude":  "plugin: /plugin install mattpocock-skills",
      "codex":   "npx skills@latest add mattpocock/skills",
      "copilot": "npx skills@latest add mattpocock/skills"
    },
    "expect": ["grilling", "grill-with-docs", "domain-modeling", "wizard", "research",
               "claude-handoff", "loop-me", "retro", "writing-beats", "..."]
  }
}
```

`expect` lists are explicit for foreign packs because the user relies on skills from the pack's `in-progress` and `misc` categories; if an official install bundles only stable categories, the diff catches the gap. `"*"` for `mine` means every child directory of `<vault>/secret-agents/skills`. Exact install-spec encoding is an implementation choice; the shape above is the contract.

## Checks, in order

Each check prints one result line (`✅` / `❌` / `⏭️ skipped` / `⚠️ warning`); autofixes print what they did. Summary is `ready` only if no `❌` remains after autofix.

| # | Check | Autofix? |
|---|-------|----------|
| 0 | Detect harness + OS; read pointer file | Missing pointer file: confirm vault path with user, write it |
| 1 | Vault reachable; **vault purity** — every dir in `<vault>/secret-agents/skills` belongs to `mine` | No — a foreign dir in the vault is a write-through incident; name the offender, never auto-delete |
| 2 | Link layout for the active harness matches the runbook table (guidance links + skills links, per-skill in mixing dirs) | Yes — create missing links (create-only); an existing wrong entry is a named conflict, not overwritten |
| 3 | Foreign packs installed per manifest for the active harness (plugin registries, `npx skills` state) | No — remediation prints the exact official install command (installs need network; preflight is offline) |
| 4 | **Session skills diff** (model-performed, not script): expected skill names vs the session-visible list | Partial — read each missing SKILL.md directly into context so it works *this* session; advise a fresh session to register it properly |
| 5 | Permission/trust: Claude global `defaultMode` must be `bypassPermissions` — `dontAsk` is not enough; a partial allow list in `~/.claude/settings.json` can still trigger prompts even with `dontAsk` set. Also require `skipDangerousModePermissionPrompt: true` at global level (suppresses the one-time bypass warning). Project settings may mirror it; worktree agents fall back to global, so global is the gate. Codex `trust_level = "trusted"` for the project; Copilot knob TBD | Yes — additive writes: `bypassPermissions` + `skipDangerousModePermissionPrompt: true` in `~/.claude/settings.json` |
| 6 | Versions: report installed versions of present harnesses + packs, and the cache's `checked_at` | No — cache older than 7 days is `⚠️` (never `❌`; offline machines must still reach `ready`); remediation: run `update-agent-stack` |
| 7 | uv resolves — only when `pyproject.toml` or `uv.lock` exists at the project root; otherwise `⏭️` | No — remediation per OS |

A harness or component absent from this machine (e.g. no `codex` CLI) is a skip, not a failure.

## Script shape

`secret-agents/skills/ready-player-one/preflight.py` — Python 3, stdlib only.

- Invocation: `python preflight.py [--no-fix] [--json]`. Default mode autofixes and prints human-readable result lines plus a final JSON summary block the model relays verbatim.
- Owns checks 0–3 and 5–7. Check 4 belongs to the model (only it can see the session skill list); SKILL.md directs it.
- Link handling: create-only, junction-aware on Windows (junction ≠ symlink; compare resolved targets, don't trust `is_symlink`). A failed creation must not leave a partial link, and cleanup failure must not mask the original error (behavior salvaged from the installer's `links.py` tests).
- Windows symlink creation may require Developer Mode/elevation: refuse with a clear message; no copy/junction/hard-link fallbacks for per-skill links.

`SKILL.md` becomes thin: run the script, relay its output, perform check 4, stop at the verdict. The old prose-driven check bodies (duplicated PowerShell/bash, per-OS fix tables) are deleted — the script is the single implementation.

## Companion skill: `update-agent-stack`

The only network-touching piece. Checks latest versions of: harness CLIs present on the machine, foreign packs via their native mechanisms (plugin marketplaces, `npx skills update` / `git` metadata), and writes the cache. Proposes each available update and applies it **only on per-item confirmation**.

Cache: `~/.agents/versions.json` — per-machine, because installs are per-machine:

```json
{ "checked_at": "2026-08-30T14:00:00Z",
  "components": { "claude-cli": { "installed": "2.1.200", "latest": "2.1.204" } } }
```

The two skills share only the trivial readers for the pointer file and manifest; their scripts stay independent (cross-skill imports break under per-skill linking — accepted duplication of a few lines).

## Out of scope / parked

- **Code-name guard:** two internal code names must never appear in this public repo (the list itself is deliberately kept out of the repo). A CI guard is a separate discussion — candidate for the `architecture-guards` skill pattern.
- Uninstall, receipts, backups, transactional installer machinery — rejected with the installer project (see `docs/2026-08-29-symlink-installer-reset-handoff.md`).
- Copilot specifics (instruction path, skills discovery, trust knob) — resolve during implementation; the manifest and runbook have named slots for them.

## Implementation order

1. Rewrite `skills/ready-player-one/SKILL.md` (thin contract) + write `preflight.py`; delete `skills/agent-preflight/`. Plant-a-violation tests for: vault purity, link conflict refusal, junction-vs-symlink detection.
2. Write `packs.json` with real `expect` lists (enumerate from installed packs).
3. `update-agent-stack` skill + script.
4. Wire this machine per the runbook's migration section; run the preflight until `ready`; then the other five machines.
