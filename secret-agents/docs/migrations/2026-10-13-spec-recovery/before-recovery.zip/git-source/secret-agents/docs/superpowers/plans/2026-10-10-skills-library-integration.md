# Skills Library Integration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a stdlib-only `SkillCatalog` program that incrementally validates and refreshes the skills library, add canonical metadata to all 19 skills, merge 4 source-only skills from worky, generate aliases and TOC, and wire `qas`/`update-skills-readme`/`install-skills` to the catalog contract.

**Architecture:** A single stdlib Python file (`catalog.py`) owns all catalog logic: header parsing, stat-cache-based incremental refresh, alias generation, atomic writes, and `show`/`update`/`check` CLI commands. Data classes own construction and serialization as class/instance methods. `SkillCatalog` owns the orchestration. Other skills invoke it as a subprocess — no cross-skill Python imports. Canonical SKILL.md files carry a structured header line after the H1 as the single source of category, shorthand, aliases, and updated date.

**Tech Stack:** Python 3.11+ stdlib only for `catalog.py`; pytest + mypy + ruff for CI; existing `secret_agents_setup` package for integration tests that call the CLI as a subprocess.

**Spec:** [secret-agents/docs/specs/2026-10-10-skills-library-integration-design.md](../specs/2026-10-10-skills-library-integration-design.md)

## Global Constraints

- Python ≥ 3.11 (matches `requires-python = ">=3.11"` in pyproject.toml).
- `catalog.py` is stdlib-only — no third-party or internal-package imports.
- All catalog writes are atomic: write to temp file, then `os.replace`.
- Catalog and TOC publish last; local stat cache writes last of all.
- Validation failure performs no generated writes.
- The updater never removes a human-owned directory (no generated marker), unknown file, canonical skill, or foreign pack.
- Canonical name = directory name = frontmatter `name` field.
- Preferred shorthands must begin with the category prefix and contain at least the first character of every hyphen-separated word of the canonical name, in order.
- Dirty edits to `AGENTS.md`, `README.md`, `README.html`, and `python-quality-gate/SKILL.md` must be preserved through a deliberate merge, never silently overwritten.
- Tests live in `secret-agents/tests/`, catalog script lives in `secret-agents/skills/query-all-skills/scripts/catalog.py`.

## Class map

| Class | Owns |
|---|---|
| `CanonicalEntry` (frozen dataclass) | Parsing from a skill directory — `from_dir(skill_dir, today)`; immutable copy with new date — `with_updated(date)`; private static: `_validate_frontmatter(fm, skill_dir) -> (name, description)` |
| `StatEntry` (dataclass) | Capturing `SKILL.md` size and mtime — `from_path(skill_dir)` |
| `StatCache` (dataclass) | Loading — `load(path, skills_root)`; saving — `save(path)`; private: `_from_dict(data, skills_root)` |
| `Catalog` (frozen dataclass) | Building from entry list — `build(entries, today)`; loading from JSON — `load(path)`; saving — `save(path)`; validating itself — `validate()`; rendering TOC — `render_toc()`; private static: `_from_dict(data)`, `_render_category_lines(cat, entries)`, `_check_entry(entry, ...)`, `_check_shorthand(entry)`, `_register_aliases(entry, seen_aliases, seen_names)` |
| `SkillCatalog` | `skills_root`, `cache_path`; `show()`, `update()`, `check()`; private: `_scan_canonical_dirs`, `_is_canonical_dir`, `_write_generated_aliases`, `_retire_obsolete_aliases`, `_full_refresh`, `_resolve_entry`, `_update_stat_cache`, `_publish`, `_show_slow`, `_catalog_issue`, `_toc_issue`, `_alias_issue` |
| Free functions | `parse_frontmatter`, `parse_skill_header`, `extract_h1`, `compute_semantic_hash`, `compute_content_hash`, `generate_alias_skill_md`, `is_generated_alias`, `_atomic_write` — pure text/path operations with no natural owner |

---

### Task 1: Catalog — data types, parsing, and per-skill errors

**Files:**
- Create: `secret-agents/skills/query-all-skills/scripts/catalog.py`
- Create: `secret-agents/tests/test_catalog_updater.py`

**Interfaces:**
- Produces:
  - Free functions: `parse_frontmatter(text) -> dict[str, str]`, `parse_skill_header(text) -> ParsedSkillHeader`, `extract_h1(text) -> str`, `compute_semantic_hash(text) -> str`, `compute_content_hash(text) -> str`
  - `ParsedSkillHeader(category, shorthand, updated, aliases: tuple[str, ...])`
  - `CanonicalEntry` with fields `name, display_name, description, category, shorthand, aliases, updated, semantic_hash, content_hash`
  - `StatEntry` with fields `size, mtime_ns`
  - `StatCache` with fields `schema_version, agent_root, catalog_hash, entries`
  - All error classes: `CatalogError`, `MissingFrontmatter`, `UnterminatedFrontmatter`, `MissingSkillHeader`, `MissingDisplayName`, `FrontmatterNameMismatch`, `UnknownCategory`, `InvalidShorthand`, `DuplicateName`, `HumanOwnedCollision`, `EmptyScan`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_catalog_updater.py`:

```python
"""Unit tests for the SkillCatalog stdlib program."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType

ROOT = Path(__file__).resolve().parent.parent
CATALOG_SCRIPT = ROOT / "skills" / "query-all-skills" / "scripts" / "catalog.py"


def _load_catalog() -> ModuleType:
    spec = importlib.util.spec_from_file_location("catalog", CATALOG_SCRIPT)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["catalog"] = module
    spec.loader.exec_module(module)
    return module


catalog = _load_catalog()


def _skill_text(
    name: str,
    category: str = "Testing",
    short: str = "ttest",
    updated: str = "2026-10-10",
    aliases: str = "",
    description: str = "Use when testing.",
) -> str:
    alias_part = f" · **Aliases:** {aliases}" if aliases else ""
    return (
        f"---\nname: {name}\ndescription: {description}\n---\n\n"
        f"# {name.replace('-', ' ').title()}\n\n"
        f"**Category:** {category} · **Short:** {short} · "
        f"**Updated:** {updated}{alias_part}\n\nBody text.\n"
    )


def test_parse_frontmatter_returns_name_and_description() -> None:
    text = "---\nname: my-skill\ndescription: Use when testing.\n---\n\n# Body\n"
    result = catalog.parse_frontmatter(text)
    assert result["name"] == "my-skill"
    assert result["description"] == "Use when testing."


def test_parse_frontmatter_raises_on_missing_delimiter() -> None:
    import pytest
    with pytest.raises(catalog.MissingFrontmatter):
        catalog.parse_frontmatter("# No frontmatter\n")


def test_parse_skill_header_parses_all_fields() -> None:
    text = _skill_text("run-unit-tests", "Testing", "trut", "2026-10-10", "rut")
    h = catalog.parse_skill_header(text)
    assert h.category == "Testing"
    assert h.shorthand == "trut"
    assert h.updated == "2026-10-10"
    assert h.aliases == ("rut",)


def test_parse_skill_header_omits_aliases_when_absent() -> None:
    text = _skill_text("agent-plan", "Agent Workflow", "ap")
    h = catalog.parse_skill_header(text)
    assert h.aliases == ()


def test_parse_skill_header_raises_when_missing() -> None:
    import pytest
    text = "---\nname: x\ndescription: y\n---\n\n# X\n\nNo header line.\n"
    with pytest.raises(catalog.MissingSkillHeader):
        catalog.parse_skill_header(text)


def test_extract_h1_returns_heading_text() -> None:
    text = "---\nname: x\ndescription: y\n---\n\n# My Skill\n\nBody.\n"
    assert catalog.extract_h1(text) == "My Skill"


def test_extract_h1_raises_when_missing() -> None:
    import pytest
    with pytest.raises(catalog.MissingDisplayName):
        catalog.extract_h1("---\nname: x\n---\nNo heading.\n")
```

- [ ] **Step 2: Run tests to confirm they fail**

```bash
cd C:/git/handbag-of-holding/secret-agents
uv run pytest tests/test_catalog_updater.py -v 2>&1 | head -20
```

Expected: `ModuleNotFoundError` or `FileNotFoundError` because `catalog.py` does not exist.

- [ ] **Step 3: Create `catalog.py` with data types and parsing**

Create `skills/query-all-skills/scripts/catalog.py`:

```python
"""SkillCatalog — stdlib-only catalog updater for secret-agents/skills.

Usage:
  python catalog.py show    [--skills-root <dir>]
  python catalog.py update  [--skills-root <dir>]
  python catalog.py check   [--skills-root <dir>]
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
from argparse import ArgumentParser
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SCHEMA_VERSION = 1
CACHE_SCHEMA_VERSION = 1
CATALOG_FILENAME = "catalog.json"
TOC_FILENAME = "TOC.md"
CACHE_PATH = Path.home() / ".agents" / "cache" / "secret-agents-skill-catalog.json"

CATEGORIES: dict[str, str] = {
    "Agent Workflow": "a",
    "Code Quality": "c",
    "Jira": "j",
    "Maintenance": "m",
    "Preflight": "p",
    "Query & Discovery": "q",
    "Reporting": "r",
    "Skill Management": "s",
    "Testing": "t",
    "Unreal": "u",
}
CATEGORY_ORDER = list(CATEGORIES.keys())

NON_SKILL_NAMES = {"README.md", "README.html", CATALOG_FILENAME, TOC_FILENAME}

HEADER_RE = re.compile(
    r"\*\*Category:\*\* (?P<category>[A-Za-z &]+?) · "
    r"\*\*Short:\*\* (?P<shorthand>[a-z]+) · "
    r"\*\*Updated:\*\* (?P<updated>\d{4}-\d{2}-\d{2})"
    r"(?: · \*\*Aliases:\*\* (?P<aliases>[^\n]+))?"
)
GENERATED_MARKER_RE = re.compile(
    r"<!-- generated:(?P<canonical>[a-z][a-z0-9-]*):(?P<date>\d{4}-\d{2}-\d{2}) -->"
)
UPDATED_RE = re.compile(r"(\*\*Updated:\*\* )\d{4}-\d{2}-\d{2}")

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class CatalogError(Exception):
    pass

class MissingFrontmatter(CatalogError):
    pass

class UnterminatedFrontmatter(CatalogError):
    pass

class MissingSkillHeader(CatalogError):
    pass

class MissingDisplayName(CatalogError):
    pass

class FrontmatterNameMismatch(CatalogError):
    pass

class UnknownCategory(CatalogError):
    pass

class InvalidShorthand(CatalogError):
    pass

class DuplicateName(CatalogError):
    pass

class HumanOwnedCollision(CatalogError):
    pass

class EmptyScan(CatalogError):
    pass

# ---------------------------------------------------------------------------
# Free-function helpers (pure text/path operations, no natural owner)
# ---------------------------------------------------------------------------

def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        raise MissingFrontmatter("File does not begin with '---'")
    try:
        end = text.index("\n---\n", 4)
    except ValueError:
        raise UnterminatedFrontmatter("Frontmatter block never closed")
    block = text[4:end]
    pairs = (line.partition(": ") for line in block.splitlines() if ": " in line)
    return {k.strip(): v.strip().strip('"') for k, _, v in pairs}


def parse_skill_header(text: str) -> ParsedSkillHeader:
    m = HEADER_RE.search(text)
    if m is None:
        raise MissingSkillHeader("No canonical skill header found")
    aliases_raw = m.group("aliases") or ""
    aliases = tuple(a.strip() for a in aliases_raw.split(",") if a.strip())
    return ParsedSkillHeader(
        category=m.group("category").strip(),
        shorthand=m.group("shorthand"),
        updated=m.group("updated"),
        aliases=aliases,
    )


def extract_h1(text: str) -> str:
    h1 = next(
        (line[2:].strip() for line in text.splitlines()
         if line.startswith("# ") and not line.startswith("## ")),
        None,
    )
    if h1 is None:
        raise MissingDisplayName("No H1 heading found in SKILL.md")
    return h1


def compute_semantic_hash(text: str) -> str:
    """SHA-256 with Updated date replaced — unchanged by timestamp-only edits."""
    normalized = UPDATED_RE.sub(r"\1__date__", text)
    return hashlib.sha256(normalized.encode()).hexdigest()


def compute_content_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def is_generated_alias(skill_dir: Path) -> bool:
    """True when SKILL.md contains the machine-readable generated marker."""
    skill_file = skill_dir / "SKILL.md"
    if not skill_file.is_file():
        return False
    return GENERATED_MARKER_RE.search(skill_file.read_text(encoding="utf-8")) is not None


def generate_alias_skill_md(alias: str, canonical: str, date: str, description: str) -> str:
    return (
        f"---\nname: {alias}\ndescription: Alias for {canonical}. {description}\n---\n\n"
        f"<!-- generated:{canonical}:{date} -->\n"
        f"# {alias}\n\n"
        f"Alias for `{canonical}`. Pass all arguments through unchanged.\n\n"
        f"## Behavior\n\n"
        f"Follow the `{canonical}` skill exactly. Treat all arguments passed to "
        f"`/{alias}` as arguments for `/{canonical}`.\n"
    )


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        os.write(fd, text.encode())
        os.close(fd)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclasses.dataclass(frozen=True)
class ParsedSkillHeader:
    category: str
    shorthand: str
    updated: str
    aliases: tuple[str, ...]


@dataclasses.dataclass(frozen=True)
class CanonicalEntry:
    name: str
    display_name: str
    description: str
    category: str
    shorthand: str
    aliases: tuple[str, ...]
    updated: str
    semantic_hash: str
    content_hash: str

    @staticmethod
    def _validate_frontmatter(fm: dict[str, str], skill_dir: Path) -> tuple[str, str]:
        """Returns (name, description) after validating both fields."""
        name = fm.get("name", "")
        if not name:
            raise CatalogError(f"{skill_dir.name}/SKILL.md: missing 'name' in frontmatter")
        if name != skill_dir.name:
            raise FrontmatterNameMismatch(
                f"{skill_dir.name}/SKILL.md: frontmatter name '{name}' != directory"
            )
        description = fm.get("description", "")
        if not description:
            raise CatalogError(f"{skill_dir.name}/SKILL.md: missing 'description'")
        return name, description

    @classmethod
    def from_dir(cls, skill_dir: Path, today: str) -> CanonicalEntry:
        text = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
        name, description = cls._validate_frontmatter(parse_frontmatter(text), skill_dir)
        header = parse_skill_header(text)
        return cls(
            name=name,
            display_name=extract_h1(text),
            description=description,
            category=header.category,
            shorthand=header.shorthand,
            aliases=header.aliases,
            updated=header.updated,
            semantic_hash=compute_semantic_hash(text),
            content_hash=compute_content_hash(text),
        )

    def with_updated(self, date: str) -> CanonicalEntry:
        return dataclasses.replace(self, updated=date)


@dataclasses.dataclass
class StatEntry:
    size: int
    mtime_ns: int

    @classmethod
    def from_path(cls, skill_dir: Path) -> StatEntry:
        s = (skill_dir / "SKILL.md").stat()
        return cls(size=s.st_size, mtime_ns=s.st_mtime_ns)


@dataclasses.dataclass
class StatCache:
    schema_version: int
    agent_root: str
    catalog_hash: str
    entries: dict[str, StatEntry]  # "skill-name/SKILL.md" -> stat

    @classmethod
    def _from_dict(cls, data: dict, skills_root: Path) -> StatCache | None:
        if data.get("schema_version") != CACHE_SCHEMA_VERSION:
            return None
        if data.get("agent_root") != str(skills_root):
            return None
        entries = {k: StatEntry(**v) for k, v in data.get("entries", {}).items()}
        return cls(
            schema_version=data["schema_version"],
            agent_root=data["agent_root"],
            catalog_hash=data.get("catalog_hash", ""),
            entries=entries,
        )

    @classmethod
    def load(cls, path: Path, skills_root: Path) -> StatCache | None:
        if not path.is_file():
            return None
        try:
            return cls._from_dict(json.loads(path.read_text(encoding="utf-8")), skills_root)
        except Exception:
            return None

    def save(self, path: Path) -> None:
        data = {
            "schema_version": self.schema_version,
            "agent_root": self.agent_root,
            "catalog_hash": self.catalog_hash,
            "entries": {k: dataclasses.asdict(v) for k, v in self.entries.items()},
        }
        _atomic_write(path, json.dumps(data, indent=2))
```

Note: `ParsedSkillHeader` must be declared before `parse_skill_header` uses it; `CanonicalEntry` must be declared before the free functions that reference it. Reorder the file so all error classes come first, then free helpers, then data classes — or forward-declare. The cleanest layout is: constants → errors → free helpers → data classes. Since `CanonicalEntry.from_dir` calls the free helpers that are already defined above it, this order works.

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/test_catalog_updater.py -v 2>&1 | tail -20
```

Expected: 8 PASSED.

- [ ] **Step 5: Commit**

```bash
git add secret-agents/skills/query-all-skills/scripts/catalog.py secret-agents/tests/test_catalog_updater.py
git commit -m "feat(catalog): add data types with class methods, parsing, and error classes"
```

---

### Task 2: Catalog — `SkillCatalog` scaffold, stat cache, and show fast path

**Files:**
- Modify: `secret-agents/skills/query-all-skills/scripts/catalog.py`
- Modify: `secret-agents/tests/test_catalog_updater.py`

**Interfaces:**
- Consumes: `CanonicalEntry.from_dir`, `StatEntry.from_path`, `StatCache.load/save`, `is_generated_alias`
- Produces:
  - `SkillCatalog(skills_root: Path, cache_path: Path = CACHE_PATH)` with `show(out=None) -> int` (fast path only — slow path stubbed)
  - `SkillCatalog._scan_canonical_dirs() -> list[Path]`
  - `SkillCatalog._is_canonical_dir(child: Path) -> bool` — guard helper used by `_scan_canonical_dirs`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_catalog_updater.py`:

```python
def test_scan_canonical_dirs_excludes_generated_aliases(tmp_path: Path) -> None:
    (tmp_path / "my-skill").mkdir()
    (tmp_path / "my-skill" / "SKILL.md").write_text(
        _skill_text("my-skill", "Testing", "tms"), encoding="utf-8"
    )
    (tmp_path / "tms").mkdir()
    (tmp_path / "tms" / "SKILL.md").write_text(
        "---\nname: tms\ndescription: Alias.\n---\n\n<!-- generated:my-skill:2026-10-10 -->\n",
        encoding="utf-8",
    )
    sc = catalog.SkillCatalog(tmp_path)
    result = sc._scan_canonical_dirs()
    assert len(result) == 1
    assert result[0].name == "my-skill"


def test_scan_canonical_dirs_raises_on_missing_skill_file(tmp_path: Path) -> None:
    import pytest
    (tmp_path / "bad-skill").mkdir()
    sc = catalog.SkillCatalog(tmp_path)
    with pytest.raises(catalog.CatalogError):
        sc._scan_canonical_dirs()


def test_canonical_entry_from_dir_returns_correct_fields(tmp_path: Path) -> None:
    (tmp_path / "run-unit-tests").mkdir()
    (tmp_path / "run-unit-tests" / "SKILL.md").write_text(
        _skill_text("run-unit-tests", "Testing", "trut", aliases="rut"),
        encoding="utf-8",
    )
    entry = catalog.CanonicalEntry.from_dir(tmp_path / "run-unit-tests", "2026-10-10")
    assert entry.name == "run-unit-tests"
    assert entry.category == "Testing"
    assert entry.shorthand == "trut"
    assert entry.aliases == ("rut",)
    assert len(entry.semantic_hash) == 64
    assert len(entry.content_hash) == 64


def test_stat_cache_miss_on_missing_file(tmp_path: Path) -> None:
    result = catalog.StatCache.load(tmp_path / "nonexistent.json", tmp_path)
    assert result is None


def test_stat_cache_roundtrip(tmp_path: Path) -> None:
    cache_path = tmp_path / "cache.json"
    cache = catalog.StatCache(
        schema_version=catalog.CACHE_SCHEMA_VERSION,
        agent_root=str(tmp_path),
        catalog_hash="abc123",
        entries={"x/SKILL.md": catalog.StatEntry(size=100, mtime_ns=123456789)},
    )
    cache.save(cache_path)
    loaded = catalog.StatCache.load(cache_path, tmp_path)
    assert loaded is not None
    assert loaded.catalog_hash == "abc123"
    assert loaded.entries["x/SKILL.md"].size == 100


def test_stat_entry_from_path(tmp_path: Path) -> None:
    skill_dir = tmp_path / "x"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("content", encoding="utf-8")
    entry = catalog.StatEntry.from_path(skill_dir)
    assert entry.size > 0
    assert entry.mtime_ns > 0


def test_show_fast_path_reads_no_skill_bodies(tmp_path: Path) -> None:
    """Warm-cache show must not read any SKILL.md body."""
    import io, json, unittest.mock

    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    skill_path = skill_dir / "SKILL.md"
    skill_path.write_text(_skill_text("my-skill", "Testing", "tms"), encoding="utf-8")

    toc_text = "# Skills\n\nGenerated 2026-10-10.\n"
    (tmp_path / catalog.TOC_FILENAME).write_text(toc_text, encoding="utf-8")

    entry = catalog.CanonicalEntry.from_dir(skill_dir, "2026-10-10")
    catalog_data = {
        "schema_version": catalog.SCHEMA_VERSION,
        "generated": "2026-10-10",
        "entries": [dataclasses.asdict(entry)],
        "generated_aliases": {},
    }
    catalog_json_text = json.dumps(catalog_data)
    (tmp_path / catalog.CATALOG_FILENAME).write_text(catalog_json_text, encoding="utf-8")

    stat_entry = catalog.StatEntry.from_path(skill_dir)
    cache = catalog.StatCache(
        schema_version=catalog.CACHE_SCHEMA_VERSION,
        agent_root=str(tmp_path),
        catalog_hash=catalog.compute_content_hash(catalog_json_text),
        entries={"my-skill/SKILL.md": stat_entry},
    )
    cache_path = tmp_path / "cache.json"
    cache.save(cache_path)

    read_calls: list[str] = []
    original_read = Path.read_text

    def spy(self: Path, **kwargs):  # type: ignore[no-untyped-def]
        if self.name == "SKILL.md":
            read_calls.append(str(self))
        return original_read(self, **kwargs)

    sc = catalog.SkillCatalog(tmp_path, cache_path=cache_path)
    with unittest.mock.patch.object(Path, "read_text", spy):
        sc.show(out=io.StringIO())

    assert read_calls == [], f"Fast path read SKILL.md bodies: {read_calls}"
```

Add `import dataclasses, json` near the top of the test file (with the other imports).

- [ ] **Step 2: Run to confirm failures**

```bash
uv run pytest tests/test_catalog_updater.py -v -k "scan or entry or stat or show" 2>&1 | tail -15
```

Expected: `AttributeError: module 'catalog' has no attribute 'SkillCatalog'`

- [ ] **Step 3: Add `SkillCatalog` with scan and show fast path**

Add after the data classes in `catalog.py`:

```python
# ---------------------------------------------------------------------------
# SkillCatalog — orchestrator
# ---------------------------------------------------------------------------

class SkillCatalog:
    def __init__(
        self,
        skills_root: Path,
        cache_path: Path = CACHE_PATH,
    ) -> None:
        self.skills_root = skills_root
        self.cache_path = cache_path

    # -- Directory scanning --------------------------------------------------

    def _is_canonical_dir(self, child: Path) -> bool:
        """True when child is a real skill dir (not a generated alias, not a non-dir)."""
        if not child.is_dir() or child.name in NON_SKILL_NAMES:
            return False
        if is_generated_alias(child):
            return False
        if not (child / "SKILL.md").is_file():
            raise CatalogError(f"Non-generated directory '{child.name}' has no SKILL.md")
        return True

    def _scan_canonical_dirs(self) -> list[Path]:
        return [child for child in sorted(self.skills_root.iterdir()) if self._is_canonical_dir(child)]

    # -- CLI commands --------------------------------------------------------

    def show(self, out=None) -> int:
        """Fast refresh + print TOC. Reads no SKILL.md bodies on a warm cache."""
        if out is None:
            out = sys.stdout
        toc_path = self.skills_root / TOC_FILENAME
        catalog_path = self.skills_root / CATALOG_FILENAME
        catalog_text = catalog_path.read_text(encoding="utf-8") if catalog_path.is_file() else None
        stat_cache = StatCache.load(self.cache_path, self.skills_root)
        if not (stat_cache and catalog_text):
            return self._show_slow(out)
        if stat_cache.catalog_hash != compute_content_hash(catalog_text):
            return self._show_slow(out)
        current = {f"{d.name}/SKILL.md": StatEntry.from_path(d) for d in self._scan_canonical_dirs()}
        if current != stat_cache.entries or not toc_path.is_file():
            return self._show_slow(out)
        out.write(toc_path.read_text(encoding="utf-8"))
        return 0

    def _show_slow(self, out) -> int:  # stub — implemented in Task 5
        return 1
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/test_catalog_updater.py -v -k "scan or entry or stat or show" 2>&1 | tail -20
```

Expected: all targeted tests PASSED (the fast-path test now passes; `_show_slow` returns 1 so the slow-path fallback isn't exercised yet).

- [ ] **Step 5: Commit**

```bash
git add secret-agents/skills/query-all-skills/scripts/catalog.py secret-agents/tests/test_catalog_updater.py
git commit -m "feat(catalog): add SkillCatalog scaffold, _scan_canonical_dirs, show fast path"
```

---

### Task 3: Catalog — `Catalog` class with build, load, save, and render_toc

**Files:**
- Modify: `secret-agents/skills/query-all-skills/scripts/catalog.py`
- Modify: `secret-agents/tests/test_catalog_updater.py`

**Interfaces:**
- Consumes: `CanonicalEntry`, `compute_semantic_hash`, `CATEGORY_ORDER`, `CATEGORIES`
- Produces:
  - `Catalog.build(entries: list[CanonicalEntry], today: str) -> Catalog`
  - `Catalog.load(path: Path) -> Catalog | None`
  - `catalog.save(path: Path) -> None`
  - `catalog.render_toc() -> str`
  - `Catalog._render_category_lines(cat: str, entries: list[CanonicalEntry]) -> list[str]` (static, used only by `render_toc`)
  - `Catalog(schema_version, generated, entries: tuple[CanonicalEntry, ...], generated_aliases: dict[str, str])`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_catalog_updater.py`:

```python
def test_semantic_hash_ignores_updated_date() -> None:
    text_a = _skill_text("x", updated="2026-01-01")
    text_b = _skill_text("x", updated="2026-12-31")
    assert catalog.compute_semantic_hash(text_a) == catalog.compute_semantic_hash(text_b)


def test_semantic_hash_differs_on_content_change() -> None:
    text_a = _skill_text("x", description="Use when foo.")
    text_b = _skill_text("x", description="Use when bar.")
    assert catalog.compute_semantic_hash(text_a) != catalog.compute_semantic_hash(text_b)


def test_with_updated_returns_new_entry() -> None:
    text = _skill_text("my-skill", updated="2026-01-01")
    entry = catalog.CanonicalEntry.from_dir(
        _write_skill(Path(__file__).parent, "my-skill", text), "2026-01-01"
    )
    bumped = entry.with_updated("2026-10-10")
    assert bumped.updated == "2026-10-10"
    assert bumped.name == entry.name  # other fields unchanged


def test_catalog_build_generates_alias_map(tmp_path: Path) -> None:
    entry = catalog.CanonicalEntry(
        "run-unit-tests", "Run Unit Tests", "Run tests.", "Testing",
        "trut", ("rut",), "2026-10-10", "h1", "h2",
    )
    c = catalog.Catalog.build([entry], "2026-10-10")
    assert c.generated_aliases["trut"] == "run-unit-tests"
    assert c.generated_aliases["rut"] == "run-unit-tests"


def test_catalog_build_sorts_by_category_then_display_name(tmp_path: Path) -> None:
    entries = [
        catalog.CanonicalEntry("run-unit-tests", "Run Unit Tests", ".", "Testing", "trut", (), "2026-10-10", "h1", "h2"),
        catalog.CanonicalEntry("agent-plan", "Agent Plan", ".", "Agent Workflow", "ap", (), "2026-10-10", "h3", "h4"),
    ]
    c = catalog.Catalog.build(entries, "2026-10-10")
    assert c.entries[0].name == "agent-plan"
    assert c.entries[1].name == "run-unit-tests"


def test_catalog_load_roundtrip(tmp_path: Path) -> None:
    entry = catalog.CanonicalEntry(
        "run-unit-tests", "Run Unit Tests", "Run tests.", "Testing",
        "trut", ("rut",), "2026-10-10", "h1", "h2",
    )
    c = catalog.Catalog.build([entry], "2026-10-10")
    path = tmp_path / "catalog.json"
    c.save(path)
    loaded = catalog.Catalog.load(path)
    assert loaded is not None
    assert len(loaded.entries) == 1
    assert loaded.entries[0].name == "run-unit-tests"
    assert loaded.entries[0].aliases == ("rut",)


def test_render_toc_sorted_by_category_then_display_name() -> None:
    entries = [
        catalog.CanonicalEntry("run-unit-tests", "Run Unit Tests", "Run tests.", "Testing", "trut", ("rut",), "2026-10-10", "h1", "h2"),
        catalog.CanonicalEntry("agent-plan", "Agent Plan", "Plan work.", "Agent Workflow", "ap", (), "2026-10-10", "h3", "h4"),
    ]
    c = catalog.Catalog.build(entries, "2026-10-10")
    toc = c.render_toc()
    agent_idx = toc.index("Agent Workflow")
    testing_idx = toc.index("## Testing")
    assert agent_idx < testing_idx
    assert "Run Unit Tests" in toc
    assert "(`trut`)" in toc
    assert "rut" in toc


def test_render_toc_one_bullet_per_canonical_skill() -> None:
    entries = [
        catalog.CanonicalEntry("run-unit-tests", "Run Unit Tests", "Run tests.", "Testing", "trut", ("rut",), "2026-10-10", "h1", "h2"),
    ]
    c = catalog.Catalog.build(entries, "2026-10-10")
    toc = c.render_toc()
    assert toc.count("- ") == 1
```

Add this helper near the top of the test file (after the imports):

```python
def _write_skill(root: Path, name: str, text: str) -> Path:
    d = root / name
    d.mkdir(exist_ok=True)
    (d / "SKILL.md").write_text(text, encoding="utf-8")
    return d
```

- [ ] **Step 2: Run to confirm failures**

```bash
uv run pytest tests/test_catalog_updater.py -v -k "hash or with_updated or catalog_build or catalog_load or render_toc" 2>&1 | tail -10
```

Expected: `AttributeError: 'CanonicalEntry' object has no attribute 'with_updated'` (or `Catalog.build`)

- [ ] **Step 3: Add methods to `CanonicalEntry` and implement `Catalog`**

`CanonicalEntry.from_dir` and `with_updated` are already declared in Task 1. Verify they're present.

Add the `Catalog` class after `StatCache` in `catalog.py`:

```python
@dataclasses.dataclass(frozen=True)
class Catalog:
    schema_version: int
    generated: str
    entries: tuple[CanonicalEntry, ...]
    generated_aliases: dict[str, str]  # alias/shorthand -> canonical name

    @classmethod
    def build(cls, entries: list[CanonicalEntry], today: str) -> Catalog:
        """Assemble a Catalog from a list of (already date-resolved) entries."""
        aliases: dict[str, str] = {}
        for e in entries:
            aliases[e.shorthand] = e.name
            for a in e.aliases:
                aliases[a] = e.name
        ordered = tuple(
            sorted(
                entries,
                key=lambda e: (CATEGORY_ORDER.index(e.category), e.display_name),
            )
        )
        return cls(
            schema_version=SCHEMA_VERSION,
            generated=today,
            entries=ordered,
            generated_aliases=aliases,
        )

    @classmethod
    def _from_dict(cls, data: dict) -> Catalog | None:
        if data.get("schema_version") != SCHEMA_VERSION:
            return None
        entries = tuple(
            CanonicalEntry(**{k: tuple(v) if isinstance(v, list) else v for k, v in e.items()})
            for e in data.get("entries", [])
        )
        return cls(
            schema_version=data["schema_version"],
            generated=data.get("generated", ""),
            entries=entries,
            generated_aliases=data.get("generated_aliases", {}),
        )

    @classmethod
    def load(cls, path: Path) -> Catalog | None:
        if not path.is_file():
            return None
        try:
            return cls._from_dict(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            return None

    def save(self, path: Path) -> None:
        data = {
            "schema_version": self.schema_version,
            "generated": self.generated,
            "entries": [dataclasses.asdict(e) for e in self.entries],
            "generated_aliases": self.generated_aliases,
        }
        _atomic_write(path, json.dumps(data, indent=2))

    @staticmethod
    def _render_category_lines(cat: str, entries: list[CanonicalEntry]) -> list[str]:
        def entry_line(e: CanonicalEntry) -> str:
            alias_note = f" · Aliases: {', '.join(e.aliases)}" if e.aliases else ""
            return f"- {e.display_name} (`{e.shorthand}`) — {e.description}{alias_note}"
        return ["", f"## {cat} ({CATEGORIES[cat]})", ""] + [entry_line(e) for e in entries]

    def render_toc(self) -> str:
        by_cat: dict[str, list[CanonicalEntry]] = {}
        for entry in self.entries:
            by_cat.setdefault(entry.category, []).append(entry)
        lines = ["# Skills", "", f"Generated {self.generated}. Run `/<short>` or `/<canonical-name>`."]
        for cat in CATEGORY_ORDER:
            cat_entries = by_cat.get(cat)
            if cat_entries:
                lines.extend(self._render_category_lines(cat, cat_entries))
        return "\n".join(lines) + "\n"
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/test_catalog_updater.py -v -k "hash or with_updated or catalog_build or catalog_load or render_toc" 2>&1 | tail -20
```

Expected: all targeted tests PASSED.

- [ ] **Step 5: Commit**

```bash
git add secret-agents/skills/query-all-skills/scripts/catalog.py secret-agents/tests/test_catalog_updater.py
git commit -m "feat(catalog): add Catalog.build/load/save/render_toc and CanonicalEntry.with_updated"
```

---

### Task 4: Catalog — alias generation and `SkillCatalog` private write methods

**Files:**
- Modify: `secret-agents/skills/query-all-skills/scripts/catalog.py`
- Modify: `secret-agents/tests/test_catalog_updater.py`

**Interfaces:**
- Consumes: `generate_alias_skill_md`, `is_generated_alias`, `Catalog`, `_atomic_write`
- Produces:
  - `SkillCatalog._write_generated_aliases(catalog_obj: Catalog, today: str) -> None`
  - `SkillCatalog._retire_obsolete_aliases(catalog_obj: Catalog) -> None`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_catalog_updater.py`:

```python
def test_generate_alias_skill_md_contains_marker() -> None:
    text = catalog.generate_alias_skill_md("trut", "run-unit-tests", "2026-10-10", "Run tests.")
    m = catalog.GENERATED_MARKER_RE.search(text)
    assert m is not None
    assert m.group("canonical") == "run-unit-tests"
    assert m.group("date") == "2026-10-10"
    fm = catalog.parse_frontmatter(text)
    assert fm["name"] == "trut"


def test_write_generated_aliases_creates_directories(tmp_path: Path) -> None:
    entry = catalog.CanonicalEntry(
        "run-unit-tests", "Run Unit Tests", "Run tests.", "Testing",
        "trut", ("rut",), "2026-10-10", "h1", "h2",
    )
    c = catalog.Catalog.build([entry], "2026-10-10")
    sc = catalog.SkillCatalog(tmp_path)
    sc._write_generated_aliases(c, "2026-10-10")
    assert (tmp_path / "trut" / "SKILL.md").is_file()
    assert (tmp_path / "rut" / "SKILL.md").is_file()
    assert "run-unit-tests" in (tmp_path / "trut" / "SKILL.md").read_text(encoding="utf-8")


def test_write_generated_aliases_refuses_human_owned_collision(tmp_path: Path) -> None:
    import pytest
    (tmp_path / "trut").mkdir()
    (tmp_path / "trut" / "SKILL.md").write_text(
        "---\nname: trut\ndescription: Hand-written.\n---\n\n# trut\n\nBody.\n",
        encoding="utf-8",
    )
    entry = catalog.CanonicalEntry(
        "run-unit-tests", "Run Unit Tests", "Run tests.", "Testing",
        "trut", (), "2026-10-10", "h1", "h2",
    )
    c = catalog.Catalog.build([entry], "2026-10-10")
    sc = catalog.SkillCatalog(tmp_path)
    with pytest.raises(catalog.HumanOwnedCollision):
        sc._write_generated_aliases(c, "2026-10-10")


def test_retire_obsolete_aliases_removes_generated_only(tmp_path: Path) -> None:
    (tmp_path / "old-alias").mkdir()
    (tmp_path / "old-alias" / "SKILL.md").write_text(
        "---\nname: old-alias\ndescription: Alias.\n---\n\n"
        "<!-- generated:some-skill:2026-10-10 -->\n",
        encoding="utf-8",
    )
    c = catalog.Catalog.build([], "2026-10-10")
    sc = catalog.SkillCatalog(tmp_path)
    sc._retire_obsolete_aliases(c)
    assert not (tmp_path / "old-alias").exists()


def test_retire_obsolete_aliases_preserves_human_owned(tmp_path: Path) -> None:
    (tmp_path / "human-alias").mkdir()
    (tmp_path / "human-alias" / "SKILL.md").write_text(
        "---\nname: human-alias\ndescription: Human.\n---\n\n# human-alias\n\nBody.\n",
        encoding="utf-8",
    )
    c = catalog.Catalog.build([], "2026-10-10")
    sc = catalog.SkillCatalog(tmp_path)
    sc._retire_obsolete_aliases(c)
    assert (tmp_path / "human-alias").exists()
```

- [ ] **Step 2: Run to confirm failures**

```bash
uv run pytest tests/test_catalog_updater.py -v -k "alias or generated or retire" 2>&1 | tail -10
```

Expected: `AttributeError: 'SkillCatalog' object has no attribute '_write_generated_aliases'`

- [ ] **Step 3: Add `_write_generated_aliases` and `_retire_obsolete_aliases` to `SkillCatalog`**

Add to `SkillCatalog` in `catalog.py`:

```python
    # -- Alias management ----------------------------------------------------

    def _write_generated_aliases(self, catalog_obj: Catalog, today: str) -> None:
        entry_by_name = {e.name: e for e in catalog_obj.entries}
        for alias, canonical in catalog_obj.generated_aliases.items():
            alias_dir = self.skills_root / alias
            if alias_dir.exists() and not is_generated_alias(alias_dir):
                raise HumanOwnedCollision(
                    f"'{alias}' is a human-owned directory; cannot generate alias there"
                )
            entry = entry_by_name.get(canonical)
            description = entry.description if entry else ""
            _atomic_write(
                alias_dir / "SKILL.md",
                generate_alias_skill_md(alias, canonical, today, description),
            )
            alias_dir.mkdir(exist_ok=True)  # mkdir before write in case dir is new

    def _retire_obsolete_aliases(self, catalog_obj: Catalog) -> None:
        current = set(catalog_obj.generated_aliases.keys())
        for child in sorted(self.skills_root.iterdir()):
            if not child.is_dir() or child.name in current:
                continue
            if not is_generated_alias(child):
                continue
            unexpected = [f for f in child.iterdir() if f.name != "SKILL.md"]
            if unexpected:
                continue
            shutil.rmtree(child)
```

Note: `alias_dir.mkdir(exist_ok=True)` must come before `_atomic_write` because `_atomic_write` calls `path.parent.mkdir(parents=True, exist_ok=True)` internally — the order doesn't matter in practice but mkdir before write is clearer intent. Actually `_atomic_write` already creates the parent, so the explicit `mkdir` call is redundant — remove it.

Corrected:

```python
    def _write_generated_aliases(self, catalog_obj: Catalog, today: str) -> None:
        entry_by_name = {e.name: e for e in catalog_obj.entries}
        for alias, canonical in catalog_obj.generated_aliases.items():
            alias_dir = self.skills_root / alias
            if alias_dir.exists() and not is_generated_alias(alias_dir):
                raise HumanOwnedCollision(
                    f"'{alias}' is a human-owned directory; cannot generate alias there"
                )
            entry = entry_by_name.get(canonical)
            description = entry.description if entry else ""
            _atomic_write(
                alias_dir / "SKILL.md",
                generate_alias_skill_md(alias, canonical, today, description),
            )
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/test_catalog_updater.py -v -k "alias or generated or retire" 2>&1 | tail -20
```

Expected: all alias tests PASSED.

- [ ] **Step 5: Commit**

```bash
git add secret-agents/skills/query-all-skills/scripts/catalog.py secret-agents/tests/test_catalog_updater.py
git commit -m "feat(catalog): add SkillCatalog._write_generated_aliases and _retire_obsolete_aliases"
```

---

### Task 5: Catalog — `Catalog.validate`, full refresh, and CLI commands

**Files:**
- Modify: `secret-agents/skills/query-all-skills/scripts/catalog.py`
- Modify: `secret-agents/tests/test_catalog_updater.py`
- Modify: `secret-agents/pyproject.toml` — add catalog script to mypy `files`

**Interfaces:**
- Consumes: all previous methods
- Produces:
  - `Catalog.validate() -> None` — raises `CatalogError` subclasses on violations (no `skills_root` param — pure catalog consistency check)
  - `Catalog._check_entry(entry, seen_names, seen_shorthands, seen_aliases) -> None` (static, one consumer)
  - `SkillCatalog._full_refresh() -> tuple[Catalog, str]`
  - `SkillCatalog._resolve_entry(skill_dir, today, prev_by_name) -> CanonicalEntry` (one consumer)
  - `SkillCatalog._update_stat_cache(catalog_obj: Catalog) -> None`
  - `SkillCatalog._catalog_issue(catalog_path, new_catalog) -> str | None`
  - `SkillCatalog._toc_issue(toc_path, expected_toc) -> str | None`
  - `SkillCatalog._alias_issue(alias) -> str | None`
  - `SkillCatalog.show(out)`, `SkillCatalog.update(out)`, `SkillCatalog.check(out)` *(completed)*
  - `main() -> int` — instantiates `SkillCatalog`, calls the appropriate method

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_catalog_updater.py`:

```python
def test_validate_rejects_duplicate_shorthands() -> None:
    import pytest
    entries = [
        catalog.CanonicalEntry("skill-a", "Skill A", "A.", "Testing", "ta", (), "2026-10-10", "h1", "h2"),
        catalog.CanonicalEntry("skill-b", "Skill B", "B.", "Testing", "ta", (), "2026-10-10", "h3", "h4"),
    ]
    c = catalog.Catalog.build(entries, "2026-10-10")
    with pytest.raises(catalog.DuplicateName):
        c.validate()


def test_validate_rejects_shorthand_without_category_prefix() -> None:
    import pytest
    entries = [
        catalog.CanonicalEntry(
            "run-unit-tests", "Run Unit Tests", "R.", "Testing", "rut", (), "2026-10-10", "h1", "h2"
        ),
    ]
    # "rut" starts with "r" (Reporting prefix) not "t" (Testing prefix)
    c = catalog.Catalog(1, "2026-10-10", tuple(entries), {"rut": "run-unit-tests"})
    with pytest.raises(catalog.InvalidShorthand):
        c.validate()


def test_validate_rejects_empty_entries() -> None:
    import pytest
    c = catalog.Catalog.build([], "2026-10-10")
    with pytest.raises(catalog.EmptyScan):
        c.validate()


def _make_skill_tree(tmp_path: Path) -> None:
    skill_dir = tmp_path / "run-unit-tests"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(
        _skill_text("run-unit-tests", "Testing", "trut", aliases="rut"),
        encoding="utf-8",
    )


def test_update_creates_catalog_and_toc(tmp_path: Path) -> None:
    import io
    _make_skill_tree(tmp_path)
    sc = catalog.SkillCatalog(tmp_path, cache_path=tmp_path / "cache.json")
    assert sc.update(out=io.StringIO()) == 0
    assert (tmp_path / catalog.CATALOG_FILENAME).is_file()
    assert (tmp_path / catalog.TOC_FILENAME).is_file()


def test_check_returns_nonzero_on_stale_toc(tmp_path: Path) -> None:
    import io
    _make_skill_tree(tmp_path)
    sc = catalog.SkillCatalog(tmp_path, cache_path=tmp_path / "cache.json")
    sc.update(out=io.StringIO())
    (tmp_path / catalog.TOC_FILENAME).write_text("stale\n", encoding="utf-8")
    assert sc.check(out=io.StringIO()) != 0


def test_show_warm_cache_reads_no_skill_bodies(tmp_path: Path) -> None:
    import io, unittest.mock
    _make_skill_tree(tmp_path)
    sc = catalog.SkillCatalog(tmp_path, cache_path=tmp_path / "cache.json")
    sc.update(out=io.StringIO())

    read_calls: list[str] = []
    original = Path.read_text

    def spy(self: Path, **kwargs):  # type: ignore[no-untyped-def]
        if self.name == "SKILL.md":
            read_calls.append(str(self))
        return original(self, **kwargs)

    with unittest.mock.patch.object(Path, "read_text", spy):
        sc.show(out=io.StringIO())

    assert read_calls == []
```

- [ ] **Step 2: Run to confirm failures**

```bash
uv run pytest tests/test_catalog_updater.py -v -k "validate or update or check or show_warm" 2>&1 | tail -10
```

Expected: `AttributeError: 'Catalog' object has no attribute 'validate'`

- [ ] **Step 3: Add `Catalog.validate` and complete `SkillCatalog`**

Add `validate` to the `Catalog` class:

```python
    @staticmethod
    def _check_shorthand(entry: CanonicalEntry) -> None:
        prefix = CATEGORIES[entry.category]
        initials = "".join(w[0] for w in entry.name.split("-") if w)
        if not entry.shorthand.startswith(prefix):
            raise InvalidShorthand(
                f"{entry.name}: shorthand '{entry.shorthand}' must start with '{prefix}'"
            )
        if not all(c in entry.shorthand for c in initials):
            raise InvalidShorthand(
                f"{entry.name}: shorthand '{entry.shorthand}' must contain initials '{initials}'"
            )

    @staticmethod
    def _register_aliases(
        entry: CanonicalEntry, seen_aliases: set[str], seen_names: set[str]
    ) -> None:
        for alias in entry.aliases:
            if alias in seen_aliases or alias in seen_names:
                raise DuplicateName(f"Duplicate alias: {alias}")
            if alias == entry.name:
                raise CatalogError(f"Alias '{alias}' equals canonical name")
            seen_aliases.add(alias)

    @staticmethod
    def _check_entry(
        entry: CanonicalEntry,
        seen_names: set[str],
        seen_shorthands: set[str],
        seen_aliases: set[str],
    ) -> None:
        if entry.name in seen_names:
            raise DuplicateName(f"Duplicate canonical name: {entry.name}")
        seen_names.add(entry.name)
        if entry.category not in CATEGORIES:
            raise UnknownCategory(f"{entry.name}: unknown category '{entry.category}'")
        Catalog._check_shorthand(entry)
        if entry.shorthand in seen_shorthands:
            raise DuplicateName(f"Duplicate shorthand: {entry.shorthand}")
        seen_shorthands.add(entry.shorthand)
        Catalog._register_aliases(entry, seen_aliases, seen_names)

    def validate(self) -> None:
        if not self.entries:
            raise EmptyScan("Catalog has zero canonical entries")
        seen_names: set[str] = set()
        seen_shorthands: set[str] = set()
        seen_aliases: set[str] = set()
        for entry in self.entries:
            self._check_entry(entry, seen_names, seen_shorthands, seen_aliases)
```

Add `_full_refresh`, `_update_stat_cache`, `update`, `check`, and complete `_show_slow` in `SkillCatalog`:

```python
    # -- Full refresh --------------------------------------------------------

    def _resolve_entry(
        self, skill_dir: Path, today: str, prev_by_name: dict[str, CanonicalEntry]
    ) -> CanonicalEntry:
        entry = CanonicalEntry.from_dir(skill_dir, today)
        prev = prev_by_name.get(entry.name)
        return (
            entry.with_updated(prev.updated)
            if prev and entry.semantic_hash == prev.semantic_hash
            else entry
        )

    def _full_refresh(self) -> tuple[Catalog, str]:
        from datetime import date as _date
        today = _date.today().isoformat()

        prev_catalog = Catalog.load(self.skills_root / CATALOG_FILENAME)
        prev_by_name = {e.name: e for e in prev_catalog.entries} if prev_catalog else {}

        entries = [
            self._resolve_entry(d, today, prev_by_name)
            for d in self._scan_canonical_dirs()
        ]
        new_catalog = Catalog.build(entries, today)
        new_catalog.validate()
        return new_catalog, new_catalog.render_toc()

    def _update_stat_cache(self, catalog_obj: Catalog) -> None:
        catalog_path = self.skills_root / CATALOG_FILENAME
        skill_dirs = self._scan_canonical_dirs()
        StatCache(
            schema_version=CACHE_SCHEMA_VERSION,
            agent_root=str(self.skills_root),
            catalog_hash=compute_content_hash(catalog_path.read_text(encoding="utf-8")),
            entries={f"{d.name}/SKILL.md": StatEntry.from_path(d) for d in skill_dirs},
        ).save(self.cache_path)

    def _publish(self, new_catalog: Catalog, toc_text: str) -> None:
        """Write aliases first, then catalog + TOC last (atomic sequence)."""
        self._write_generated_aliases(new_catalog, new_catalog.generated)
        self._retire_obsolete_aliases(new_catalog)
        new_catalog.save(self.skills_root / CATALOG_FILENAME)
        _atomic_write(self.skills_root / TOC_FILENAME, toc_text)

    def _show_slow(self, out) -> int:
        try:
            new_catalog, toc_text = self._full_refresh()
        except CatalogError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        self._publish(new_catalog, toc_text)
        self._update_stat_cache(new_catalog)
        out.write(toc_text)
        return 0

    # -- Public CLI commands -------------------------------------------------

    def update(self, out=None) -> int:
        if out is None:
            out = sys.stdout
        try:
            new_catalog, toc_text = self._full_refresh()
        except CatalogError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        self._publish(new_catalog, toc_text)
        self._update_stat_cache(new_catalog)
        out.write(toc_text)
        return 0

    def _catalog_issue(self, catalog_path: Path, new_catalog: Catalog) -> str | None:
        if not catalog_path.is_file():
            return "catalog.json is missing"
        actual = json.loads(catalog_path.read_text(encoding="utf-8"))
        expected = {
            "schema_version": new_catalog.schema_version,
            "generated": new_catalog.generated,
            "entries": [dataclasses.asdict(e) for e in new_catalog.entries],
            "generated_aliases": new_catalog.generated_aliases,
        }
        return "catalog.json is stale" if actual != expected else None

    def _toc_issue(self, toc_path: Path, expected_toc: str) -> str | None:
        if not toc_path.is_file():
            return "TOC.md is missing"
        return "TOC.md is stale" if toc_path.read_text(encoding="utf-8") != expected_toc else None

    def _alias_issue(self, alias: str) -> str | None:
        alias_dir = self.skills_root / alias
        if not (alias_dir / "SKILL.md").is_file():
            return f"Generated alias '{alias}' is missing"
        return None if is_generated_alias(alias_dir) else f"'{alias}' exists but lacks the generated marker"

    def check(self, out=None) -> int:
        if out is None:
            out = sys.stdout
        try:
            new_catalog, expected_toc = self._full_refresh()
        except CatalogError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        issues = [
            self._catalog_issue(self.skills_root / CATALOG_FILENAME, new_catalog),
            self._toc_issue(self.skills_root / TOC_FILENAME, expected_toc),
            *[self._alias_issue(a) for a in new_catalog.generated_aliases],
        ]
        real_issues = [i for i in issues if i is not None]
        if not real_issues:
            out.write("ok: catalog is current\n")
            return 0
        print("\n".join(f"drift: {i}" for i in real_issues), file=sys.stderr)
        return 1
```

Add the `main()` function and entry point after `SkillCatalog`:

```python
# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def _default_skills_root() -> Path:
    return Path(__file__).resolve().parent.parent.parent


def main() -> int:
    parser = ArgumentParser(
        description="SkillCatalog — validate and refresh secret-agents/skills"
    )
    parser.add_argument(
        "command", choices=["show", "update", "check"],
        help="show: fast refresh + print TOC; update: force full refresh; check: detect drift",
    )
    parser.add_argument("--skills-root", type=Path, default=None)
    args = parser.parse_args()
    skills_root: Path = args.skills_root or _default_skills_root()
    sc = SkillCatalog(skills_root)
    if args.command == "show":
        return sc.show()
    if args.command == "update":
        return sc.update()
    if args.command == "check":
        return sc.check()
    return 1


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 4: Add catalog.py to mypy `files` in `pyproject.toml`**

Find:
```toml
files = ["src", "tests", "skills/update-model-routing/scripts"]
```
Replace with:
```toml
files = ["src", "tests", "skills/update-model-routing/scripts", "skills/query-all-skills/scripts"]
```

- [ ] **Step 5: Run all catalog tests**

```bash
uv run pytest tests/test_catalog_updater.py -v 2>&1 | tail -30
```

Expected: all tests PASSED.

- [ ] **Step 6: Run mypy**

```bash
uv run mypy skills/query-all-skills/scripts/catalog.py 2>&1 | tail -15
```

Expected: no errors. Fix any type annotation issues before committing.

- [ ] **Step 7: Commit**

```bash
git add secret-agents/skills/query-all-skills/scripts/catalog.py secret-agents/tests/test_catalog_updater.py secret-agents/pyproject.toml
git commit -m "feat(catalog): complete Catalog.validate, SkillCatalog._full_refresh, show/update/check"
```

---

### Task 6: Repository drift guard

**Files:**
- Modify: `secret-agents/tests/test_catalog_updater.py`

**Interfaces:**
- Consumes: `SkillCatalog.check()` CLI (invoked as subprocess against real `skills/`)
- Produces: CI test that fails if any canonical header, alias, catalog.json, or TOC.md is missing or stale

*This test cannot pass until Tasks 7–10 are complete. Write it now so it fails loudly and drives the remaining work.*

- [ ] **Step 1: Write the drift guard test**

Append to `tests/test_catalog_updater.py`:

```python
def test_catalog_drift_guard() -> None:
    """CI guard: catalog.json, TOC.md, and all generated aliases must be current."""
    import subprocess
    result = subprocess.run(
        [sys.executable, str(CATALOG_SCRIPT), "check",
         "--skills-root", str(ROOT / "skills")],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        f"Catalog drift detected:\n{result.stderr}\n\n"
        "Fix: python skills/query-all-skills/scripts/catalog.py update\n"
        "Then commit the generated changes."
    )
```

- [ ] **Step 2: Run and confirm it fails (expected)**

```bash
uv run pytest tests/test_catalog_updater.py::test_catalog_drift_guard -v 2>&1 | tail -20
```

Expected: FAILED — `catalog check` reports missing canonical headers or missing skills.

- [ ] **Step 3: Commit the failing test**

```bash
git add secret-agents/tests/test_catalog_updater.py
git commit -m "test(catalog): add CI drift guard (expected failure until library is wired)"
```

---

### Task 7: Canonical metadata headers — all 19 existing canonical skills

**Files:**
- Modify: `secret-agents/skills/agent-plan/SKILL.md`
- Modify: `secret-agents/skills/clean-code-architecture-guards/SKILL.md`
- Modify: `secret-agents/skills/clean-code-error-handling/SKILL.md`
- Modify: `secret-agents/skills/jira-human-ticket-create/SKILL.md`
- Modify: `secret-agents/skills/python-quality-gate/SKILL.md`
- Modify: `secret-agents/skills/python-tdd-cycle/SKILL.md`
- Modify: `secret-agents/skills/report-receipt/SKILL.md`
- Modify: `secret-agents/skills/report-rollup/SKILL.md`
- Modify: `secret-agents/skills/report-status/SKILL.md`
- Modify: `secret-agents/skills/unreal-reset-build-env/SKILL.md`
- Modify: `secret-agents/skills/unreal-ugs-release/SKILL.md`
- Modify: `secret-agents/skills/update-claude-pricing-doc/SKILL.md`
- Modify: `secret-agents/skills/update-model-routing/SKILL.md`
- Modify: `secret-agents/skills/update-skills-readme/SKILL.md`
- Modify: `secret-agents/skills/ready-player-one/SKILL.md`

Note: `query-all-skills`, `install-skills`, `run-unit-tests`, `run-mac-coverage` are handled in Task 8 (new files). Skills with overlapping worky originals (`python-quality-gate`, `python-tdd-cycle`, `report-rollup`, `jira-human-ticket-create`, `update-skills-readme`) need content merges in Task 8; this task only adds the header line. `ready-player-one` gets full content replacement in Task 9.

**Interfaces:**
- Produces: every canonical SKILL.md has a `**Category:** ... · **Short:** ... · **Updated:** 2026-10-10 ...` line immediately after the H1.

- [ ] **Step 1: Understand the header contract**

The canonical header line appears as the first non-blank line after the H1:

```
**Category:** <category> · **Short:** <shorthand> · **Updated:** 2026-10-10[ · **Aliases:** <alias1>, <alias2>]
```

The complete header table:

| Canonical name | Header line |
|---|---|
| agent-plan | `**Category:** Agent Workflow · **Short:** ap · **Updated:** 2026-10-10` |
| clean-code-architecture-guards | `**Category:** Code Quality · **Short:** ccag · **Updated:** 2026-10-10 · **Aliases:** architecture-guards` |
| clean-code-error-handling | `**Category:** Code Quality · **Short:** cceh · **Updated:** 2026-10-10` |
| jira-human-ticket-create | `**Category:** Jira · **Short:** jhtc · **Updated:** 2026-10-10 · **Aliases:** jira-ht` |
| python-quality-gate | `**Category:** Code Quality · **Short:** cpqg · **Updated:** 2026-10-10` |
| python-tdd-cycle | `**Category:** Testing · **Short:** tptc · **Updated:** 2026-10-10` |
| query-all-skills | `**Category:** Query & Discovery · **Short:** qas · **Updated:** 2026-10-10` |
| report-receipt | `**Category:** Reporting · **Short:** rrec · **Updated:** 2026-10-10 · **Aliases:** work-receipt-create` |
| report-rollup | `**Category:** Reporting · **Short:** rrol · **Updated:** 2026-10-10` |
| report-status | `**Category:** Reporting · **Short:** rs · **Updated:** 2026-10-10 · **Aliases:** status-report-create` |
| install-skills | `**Category:** Skill Management · **Short:** sis · **Updated:** 2026-10-10` |
| update-skills-readme | `**Category:** Skill Management · **Short:** susr · **Updated:** 2026-10-10` |
| run-mac-coverage | `**Category:** Testing · **Short:** trmc · **Updated:** 2026-10-10` |
| run-unit-tests | `**Category:** Testing · **Short:** trut · **Updated:** 2026-10-10 · **Aliases:** rut` |
| unreal-reset-build-env | `**Category:** Unreal · **Short:** urbe · **Updated:** 2026-10-10 · **Aliases:** reset-unreal-build-environment` |
| unreal-ugs-release | `**Category:** Unreal · **Short:** uur · **Updated:** 2026-10-10 · **Aliases:** ugs-pcb-release` |
| update-claude-pricing-doc | `**Category:** Maintenance · **Short:** mucpd · **Updated:** 2026-10-10` |
| update-model-routing | `**Category:** Maintenance · **Short:** mumr · **Updated:** 2026-10-10` |
| ready-player-one | `**Category:** Preflight · **Short:** prpo · **Updated:** 2026-10-10 · **Aliases:** agent-preflight` |

- [ ] **Step 2: Add headers to the 8 non-overlapping canonical skills**

Read each file, find the H1 line, insert the header immediately after it (blank line between H1 and header, blank line after header before body).

Apply to: `agent-plan`, `clean-code-error-handling`, `report-receipt`, `report-status`, `unreal-reset-build-env`, `unreal-ugs-release`, `update-claude-pricing-doc`, `update-model-routing`

Example — `agent-plan/SKILL.md` H1 is `# Smart Plan`:
```
# Smart Plan

**Category:** Agent Workflow · **Short:** ap · **Updated:** 2026-10-10

Produce an execution plan...
```

- [ ] **Step 3: Add headers to overlapping skills (header only — content merge in Task 8)**

Apply header lines only to: `clean-code-architecture-guards`, `jira-human-ticket-create`, `python-quality-gate`, `python-tdd-cycle`, `report-rollup`, `update-skills-readme`

Note: `ready-player-one` is handled entirely in Task 9.

- [ ] **Step 4: Verify headers parse correctly**

```bash
cd C:/git/handbag-of-holding/secret-agents
python skills/query-all-skills/scripts/catalog.py check --skills-root skills 2>&1 | head -30
```

Expected: may report missing aliases and missing `query-all-skills`/`install-skills`/`run-unit-tests`/`run-mac-coverage` — that's fine. Must NOT report malformed headers on the files just edited.

- [ ] **Step 5: Commit**

```bash
git add secret-agents/skills/
git commit -m "feat(skills): add canonical metadata headers to 14 existing skills"
```

---

### Task 8: Import and merge source-only skills from worky

This task adds 4 new canonical skills and merges the overlapping ones.

**Files:**
- Create: `secret-agents/skills/query-all-skills/SKILL.md`
- Create: `secret-agents/skills/install-skills/SKILL.md`
- Create: `secret-agents/skills/run-unit-tests/SKILL.md`
- Create: `secret-agents/skills/run-mac-coverage/SKILL.md`
- Modify: `secret-agents/skills/clean-code-architecture-guards/SKILL.md`
- Modify: `secret-agents/skills/jira-human-ticket-create/SKILL.md`
- Modify: `secret-agents/skills/python-quality-gate/SKILL.md`
- Modify: `secret-agents/skills/python-tdd-cycle/SKILL.md`
- Modify: `secret-agents/skills/report-rollup/SKILL.md`
- Modify: `secret-agents/skills/update-skills-readme/SKILL.md`

**Note on dirty edits:** `python-quality-gate/SKILL.md` has uncommitted edits. Run `git diff secret-agents/skills/python-quality-gate/SKILL.md` first; merge worky behaviors into the dirty version, preserving all dirty edits.

**Merge rules (from spec §Skill merge and pruning rules):**
1. Inventory triggers, arguments, safety constraints, outputs, failure behavior, platform branches.
2. Keep the union of useful behaviors; keep the stricter safety rule.
3. Discard: stale absolute paths, copy-overwrite semantics, narrative history, duplicated procedures.

- [ ] **Step 1: Read source files before writing**

Read each source skill from worky:
- `C:/git/worky/worky/Agent/skills/query-all-skills/SKILL.md`
- `C:/git/worky/worky/Agent/skills/install-skills/SKILL.md`
- `C:/git/worky/worky/Agent/skills/run-unit-tests/SKILL.md`
- `C:/git/worky/worky/Agent/skills/run-mac-coverage/SKILL.md`
- `C:/git/worky/worky/Agent/skills/architecture-guards/SKILL.md`
- `C:/git/worky/worky/Agent/skills/jira-human-ticket-create/SKILL.md`
- `C:/git/worky/worky/Agent/skills/python-quality-gate/SKILL.md`
- `C:/git/worky/worky/Agent/skills/python-tdd-cycle/SKILL.md`
- `C:/git/worky/worky/Agent/skills/report-rollup/SKILL.md`
- `C:/git/worky/worky/Agent/skills/update-skills-readme/SKILL.md`

Read each target skill. Build a behavior checklist for each pair before writing.

- [ ] **Step 2: Write `query-all-skills/SKILL.md`**

Create `secret-agents/skills/query-all-skills/SKILL.md` with:
- Frontmatter `name: query-all-skills`, description from the source.
- H1: `# Query All Skills`
- Canonical header: `**Category:** Query & Discovery · **Short:** qas · **Updated:** 2026-10-10`
- Procedure that invokes `catalog show`:

```markdown
## Procedure

### Step 1 — Invoke the catalog

```bash
SKILL_DIR="<directory containing this SKILL.md>"
python3 "$SKILL_DIR/scripts/catalog.py" show --skills-root "$SKILL_DIR/.."
```

### Step 2 — Print the usage message

Immediately after the TOC output, print verbatim:

```
To see how to use any skill, run it with --help (most skills support this):
  /<skill-name> --help
```
```

- `--target <dir>` maps to `--skills-root <dir>` for backward compatibility.
- Discard: the old `list_skills.py` procedure.

- [ ] **Step 3: Write `install-skills/SKILL.md`**

Create `secret-agents/skills/install-skills/SKILL.md` with the CLI surface from spec:

```
install-skills [--all | <canonical-or-alias> ...] [--update]
               [--harness claude|codex|copilot|all | --target <directory>]
               [--help]
```

Procedure:
1. If `--update`: run `python3 "$SKILL_DIR/../query-all-skills/scripts/catalog.py" update --skills-root "$SKILL_DIR/.."`. If non-zero, abort.
2. Resolve install set from `catalog.json`.
3. Validate all destinations before any mutation (mark correct/will-create/conflict). Conflict → abort.
4. Create missing links using `secret-agents/src/secret_agents_setup/links.py`.
5. Report created and already-correct links.

Discard: copy-overwrite semantics, hard-coded Mac paths, `--source` flag.

- [ ] **Step 4: Write `run-unit-tests/SKILL.md`**

Copy source content; add header `**Category:** Testing · **Short:** trut · **Updated:** 2026-10-10 · **Aliases:** rut`; remove hardcoded worky paths; keep all flags, venv procedure, pytest + pre-commit steps, `--fix` cycle, `--help` block.

- [ ] **Step 5: Write `run-mac-coverage/SKILL.md`**

Copy source content; add header `**Category:** Testing · **Short:** trmc · **Updated:** 2026-10-10`; replace hardcoded absolute paths with `$TARGET`/`$PACKAGE` variables; keep all flags, paths table, all steps, `--help` block.

- [ ] **Step 6: Merge overlapping skills**

For `clean-code-architecture-guards`, `jira-human-ticket-create`, `python-tdd-cycle`, `report-rollup`: merge any behaviors present in the worky source but absent from the target. Keep all existing target content.

For `update-skills-readme`: keep the target's renderer contract; add the `review` argument behavior (regenerate Architect reviews) if missing from the target.

For `python-quality-gate`: run `git diff secret-agents/skills/python-quality-gate/SKILL.md` first. Merge worky behaviors into the dirty file without discarding dirty edits.

- [ ] **Step 7: Validate all skills parse correctly**

```bash
python skills/query-all-skills/scripts/catalog.py check --skills-root skills 2>&1 | head -40
```

Expected: 19 canonical skills detected; errors only about missing generated aliases and catalog/TOC (normal at this stage).

- [ ] **Step 8: Commit**

```bash
git add secret-agents/skills/
git commit -m "feat(skills): import source-only skills and merge overlapping canonical skills"
```

---

### Task 9: Rewrite `ready-player-one` and convert human-authored compat aliases to generated

**Files:**
- Modify: `secret-agents/skills/ready-player-one/SKILL.md`
- Delete: `secret-agents/skills/agent-preflight/` (human-authored — will be regenerated)
- Delete: `secret-agents/skills/jira-ht/` (human-authored — will be regenerated)

- [ ] **Step 1: Read both sources**

Read:
- `C:/git/worky/worky/Agent/skills/ready-player-one/SKILL.md` (full implementation)
- `secret-agents/skills/ready-player-one/SKILL.md` (currently a stub that forwards to `agent-preflight`)
- `secret-agents/docs/specs/2026-08-30-ready-player-one-design.md` (approved design)

Verify the worky source matches the approved design. Note any gaps.

- [ ] **Step 2: Replace `ready-player-one/SKILL.md`**

Write the full preflight content with:
- Frontmatter: `name: ready-player-one`, description per the spec trigger condition.
- H1: `# Ready Player One`
- Canonical header: `**Category:** Preflight · **Short:** prpo · **Updated:** 2026-10-10 · **Aliases:** agent-preflight`
- Full preflight procedure from worky source (harness detection, OS detection, per-harness checks, binary output).
- Discard: the old forwarding stub.

- [ ] **Step 3: Delete human-authored compat alias directories**

```bash
cd C:/git/handbag-of-holding/secret-agents
git rm -r skills/agent-preflight/ skills/jira-ht/
```

- [ ] **Step 4: Verify ready-player-one parses**

```bash
python skills/query-all-skills/scripts/catalog.py check --skills-root skills 2>&1 | head -20
```

Expected: `ready-player-one` parses without error; `agent-preflight` and `jira-ht` reported as missing generated aliases (fixed in Task 10).

- [ ] **Step 5: Commit**

```bash
git add secret-agents/skills/ready-player-one/SKILL.md
git commit -m "feat(skills): replace ready-player-one stub with full implementation; remove human-authored compat aliases"
```

---

### Task 10: Generate the initial catalog, TOC, and all alias directories

**Files:**
- Create: `secret-agents/skills/catalog.json` (generated)
- Create: `secret-agents/skills/TOC.md` (generated)
- Create: all 19 shorthand alias dirs and 8 compat alias dirs (generated)

- [ ] **Step 1: Run catalog update**

```bash
cd C:/git/handbag-of-holding/secret-agents
python skills/query-all-skills/scripts/catalog.py update --skills-root skills
```

Expected: categorized TOC printed; `catalog.json`, `TOC.md`, and 27 alias directories created.

- [ ] **Step 2: Inspect output**

```bash
cat skills/TOC.md
ls skills/ | sort
```

Verify: 19 canonical dirs; 19 shorthand dirs (`ap`, `ccag`, `cceh`, `cpqg`, `jhtc`, `mucpd`, `mumr`, `prpo`, `qas`, `rrec`, `rrol`, `rs`, `sis`, `susr`, `tptc`, `trmc`, `trut`, `urbe`, `uur`); 8 compat dirs (`agent-preflight`, `architecture-guards`, `jira-ht`, `reset-unreal-build-environment`, `rut`, `status-report-create`, `ugs-pcb-release`, `work-receipt-create`). No generated alias has an independent TOC entry.

- [ ] **Step 3: Run drift guard**

```bash
python skills/query-all-skills/scripts/catalog.py check --skills-root skills
```

Expected: `ok: catalog is current`

- [ ] **Step 4: Run catalog unit tests**

```bash
uv run pytest tests/test_catalog_updater.py -v 2>&1 | tail -20
```

Expected: all tests PASSED including `test_catalog_drift_guard`.

- [ ] **Step 5: Commit generated artifacts**

```bash
git add secret-agents/skills/
git commit -m "feat(catalog): generate initial catalog.json, TOC.md, and all alias directories"
```

---

### Task 11: Wire query-all-skills and update-skills-readme to catalog commands

**Files:**
- Modify: `secret-agents/skills/query-all-skills/SKILL.md` — verify it invokes `catalog show`
- Modify: `secret-agents/skills/update-skills-readme/SKILL.md` — add catalog `update` invocation

- [ ] **Step 1: Verify `query-all-skills/SKILL.md` invokes `catalog show`**

Read `secret-agents/skills/query-all-skills/SKILL.md` (written in Task 8). Confirm the procedure calls `catalog.py show`. If it still references `list_skills.py`, replace with the catalog invocation.

- [ ] **Step 2: Add catalog update step to `update-skills-readme/SKILL.md`**

Read the file. Add a new Step 0 before the current Step 1:

```markdown
### Step 0 — Refresh the catalog

```bash
SKILL_DIR="<directory containing this SKILL.md>"
python3 "$SKILL_DIR/../query-all-skills/scripts/catalog.py" update --skills-root "$SKILL_DIR/.."
```

If the command exits non-zero, print the error and stop.
```

Renumber subsequent steps. In the Inventory step, update to source from `catalog.json` for canonical skills; add a note that directories with a `<!-- generated: -->` marker are generated aliases and do not get independent `### <name>` README sections.

- [ ] **Step 3: Commit**

```bash
git add secret-agents/skills/query-all-skills/SKILL.md secret-agents/skills/update-skills-readme/SKILL.md
git commit -m "feat(skills): wire query-all-skills and update-skills-readme to catalog commands"
```

---

### Task 12: Rewrite install-skills for create-only link semantics and --update

**Files:**
- Modify: `secret-agents/skills/install-skills/SKILL.md`

- [ ] **Step 1: Read `install-skills/SKILL.md` from Task 8**

Read `secret-agents/skills/install-skills/SKILL.md`. Verify the procedure matches the spec exactly.

- [ ] **Step 2: Verify or complete the procedure**

The procedure must cover the 5-step flow from Task 8 Step 3 verbatim. Confirm:
- `--update` triggers `catalog update` first, abort on non-zero.
- Install set resolved from `catalog.json` `generated_aliases`.
- Validate-before-mutate: correct/will-create/conflict per destination.
- Create-only links via `links.py`.
- Report created and already-correct.

- [ ] **Step 3: Update --help block**

```
install-skills — install agent skills as discoverable links

Usage:
  /install-skills                           Install all skills (harness: all)
  /install-skills --all                     Same as above
  /install-skills run-unit-tests rut        Install only the named skills (and their aliases)
  /install-skills --update                  Refresh catalog, then install all
  /install-skills --harness claude          Install into claude harness directory
  /install-skills --harness all             Install into all harness directories (default)
  /install-skills --target <dir>            Install into an explicit directory
  /install-skills --help                    Show this help

Behavior:
  - Resolves aliases to canonical skills automatically
  - Create-only: never overwrites an existing link pointing elsewhere
  - Missing named skills abort before any mutation
  - --target and --harness are mutually exclusive
```

- [ ] **Step 4: Commit**

```bash
git add secret-agents/skills/install-skills/SKILL.md
git commit -m "feat(skills): complete install-skills create-only semantics and catalog integration"
```

---

### Task 13: README reconciliation and final gate

**Files:**
- Modify: `secret-agents/skills/README.md`
- Modify: `secret-agents/skills/update-skills-readme/scripts/render_html.py`
- Modify: `secret-agents/tests/test_skills_readme.py`

- [ ] **Step 1: Read current state**

```bash
git diff secret-agents/skills/README.md
git diff secret-agents/skills/update-skills-readme/scripts/render_html.py
```

Run the renderer to see current failures:

```bash
uv run python skills/update-skills-readme/scripts/render_html.py 2>&1
```

- [ ] **Step 2: Update `render_html.py` to skip generated aliases**

Find `skill_directories()` or equivalent. Add the generated-alias filter before returning:

```python
import re as _re
_GENERATED_RE = _re.compile(r"<!-- generated:[a-z][a-z0-9-]*:\d{4}-\d{2}-\d{2} -->")

def _is_generated_alias(skill_dir: Path) -> bool:
    skill_file = skill_dir / "SKILL.md"
    if not skill_file.is_file():
        return False
    return bool(_GENERATED_RE.search(skill_file.read_text(encoding="utf-8")))
```

Filter generated aliases out of `skill_directories()`.

- [ ] **Step 3: Update `README.md`**

1. Update generated date.
2. Add sections for `query-all-skills`, `install-skills`, `run-unit-tests`, `run-mac-coverage`.
3. Update `ready-player-one` section (full preflight, not forwarding stub).
4. Add a note pointing to `TOC.md` for the categorized shorthand listing.
5. Preserve all `**Architect's review.**` blocks verbatim.
6. Preserve all dirty edits not in conflict with the above.

- [ ] **Step 4: Run the renderer**

```bash
uv run python skills/update-skills-readme/scripts/render_html.py
```

Expected: exits 0 with `verified:` line. Fix dead anchors or missing sections if needed.

- [ ] **Step 5: Run the full test suite**

```bash
uv run pytest tests/ -v 2>&1 | tail -40
```

Expected: all tests PASSED including `test_catalog_drift_guard`.

- [ ] **Step 6: Run mypy and ruff**

```bash
uv run mypy 2>&1 | tail -20
uv run ruff check src tests skills/update-model-routing/scripts skills/query-all-skills/scripts
uv run ruff format --check src tests skills/update-model-routing/scripts skills/query-all-skills/scripts
```

Fix any errors before continuing.

- [ ] **Step 7: Final integration smoke test**

```bash
python skills/query-all-skills/scripts/catalog.py show --skills-root skills
```

Expected: prints the categorized TOC without reading any SKILL.md bodies (warm cache).

- [ ] **Step 8: Commit**

```bash
git add secret-agents/skills/README.md secret-agents/skills/README.html secret-agents/skills/update-skills-readme/scripts/render_html.py secret-agents/tests/test_skills_readme.py
git commit -m "feat(skills): reconcile README with generated aliases; all tests passing"
```

---

## Discarded source behaviors (per spec §4)

| Source behavior | Reason discarded |
|---|---|
| `install-skills` copy-overwrite semantics | Incompatible with multi-machine link model; replaced by create-only |
| `install-skills` hard-coded Mac source path | Machine-specific; target uses relative paths |
| `install-skills --source` flag | Skills root is always the catalog root |
| `qas` `list_skills.py` script | Replaced by `SkillCatalog.show()` via `catalog show` |
| `ready-player-one` stub forwarding to `agent-preflight` | Inverted the dependency; canonical is now `ready-player-one` |
| Human-authored `agent-preflight` and `jira-ht` directories | Replaced by catalog-generated equivalents |
