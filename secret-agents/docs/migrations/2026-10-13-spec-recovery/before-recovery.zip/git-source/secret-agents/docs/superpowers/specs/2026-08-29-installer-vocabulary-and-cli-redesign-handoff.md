# Installer Vocabulary & CLI Readability — Discussion Summary & Handoff

**Date:** 2026-08-29
**Status:** Exploratory design discussion. **No decisions were finalized.** This captures the problems raised, the options weighed, and the current *leanings* (explicitly tentative) so a future session can continue and actually decide — with the user.
**Repo:** `handbag-of-holding/secret-agents` · **Branch:** Batch 3 is on `batch-3-rollback-execution-and-cli` (PR #3 → `main`).

---

## Context (brief)
`secret-agents` is a stdlib Python installer that links this repo's shared agent guidance (`AGENTS.md`) and skills into each AI harness's discovery directories (Claude Code, Codex, Copilot) — links, never copies — with install/check/uninstall, rollback, and an ownership receipt. Batch 3 (execution + CLI) just shipped in PR #3; 123 tests green. The discussion below is a code review of that result; it is **not** an approved design.

## Problems raised (the substance of the discussion)
1. **`cli.py` is a "bag of tricks."** It fuses argument parsing, input wiring, command orchestration, *and* all output + exit-code emission in one module.
2. **The module doesn't communicate its purpose.** A dev in a hurry can't latch onto what it does beyond "a CLI for install/uninstall of something."
3. **Names don't self-document.** The code must speak for itself; a docstring you're forced to read means the code failed, and docstrings go stale — so comments don't count as the fix.
4. **`Projection` is actively misleading.** It's a graphics/geometry term (casting an image onto a surface); a reader must translate it before using it, and it fights its traditional meaning.
5. **`_Session` implies an evolving lifecycle** but is a frozen, single-shot bag of resolved inputs — nothing changes mid-use.
6. **The rot is deeper than one noun.** The surrounding structural names (`Kind`, `Plan`, `Finding`) also fail to communicate, so bolting the new noun onto them (`MirrorKind`, `plan_mirrors`, `finding.mirror`) doesn't fix anything.

## Shared conclusions (things we did agree on — principles, not implementations)
- Code communicates through **names and structure**, not docstrings.
- A name must **read like a plain sentence**; avoid metaphors that fight established meanings (graphics/geometry like *projection*/*render*; introspection like *reflection*).
- **`Kind` is acceptable only when it enumerates genuine variants** (e.g. a step being create/replace/backup) and wrong as an empty modifier ("a kind of mirror").
- Any change here must be a **behavior-preserving refactor**: identical stdout/stderr, identical exit codes, all 123 tests green.

## Directions explored — NOTHING DECIDED

### Core noun to replace `Projection`
Weighed and set aside, with reasons: `Link`/`DiscoveryLink` (names the mechanism, not the intent), `Mount` (implies a kernel/volume mount), `Registration` (a fib — there's no registry API), `Placement`/`InstallTarget`/`target` (generic, "still not great"), `Reflection` (a loaded programming term = runtime introspection; fights its meaning like *projection* does), `sync`/`publish` (verb-first, awkward as a noun; *publish* implies producing a copy).
- **Current leaning:** `Mirror` (long tech lineage — mirror sites, disk/RAID mirroring, mirrored repos = "same content available elsewhere"). **Not ratified** — the user favored it but kept probing (e.g. why not *reflection*), so treat it as a leaning, not a decision.
- **Caveat if adopted:** "mirror" can suggest a *refreshed copy*; we use one live link. Mitigate by keeping the mechanism layer explicitly link-named (a mirror is realized as a symlink/junction by `LinkBackend`).

### The derived / structural vocabulary (the unsolved part)
- First attempt — `MirrorKind`, `plan_mirrors()`, `finding.mirror` — **rejected** as not communicating.
- Second attempt was *proposed but not accepted*: `Content` (skills vs guidance), `desired_mirrors()` (the wanted set), `inspect()` → `Plan`, `Finding`→`Status`, `FindingState`→`State`, `PlannedAction`→`Step`, `ActionKind`→`StepKind`. The user then questioned whether `Kind`/`Plan`/`Finding` communicate at all. **This is the main open problem** — it needs a fresh pass, not acceptance of that table.

### CLI structure
- Options weighed: (a) commands compute and **return a plain result value**, and **one unit owns all text + the outcome→exit-code map**; (b) extract a writer but call it inline from commands; (c) just split the file, keep the style.
- **Current leaning:** (a) — but this came from a quick pick, not a ratified design. The writer's name, and whether presentation becomes its own file, are undecided. "Renderer" was rejected as a graphics word.

### `_Session` rename
- Candidates floated: `Invocation`, `RunContext`, `Request`. Undecided.

## Open questions still to decide
- Confirm (or reject) `Mirror` as the core noun.
- A **structural vocabulary that reads like sentences** — the hard, unsolved part.
- Names for: the old `_Session`, the output-writer unit (no graphics words), the result value/outcome type.
- Whether to rename the term inside the **approved** spec `2026-08-28-harness-setup-design.md` (it uses "projection") or keep it with a glossary.
- Which branch and when, relative to PR #3.
- Blast-radius + sequencing — never presented.

## Constraints & guardrails
- Pure refactor; behavior/output/exit-codes identical; tests stay green.
- Follow AGENTS.md: functions read like prose; classes only where state is owned (`_Transaction`/`_InstallRun`/`_UninstallRun`) or substitutable (`LinkBackend`) — no god-object `Installer`; presentation boundary owns exit codes; programmer errors (applying a blocked plan) fail fast, untranslated.
- **Do not touch** four unrelated, pre-existing working-tree edits (`AGENTS.md`, `skills/README.md`, `skills/README.html`, `skills/python-quality-gate/SKILL.md`) or untracked `src/secret_agents_setup.egg-info/` — they came from harness/skill sync mid-session and are excluded from PR #3.
- This is an **architectural brainstorm that isn't finished.** Decide the design (and update/adjust the spec) **before** writing code.

## Codex resume prompt

```text
Continue an UNFINISHED, exploratory design discussion about the installer subsystem in
handbag-of-holding/secret-agents. Nothing has been decided — do not treat prior leanings as
settled. The goal is a behavior-preserving refactor for readability: identical stdout/stderr
and exit codes, all 123 tests green.

Read first:
1. secret-agents/docs/superpowers/specs/2026-08-29-installer-vocabulary-and-cli-redesign-handoff.md
   (this summary: problems raised, options weighed, current leanings, open questions)
2. secret-agents/AGENTS.md
3. secret-agents/src/secret_agents_setup/cli.py, models.py, planning.py, harness_profiles.py
4. secret-agents/docs/superpowers/specs/2026-08-28-harness-setup-design.md (uses "projection")

Problems to solve (agreed): cli.py mixes parsing/orchestration/output; the module and its
names don't self-document; `Projection` (graphics term) and `_Session` (implies a lifecycle)
mislead; and the structural names (`Kind`/`Plan`/`Finding`) don't communicate either.

Agreed principles: names must read like plain sentences; no metaphors that fight established
meanings (projection/render/reflection); `Kind` only for real variant sets; behavior-preserving.

Leanings to re-confirm or reject WITH the user (not decisions): core noun `Mirror`; CLI
commands return a result value while one unit owns text + exit-code mapping.

Do this, one question at a time, and DO NOT write code until the user approves a design:
1. Settle the core noun.
2. Solve the hard part — a structural vocabulary (the old Kind/Plan/Finding/Action/Session and
   the new output-writer + result type) where every name reads like a sentence. Prior tries
   (MirrorKind, plan_mirrors, finding.mirror) were rejected; a proposed Content/inspect/Plan/
   Status/State/Step set was NOT accepted.
3. Settle the CLI structure and the output-writer/result-type names.
4. Present blast radius + sequencing (files, whether to rename in the approved spec, branch).
5. Update the spec, then use the writing-plans skill for an implementation plan.
```
