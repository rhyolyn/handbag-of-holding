# ready-player-one Rewrite Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the model-driven `agent-preflight` + `ready-player-one` alias pair with a single thin `SKILL.md` that delegates checks 0-3 and 5-7 to a Python stdlib script (`preflight.py`), producing a binary `ready` / `NOT READY` verdict before expensive batched prompts.

**Architecture:** `preflight.py` is one self-contained file, but it is not a procedural helper pile. It is a nominal, object-oriented preflight module: `PreflightApplication` owns the CLI flow, `EnvironmentBootstrapper` owns context construction, `CheckSuite` enforces ordered policy, `ReadinessCheck` subclasses own each check, `HarnessProfile` subclasses own harness-specific behavior, `OperatingSystemProfile` subclasses own OS-specific behavior, and `LinkManager` owns create-only link semantics. The model owns check 4 because only the active session can see session-visible skills.

**Tech Stack:** Python 3.11+ stdlib only (`abc`, `dataclasses`, `enum.StrEnum`, `json`, `pathlib`, `subprocess`, `tomllib`); pytest for tests; no imports from `secret_agents_setup` or any `secret-agents/src` package.

**Spec:** `secret-agents/docs/specs/2026-08-30-ready-player-one-design.md`

## Scope

This plan covers spec items 1-2: the `ready-player-one` rewrite and `packs.json`. `update-agent-stack` is a separate plan.

## Global Constraints

- `preflight.py` uses Python 3.11+ stdlib only: no third-party imports, no imports from `secret_agents_setup`, no imports from `secret-agents/src`.
- Use nominal abstract base classes (`abc.ABC`) for polymorphic extension points: checks, harnesses, OS profiles, and command runners all inherit from named base classes.
- Harness variation lives in `HarnessProfile` subclasses. A check asks the profile for behavior; it does not switch on `"claude"` / `"codex"` except inside the detector/factory that selects the profile.
- OS variation lives in `OperatingSystemProfile` subclasses. Link detection, manual command text, and uv remediation belong there.
- `PreflightContext` is immutable and carries objects with behavior (`HarnessProfile`, `OperatingSystemProfile`, `PreflightPaths`, `PackManifest`, `LinkManager`, `PreflightOptions`), not loose strings and duplicated paths.
- A check returns a `CheckResult`. It never mutates caller-owned lists.
- Link behavior returns typed `LinkOutcome` values. Callers never parse message text to decide whether a link is missing, conflicting, or created.
- `--no-fix` disables all autofixes.
- Windows per-skill links are symlinks only: no copy, junction, or hard-link fallbacks. If symlinks cannot be created, return a clear capability failure.
- Junction detection on Windows uses `os.lstat().st_reparse_tag == 0xA0000003`; never treat `Path.is_symlink()` as sufficient for junctions.
- Link creation is create-only: never overwrite an existing link or file, even if its target is wrong. Report the conflict.
- A failed link creation must not leave a partial link. Cleanup failure may be included in the diagnostic but must not replace the original failure.
- Check 4 is model-performed from `SKILL.md`; it is not implemented in `preflight.py`.
- All checks run offline. `preflight.py` makes no network calls.
- A harness or component absent from this machine is a skip (`Status.SKIP`), not a failure.
- Comments are a last resort. Prefer names and class boundaries that make call sites read clearly.

## File Structure

```
secret-agents/
  packs.json
  skills/
    ready-player-one/
      SKILL.md
      preflight.py
      tests/
        conftest.py
        test_preflight.py
    agent-preflight/
      SKILL.md
```

## Architecture Contract

`preflight.py` must be organized in this order so the first screen tells the story:

1. Constants, enums, and immutable value objects.
2. `PreflightApplication`, `EnvironmentBootstrapper`, `CheckSuite`, and `ReadinessSummary`.
3. `ReadinessCheck` subclasses in execution order.
4. Harness profile classes.
5. OS profile classes.
6. Infrastructure classes (`LinkManager`, settings/config readers, version cache, uv runner).
7. CLI helpers and `main()`.

Primary call path:

```python
def main(argv: list[str] | None = None) -> int:
    return PreflightApplication.from_cli(argv).run()
```

The implementation should read like this:

```python
class PreflightApplication:
    def run(self) -> int:
        bootstrap = self.bootstrapper.bootstrap()
        results = [bootstrap.result]
        if bootstrap.context is not None:
            results.extend(self.checks.run_all(bootstrap.context))
        return self.reporter.report(ReadinessSummary(results))
```

Every task preserves `CheckSuite.default()` as the ordered policy surface.

## Batch Execution Guide

Four batches. Start each in a fresh session using the handoff prompt below. The prompt gives the agent the exact task range to read.

| Batch | Model | Tasks | Produces |
|-------|-------|-------|----------|
| 1 | Sonnet | 1-2 | `packs.json`, nominal OO scaffold, CLI reporter, two smoke tests |
| 2 | Sonnet | 3-5 | bootstrap, manifest model, vault purity, OS profiles, link manager |
| 3 | Sonnet | 6-8 | harness profiles, link layout, foreign packs, permission/trust |
| 4 | Opus | 9-10 | version cache, uv, integration test, thin `SKILL.md`, cleanup, README |

### Batch 1 Handoff

```
You are executing Batch 1 of the ready-player-one rewrite.
Working directory: c:\git\handbag-of-holding
Plan file: secret-agents/docs/plans/2026-08-30-ready-player-one-rewrite.md
Execute Tasks 1-2 only. Read from `### Task 1:` through the divider before `### Task 3:`.

Constraints:
- Build the nominal OO scaffold exactly; `CheckSuite.default()` remains the ordered policy surface.
- Python 3.11+ stdlib only in preflight.py.
- Do not import secret_agents_setup or any code from secret-agents/src.
- Test must reach 2 PASS before committing Task 2.
```

### Batch 2 Handoff

```
You are executing Batch 2 of the ready-player-one rewrite.
Working directory: c:\git\handbag-of-holding
Plan file: secret-agents/docs/plans/2026-08-30-ready-player-one-rewrite.md
Execute Tasks 3-5 only. Read from `### Task 3:` through the divider before `### Task 6:`.

Prior state:
- packs.json exists and parses.
- preflight.py contains the nominal OO scaffold from Task 2.
- CheckSuite.default() currently returns an empty ordered suite.

Constraints:
- Keep state ownership on classes. Do not add module-level helper families for bootstrap, manifest, or links.
- LinkManager returns LinkOutcome values, never str-or-None.
- Windows junction detection uses os.lstat().st_reparse_tag == 0xA0000003.
- Each task: failing test, verify fail, implement, verify pass, commit.
```

### Batch 3 Handoff

```
You are executing Batch 3 of the ready-player-one rewrite.
Working directory: c:\git\handbag-of-holding
Plan file: secret-agents/docs/plans/2026-08-30-ready-player-one-rewrite.md
Execute Tasks 6-8 only. Read from `### Task 6:` through the divider before `### Task 9:`.

Prior state:
- EnvironmentBootstrapper, PackManifest, VaultPurityCheck, OperatingSystemProfile subclasses, and LinkManager are implemented and tested.
- CheckSuite.default() contains VaultPurityCheck.

Constraints:
- Harness-specific link requirements, foreign-pack checks, and trust checks belong to HarnessProfile subclasses.
- Check classes delegate to profiles; they do not switch on harness names.
- Claude global defaultMode must be bypassPermissions. Project settings may accept dontAsk or bypassPermissions.
- Each task: failing test, verify fail, implement, verify pass, commit.
```

### Batch 4 Handoff

```
You are executing Batch 4 of the ready-player-one rewrite.
Working directory: c:\git\handbag-of-holding
Plan file: secret-agents/docs/plans/2026-08-30-ready-player-one-rewrite.md
Execute Tasks 9-10 only. Read from `### Task 9:` through the end of the file.

Prior state:
- Checks 1, 2, 3, and 5 are implemented through nominal classes.
- CheckSuite.default() contains VaultPurityCheck, LinkLayoutCheck, ForeignPacksCheck, and PermissionTrustCheck.

Constraints:
- Check 6 is never a failure; stale or missing cache is a warning.
- Check 7 skips when no pyproject.toml or uv.lock exists at the project root.
- The integration test runs the real script with --json --no-fix.
- Rewrite SKILL.md as a thin contract and delete agent-preflight/.
```

---

### Task 1: packs.json

**Files:**
- Create: `secret-agents/packs.json`

**Interfaces:**
- Produces manifest consumed by `PackManifest.load_from(vault_path: Path)`.
- Schema: `{pack_name: {source?, install: {claude, codex, copilot}, expect: "*" | string[]}}`.
- `mine.expect: "*"` means every direct child directory of `<vault>/secret-agents/skills`.

- [ ] **Step 1: Write packs.json**

```json
{
  "mine": {
    "source": "vault-skills-dir",
    "expect": "*"
  },
  "superpowers": {
    "install": {
      "claude": "/plugin install superpowers (marketplace: claude-plugins-official)",
      "codex": "/plugins -> search superpowers -> install",
      "copilot": "copilot plugin install superpowers@superpowers-marketplace"
    },
    "expect": [
      "brainstorming", "dispatching-parallel-agents", "executing-plans",
      "finishing-a-development-branch", "receiving-code-review", "requesting-code-review",
      "subagent-driven-development", "systematic-debugging", "test-driven-development",
      "using-git-worktrees", "using-superpowers", "verification-before-completion",
      "writing-plans", "writing-skills"
    ]
  },
  "mattpocock-skills": {
    "install": {
      "claude": "/plugin install mattpocock-skills",
      "codex": "npx skills@latest add mattpocock/skills",
      "copilot": "npx skills@latest add mattpocock/skills"
    },
    "expect": [
      "architecture-guards", "ask-matt", "claude-handoff", "code-review",
      "codebase-design", "diagnosing-bugs", "domain-modeling", "find-skills",
      "git-guardrails-claude-code", "grill-me", "grill-with-docs", "grilling",
      "handoff", "implement", "implement-spec", "improve-codebase-architecture",
      "loop-me", "migrate-to-shoehorn", "prototype", "research",
      "resolving-merge-conflicts", "retro", "scaffold-exercises", "setup-pre-commit",
      "setup-ts-deep-modules", "tdd", "teach", "to-questionnaire", "to-spec",
      "to-tickets", "triage", "wait-what", "wayfinder", "wizard",
      "work-receipt-create", "writing-beats", "writing-for-agents",
      "writing-fragments", "writing-shape"
    ]
  }
}
```

- [ ] **Step 2: Validate JSON parses**

```bash
python -c "import json; d=json.load(open('secret-agents/packs.json')); print(d['superpowers']['expect'][:3])"
```

Expected: `['brainstorming', 'dispatching-parallel-agents', 'executing-plans']`

- [ ] **Step 3: Commit**

```bash
git add secret-agents/packs.json
git commit -m "feat: add packs.json manifest for preflight skill-diff"
```

---

### Task 2: Nominal OO scaffold + test infrastructure

**Files:**
- Create: `secret-agents/skills/ready-player-one/preflight.py`
- Create: `secret-agents/skills/ready-player-one/tests/conftest.py`
- Create: `secret-agents/skills/ready-player-one/tests/test_preflight.py`

**Interfaces:**
- Produces:
  - `Status(StrEnum)`
  - `HarnessName(StrEnum)`
  - `OperatingSystemName(StrEnum)`
  - `CheckResult`
  - `PreflightOptions`
  - `PreflightPaths`
  - `PackManifest`
  - `PreflightContext`
  - `BootstrapResult`
  - `ReadinessSummary`
  - `ConsoleReporter`
  - `ReadinessCheck(ABC)`
  - `HarnessProfile(ABC)` with `ClaudeProfile`, `CodexProfile`, `CopilotProfile`
  - `OperatingSystemProfile(ABC)` with `WindowsProfile`, `MacProfile`, `LinuxProfile`
  - `LinkManager`
  - `CheckSuite`
  - `EnvironmentBootstrapper`
  - `PreflightApplication`
  - `parse_args(argv)` and `main(argv)`

- [ ] **Step 1: Write failing smoke tests**

```python
import dataclasses
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPT = Path(__file__).parent.parent / "preflight.py"
PYTHON = sys.executable


def _run(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run([PYTHON, str(SCRIPT), *args], capture_output=True, text=True)


def test_script_accepts_no_fix_flag() -> None:
    result = _run("--no-fix", "--json")
    assert result.returncode in (0, 1)


def test_json_output_contains_verdict_and_checks() -> None:
    result = _run("--json", "--no-fix")
    match = re.search(r"```json\n(.*?)```", result.stdout, re.DOTALL)
    assert match, f"No JSON block in:\n{result.stdout}"
    data = json.loads(match.group(1))
    assert data["verdict"] in ("ready", "NOT READY")
    assert type(data["checks"]) is list
```

- [ ] **Step 2: Run and verify FAIL**

```bash
cd secret-agents/skills/ready-player-one
python -m pytest tests/test_preflight.py -v
```

Expected: FAIL because `preflight.py` does not exist.

- [ ] **Step 3: Write conftest.py**

```python
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
```

- [ ] **Step 4: Write preflight.py scaffold**

```python
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import dataclasses
import json
import os
import platform
import subprocess
import sys
import tempfile
import tomllib
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any

AGENT_ROOT_SUBDIR = "secret-agents"
MANIFEST_NAME = "packs.json"
VERSION_CACHE_MAX_AGE_DAYS = 7
JUNCTION_REPARSE_TAG = 0xA0000003


class Status(StrEnum):
    PASS = "✅"
    FAIL = "❌"
    SKIP = "⏭️"
    WARN = "⚠️"


class HarnessName(StrEnum):
    CLAUDE = "claude"
    CODEX = "codex"
    COPILOT = "copilot"


class OperatingSystemName(StrEnum):
    WINDOWS = "win"
    MAC = "mac"
    LINUX = "lin"


@dataclasses.dataclass(frozen=True)
class CheckResult:
    num: int
    status: Status
    message: str
    autofixes: tuple[str, ...] = ()
    remediations: tuple[str, ...] = ()

    def to_line(self) -> str:
        return f"{self.status.value} Check {self.num}: {self.message}"

    def to_json(self) -> dict[str, object]:
        return {
            "num": self.num,
            "status": self.status.value,
            "message": self.message,
            "autofixes": list(self.autofixes),
            "remediations": list(self.remediations),
        }


@dataclasses.dataclass(frozen=True)
class PreflightOptions:
    no_fix: bool
    json_out: bool


@dataclasses.dataclass(frozen=True)
class PreflightPaths:
    home: Path
    cwd: Path
    vault: Path

    @property
    def pointer_file(self) -> Path:
        return self.home / ".agents" / "root"

    @property
    def agent_root(self) -> Path:
        return self.vault / AGENT_ROOT_SUBDIR

    @property
    def vault_skills(self) -> Path:
        return self.agent_root / "skills"

    @property
    def agents_skills(self) -> Path:
        return self.home / ".agents" / "skills"

    @property
    def claude_dir(self) -> Path:
        return self.home / ".claude"

    @property
    def codex_dir(self) -> Path:
        return self.home / ".codex"

    @property
    def versions_cache(self) -> Path:
        return self.home / ".agents" / "versions.json"


@dataclasses.dataclass(frozen=True)
class Pack:
    name: str
    install_by_harness: dict[str, str]
    expected_skill_names: tuple[str, ...]
    expects_all_vault_skills: bool = False

    @property
    def is_mine(self) -> bool:
        return self.name == "mine"

    def install_command_for(self, harness: HarnessName) -> str:
        return self.install_by_harness.get(harness.value, f"see packs.json for {self.name}")


@dataclasses.dataclass(frozen=True)
class PackManifest:
    found: bool
    packs: tuple[Pack, ...] = ()

    @classmethod
    def missing(cls) -> PackManifest:
        return cls(found=False)

    @classmethod
    def from_document(cls, document: dict[str, Any]) -> PackManifest:
        packs: list[Pack] = []
        for name, config in document.items():
            if type(config) is not dict:
                continue
            expect = config.get("expect", [])
            install = config.get("install", {})
            expects_all = expect == "*"
            expected = tuple(str(item) for item in expect) if type(expect) is list else ()
            install_by_harness = {str(k): str(v) for k, v in install.items()} if type(install) is dict else {}
            packs.append(Pack(str(name), install_by_harness, expected, expects_all))
        return cls(found=True, packs=tuple(packs))

    @classmethod
    def load_from(cls, vault_path: Path) -> PackManifest:
        manifest_path = vault_path / AGENT_ROOT_SUBDIR / MANIFEST_NAME
        if not manifest_path.exists():
            return cls.missing()
        try:
            document = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return cls.missing()
        return cls.from_document(document) if type(document) is dict else cls.missing()

    def foreign_packs(self) -> tuple[Pack, ...]:
        return tuple(pack for pack in self.packs if not pack.is_mine)

    def foreign_skill_names(self) -> set[str]:
        names: set[str] = set()
        for pack in self.foreign_packs():
            names.update(pack.expected_skill_names)
        return names


@dataclasses.dataclass(frozen=True)
class PreflightContext:
    options: PreflightOptions
    paths: PreflightPaths
    manifest: PackManifest
    harness: HarnessProfile
    os_profile: OperatingSystemProfile
    link_manager: LinkManager


@dataclasses.dataclass(frozen=True)
class BootstrapResult:
    result: CheckResult
    context: PreflightContext | None = None


@dataclasses.dataclass(frozen=True)
class ReadinessSummary:
    READY = "ready"
    NOT_READY = "NOT READY"

    results: tuple[CheckResult, ...]

    @property
    def failures(self) -> tuple[CheckResult, ...]:
        return tuple(result for result in self.results if result.status is Status.FAIL)

    @property
    def verdict(self) -> str:
        return self.READY if not self.failures else self.NOT_READY

    @property
    def exit_code(self) -> int:
        return 0 if self.verdict == self.READY else 1

    def to_json(self) -> dict[str, object]:
        return {"verdict": self.verdict, "checks": [result.to_json() for result in self.results]}


class ConsoleReporter:
    def __init__(self, json_out: bool) -> None:
        self.json_out = json_out

    def report(self, summary: ReadinessSummary) -> int:
        for result in summary.results:
            print(result.to_line())
            for fix in result.autofixes:
                print(f"  -> autofix applied: {fix}")
        if summary.failures:
            self._print_remediations(summary.failures)
        print(f"\n{summary.verdict}")
        if self.json_out:
            print(f"\n```json\n{json.dumps(summary.to_json(), indent=2, ensure_ascii=False)}\n```")
        return summary.exit_code

    def _print_remediations(self, failures: tuple[CheckResult, ...]) -> None:
        print()
        for index, result in enumerate(failures, 1):
            for remediation in result.remediations:
                print(f"{index}. {remediation}")


class ReadinessCheck(ABC):
    number: int

    @abstractmethod
    def run(self, context: PreflightContext) -> CheckResult:
        raise NotImplementedError


class HarnessProfile(ABC):
    name: HarnessName

    @abstractmethod
    def link_layout_known(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def link_requirements(self, context: PreflightContext) -> tuple[LinkRequirement, ...]:
        raise NotImplementedError

    @abstractmethod
    def foreign_pack_check_known(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def is_foreign_pack_installed(self, pack: Pack, context: PreflightContext) -> bool:
        raise NotImplementedError

    @abstractmethod
    def check_trust(self, context: PreflightContext) -> CheckResult:
        raise NotImplementedError


class OperatingSystemProfile(ABC):
    name: OperatingSystemName

    @abstractmethod
    def is_junction(self, path: Path) -> bool:
        raise NotImplementedError

    @abstractmethod
    def can_create_symlink(self, probe_dir: Path) -> bool:
        raise NotImplementedError

    @abstractmethod
    def manual_directory_link_command(self, link: Path, target: Path) -> str:
        raise NotImplementedError

    @abstractmethod
    def symlink_capability_remediation(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def uv_remediations(self) -> tuple[str, ...]:
        raise NotImplementedError


class LinkState(StrEnum):
    CORRECT = "correct"
    CREATED = "created"
    MISSING = "missing"
    CONFLICT = "conflict"
    CAPABILITY_BLOCKED = "capability-blocked"
    CREATE_FAILED = "create-failed"
    TARGET_MISMATCH = "target-mismatch"


class LinkKind(StrEnum):
    FILE = "file"
    DIRECTORY = "directory"


class LinkPolicy(StrEnum):
    CREATE_ONLY = "create-only"
    VERIFY_ONLY = "verify-only"


@dataclasses.dataclass(frozen=True)
class LinkRequirement:
    label: str
    link: Path
    target: Path
    kind: LinkKind
    policy: LinkPolicy = LinkPolicy.CREATE_ONLY
    missing_remediation: str = ""

    @property
    def is_directory(self) -> bool:
        return self.kind is LinkKind.DIRECTORY


@dataclasses.dataclass(frozen=True)
class LinkOutcome:
    requirement: LinkRequirement
    state: LinkState
    detail: str
    cleanup_detail: str = ""

    @property
    def is_ready(self) -> bool:
        return self.state in (LinkState.CORRECT, LinkState.CREATED)

    @property
    def autofix(self) -> str | None:
        return f"created {self.requirement.label}" if self.state is LinkState.CREATED else None

    @property
    def remediation(self) -> str:
        if self.cleanup_detail:
            return f"{self.detail}; cleanup note: {self.cleanup_detail}"
        if self.state is LinkState.MISSING and self.requirement.missing_remediation:
            return self.requirement.missing_remediation
        return self.detail


class LinkManager:
    def __init__(self, os_profile: OperatingSystemProfile) -> None:
        self.os_profile = os_profile

    def ensure(self, requirement: LinkRequirement, no_fix: bool) -> LinkOutcome:
        return LinkOutcome(requirement, LinkState.MISSING, "link checks pending Task 5")


class CheckSuite:
    def __init__(self, checks: tuple[ReadinessCheck, ...]) -> None:
        self.checks = checks

    @classmethod
    def default(cls) -> CheckSuite:
        return cls(checks=())

    def run_all(self, context: PreflightContext) -> tuple[CheckResult, ...]:
        return tuple(check.run(context) for check in self.checks)


class EnvironmentBootstrapper:
    def __init__(self, options: PreflightOptions, home: Path, cwd: Path) -> None:
        self.options = options
        self.home = home
        self.cwd = cwd

    def bootstrap(self) -> BootstrapResult:
        result = CheckResult(0, Status.PASS, "bootstrap scaffold")
        return BootstrapResult(result=result)


class PreflightApplication:
    def __init__(self, bootstrapper: EnvironmentBootstrapper, checks: CheckSuite, reporter: ConsoleReporter) -> None:
        self.bootstrapper = bootstrapper
        self.checks = checks
        self.reporter = reporter

    @classmethod
    def from_cli(cls, argv: list[str] | None = None) -> PreflightApplication:
        args = parse_args(argv)
        options = PreflightOptions(no_fix=args.no_fix, json_out=args.json_out)
        return cls(
            bootstrapper=EnvironmentBootstrapper(options, Path.home(), Path.cwd()),
            checks=CheckSuite.default(),
            reporter=ConsoleReporter(options.json_out),
        )

    def run(self) -> int:
        bootstrap = self.bootstrapper.bootstrap()
        results = [bootstrap.result]
        if bootstrap.context is not None:
            results.extend(self.checks.run_all(bootstrap.context))
        return self.reporter.report(ReadinessSummary(tuple(results)))


class BaseHarnessProfile(HarnessProfile):
    name: HarnessName

    def link_layout_known(self) -> bool:
        return False

    def link_requirements(self, context: PreflightContext) -> tuple[LinkRequirement, ...]:
        return ()

    def foreign_pack_check_known(self) -> bool:
        return False

    def is_foreign_pack_installed(self, pack: Pack, context: PreflightContext) -> bool:
        return False

    def check_trust(self, context: PreflightContext) -> CheckResult:
        return CheckResult(5, Status.SKIP, "permission/trust check pending Task 8")


class ClaudeProfile(BaseHarnessProfile):
    name = HarnessName.CLAUDE


class CodexProfile(BaseHarnessProfile):
    name = HarnessName.CODEX


class CopilotProfile(BaseHarnessProfile):
    name = HarnessName.COPILOT


class WindowsProfile(OperatingSystemProfile):
    name = OperatingSystemName.WINDOWS

    def is_junction(self, path: Path) -> bool:
        return False

    def can_create_symlink(self, probe_dir: Path) -> bool:
        return False

    def manual_directory_link_command(self, link: Path, target: Path) -> str:
        return f"mklink /J {link} {target}"

    def symlink_capability_remediation(self) -> str:
        return "enable Developer Mode or run as Administrator"

    def uv_remediations(self) -> tuple[str, ...]:
        return ("uv self update", "winget install astral-sh.uv")


class PosixProfile(OperatingSystemProfile):
    def is_junction(self, path: Path) -> bool:
        return False

    def can_create_symlink(self, probe_dir: Path) -> bool:
        return True

    def manual_directory_link_command(self, link: Path, target: Path) -> str:
        return f"ln -sfn {target} {link}"

    def symlink_capability_remediation(self) -> str:
        return "verify symlink permissions for this directory"

    def uv_remediations(self) -> tuple[str, ...]:
        return ("uv self update",)


class MacProfile(PosixProfile):
    name = OperatingSystemName.MAC

    def uv_remediations(self) -> tuple[str, ...]:
        return ("uv self update", "brew install uv")


class LinuxProfile(PosixProfile):
    name = OperatingSystemName.LINUX

    def uv_remediations(self) -> tuple[str, ...]:
        return ("uv self update", "curl -LsSf https://astral.sh/uv/install.sh | sh")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Agent preflight check")
    parser.add_argument("--no-fix", action="store_true", dest="no_fix", help="Report only; skip all autofixes")
    parser.add_argument("--json", action="store_true", dest="json_out", help="Append JSON summary block to output")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    return PreflightApplication.from_cli(argv).run()


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 5: Run and verify PASS**

```bash
python -m pytest tests/test_preflight.py -v
```

Expected: 2 PASS.

- [ ] **Step 6: Commit**

```bash
git add secret-agents/skills/ready-player-one/preflight.py secret-agents/skills/ready-player-one/tests/conftest.py secret-agents/skills/ready-player-one/tests/test_preflight.py
git commit -m "feat: scaffold OO preflight runner"
```

---

### Task 3: Environment bootstrapper, profile factories, and manifest load

**Files:**
- Modify: `secret-agents/skills/ready-player-one/preflight.py`
- Modify: `secret-agents/skills/ready-player-one/tests/test_preflight.py`

**Interfaces:**
- Produces:
  - `HarnessDetector.detect() -> HarnessProfile`
  - `OperatingSystemDetector.detect() -> OperatingSystemProfile`
  - `EnvironmentBootstrapper.bootstrap() -> BootstrapResult`
  - `PackManifest.load_from(vault_path: Path) -> PackManifest`

- [ ] **Step 1: Add failing bootstrap tests**

```python
import preflight


def test_bootstrap_detects_claude_from_env(monkeypatch, tmp_path: Path) -> None:
    home = tmp_path / "home"
    vault = tmp_path / "vault"
    (vault / "secret-agents").mkdir(parents=True)
    (home / ".agents").mkdir(parents=True)
    (home / ".agents" / "root").write_text(str(vault), encoding="utf-8")
    monkeypatch.setenv("CLAUDE_CODE_SESSION_ID", "1")

    bootstrap = preflight.EnvironmentBootstrapper(
        preflight.PreflightOptions(no_fix=True, json_out=False),
        home,
        tmp_path,
    ).bootstrap()

    assert bootstrap.context is not None
    assert bootstrap.context.harness.name is preflight.HarnessName.CLAUDE
    assert bootstrap.context.paths.vault == vault


def test_bootstrap_fails_when_pointer_file_missing(tmp_path: Path) -> None:
    bootstrap = preflight.EnvironmentBootstrapper(
        preflight.PreflightOptions(no_fix=True, json_out=False),
        tmp_path / "home",
        tmp_path,
    ).bootstrap()

    assert bootstrap.context is None
    assert bootstrap.result.status is preflight.Status.FAIL
    assert "pointer file missing" in bootstrap.result.message


def test_bootstrap_fails_when_vault_path_not_found(tmp_path: Path) -> None:
    home = tmp_path / "home"
    (home / ".agents").mkdir(parents=True)
    (home / ".agents" / "root").write_text(str(tmp_path / "missing"), encoding="utf-8")

    bootstrap = preflight.EnvironmentBootstrapper(
        preflight.PreflightOptions(no_fix=True, json_out=False),
        home,
        tmp_path,
    ).bootstrap()

    assert bootstrap.context is None
    assert bootstrap.result.status is preflight.Status.FAIL
    assert "vault not found" in bootstrap.result.message


def test_bootstrap_marks_manifest_missing_without_failing(tmp_path: Path) -> None:
    home = tmp_path / "home"
    vault = tmp_path / "vault"
    (vault / "secret-agents").mkdir(parents=True)
    (home / ".agents").mkdir(parents=True)
    (home / ".agents" / "root").write_text(str(vault), encoding="utf-8")

    bootstrap = preflight.EnvironmentBootstrapper(
        preflight.PreflightOptions(no_fix=True, json_out=False),
        home,
        tmp_path,
    ).bootstrap()

    assert bootstrap.context is not None
    assert bootstrap.context.manifest.found is False
    assert bootstrap.result.status is preflight.Status.PASS
```

- [ ] **Step 2: Run and verify FAIL**

```bash
python -m pytest tests/test_preflight.py -k "bootstrap" -v
```

Expected: tests fail because bootstrap still returns the scaffold result.

- [ ] **Step 3: Implement detectors and bootstrap**

Implementation rules:
- `HarnessDetector` owns env/workspace signals and returns a `HarnessProfile`.
- `OperatingSystemDetector` owns `platform.system()` mapping and returns an `OperatingSystemProfile`.
- `EnvironmentBootstrapper` reads `home/.agents/root`, constructs `PreflightPaths`, loads `PackManifest`, creates `LinkManager(os_profile)`, and returns a `PreflightContext`.

Required profile selection:

```python
class HarnessDetector:
    def __init__(self, env: dict[str, str], cwd: Path, home: Path) -> None:
        self.env = env
        self.cwd = cwd
        self.home = home

    def detect(self) -> HarnessProfile:
        if self.env.get("CLAUDE_CODE_SESSION_ID") or (self.cwd / ".claude").exists():
            return ClaudeProfile()
        if self.env.get("CODEX_HOME") or self.env.get("CODEX_CLI_PATH") or (self.home / ".codex").exists():
            return CodexProfile()
        if self.env.get("OPENAI_API_KEY") and not self.env.get("ANTHROPIC_API_KEY"):
            return CodexProfile()
        if self.env.get("GITHUB_COPILOT_TOKEN") or self.env.get("GITHUB_COPILOT_CHAT_CONTEXT"):
            return CopilotProfile()
        return ClaudeProfile()


class OperatingSystemDetector:
    def detect(self) -> OperatingSystemProfile:
        system = platform.system()
        if system == "Windows":
            return WindowsProfile()
        if system == "Darwin":
            return MacProfile()
        return LinuxProfile()
```

- [ ] **Step 4: Run and verify PASS**

```bash
python -m pytest tests/test_preflight.py -k "bootstrap" -v
```

Expected: 4 PASS.

- [ ] **Step 5: Commit**

```bash
git add secret-agents/skills/ready-player-one/preflight.py secret-agents/skills/ready-player-one/tests/test_preflight.py
git commit -m "feat: bootstrap preflight context"
```

---

### Task 4: VaultPurityCheck

**Files:**
- Modify: `secret-agents/skills/ready-player-one/preflight.py`
- Modify: `secret-agents/skills/ready-player-one/tests/test_preflight.py`

**Interfaces:**
- Produces `VaultPurityCheck(ReadinessCheck)` with `number = 1`.
- Adds `VaultPurityCheck()` to `CheckSuite.default()`.

- [ ] **Step 1: Add failing vault purity tests**

```python
def _context_for_vault(tmp_path: Path, manifest: preflight.PackManifest) -> preflight.PreflightContext:
    vault = tmp_path / "vault"
    paths = preflight.PreflightPaths(home=tmp_path / "home", cwd=tmp_path, vault=vault)
    return preflight.PreflightContext(
        options=preflight.PreflightOptions(no_fix=True, json_out=False),
        paths=paths,
        manifest=manifest,
        harness=preflight.ClaudeProfile(),
        os_profile=preflight.LinuxProfile(),
        link_manager=preflight.LinkManager(preflight.LinuxProfile()),
    )


def test_vault_purity_flags_foreign_skill_directory(tmp_path: Path) -> None:
    skills = tmp_path / "vault" / "secret-agents" / "skills"
    (skills / "ready-player-one").mkdir(parents=True)
    (skills / "brainstorming").mkdir()
    manifest = preflight.PackManifest.from_document({
        "mine": {"expect": "*"},
        "superpowers": {"expect": ["brainstorming"], "install": {"claude": "/plugin install superpowers"}},
    })

    result = preflight.VaultPurityCheck().run(_context_for_vault(tmp_path, manifest))

    assert result.status is preflight.Status.FAIL
    assert any("brainstorming" in item for item in result.remediations)


def test_vault_purity_passes_with_only_owned_skill_directories(tmp_path: Path) -> None:
    skills = tmp_path / "vault" / "secret-agents" / "skills"
    (skills / "ready-player-one").mkdir(parents=True)
    manifest = preflight.PackManifest.from_document({
        "mine": {"expect": "*"},
        "superpowers": {"expect": ["brainstorming"]},
    })

    result = preflight.VaultPurityCheck().run(_context_for_vault(tmp_path, manifest))

    assert result.status is preflight.Status.PASS


def test_vault_purity_fails_when_skills_dir_missing(tmp_path: Path) -> None:
    manifest = preflight.PackManifest.from_document({"mine": {"expect": "*"}})

    result = preflight.VaultPurityCheck().run(_context_for_vault(tmp_path, manifest))

    assert result.status is preflight.Status.FAIL
    assert "skills" in result.message


def test_vault_purity_skips_when_manifest_missing(tmp_path: Path) -> None:
    result = preflight.VaultPurityCheck().run(_context_for_vault(tmp_path, preflight.PackManifest.missing()))

    assert result.status is preflight.Status.SKIP
```

- [ ] **Step 2: Run and verify FAIL**

```bash
python -m pytest tests/test_preflight.py -k "vault_purity" -v
```

Expected: failure because `VaultPurityCheck` is not implemented.

- [ ] **Step 3: Implement VaultPurityCheck**

Implementation rules:
- Use `context.manifest.foreign_skill_names()`.
- A direct child of `context.paths.vault_skills` is a violation only when it is a real directory and its name appears in foreign skill names.
- A symlink or Windows junction inside the vault is not treated as authored content.

- [ ] **Step 4: Add VaultPurityCheck to the suite**

```python
@classmethod
def default(cls) -> CheckSuite:
    return cls(checks=(VaultPurityCheck(),))
```

- [ ] **Step 5: Run and verify PASS**

```bash
python -m pytest tests/test_preflight.py -k "vault_purity" -v
```

Expected: 4 PASS.

- [ ] **Step 6: Commit**

```bash
git add secret-agents/skills/ready-player-one/preflight.py secret-agents/skills/ready-player-one/tests/test_preflight.py
git commit -m "feat: add vault purity check"
```

---

### Task 5: OperatingSystemProfile subclasses and LinkManager

**Files:**
- Modify: `secret-agents/skills/ready-player-one/preflight.py`
- Modify: `secret-agents/skills/ready-player-one/tests/test_preflight.py`

**Interfaces:**
- Produces real implementations for:
  - `WindowsProfile.is_junction(path)`
  - `WindowsProfile.can_create_symlink(probe_dir)`
  - `MacProfile.can_create_symlink(probe_dir)`
  - `LinuxProfile.can_create_symlink(probe_dir)`
  - `LinkManager.ensure(requirement, no_fix) -> LinkOutcome`

- [ ] **Step 1: Add failing LinkManager tests**

```python
def test_link_manager_reports_correct_existing_link(tmp_path: Path) -> None:
    target = tmp_path / "target"
    link = tmp_path / "link"
    target.mkdir()
    link.symlink_to(target, target_is_directory=True)
    requirement = preflight.LinkRequirement("test link", link, target, preflight.LinkKind.DIRECTORY)

    outcome = preflight.LinkManager(preflight.LinuxProfile()).ensure(requirement, no_fix=False)

    assert outcome.state is preflight.LinkState.CORRECT
    assert outcome.is_ready


def test_link_manager_reports_conflict_without_overwrite(tmp_path: Path) -> None:
    existing = tmp_path / "existing"
    expected = tmp_path / "expected"
    link = tmp_path / "link"
    existing.mkdir()
    expected.mkdir()
    link.symlink_to(existing, target_is_directory=True)
    requirement = preflight.LinkRequirement("test link", link, expected, preflight.LinkKind.DIRECTORY)

    outcome = preflight.LinkManager(preflight.LinuxProfile()).ensure(requirement, no_fix=False)

    assert outcome.state is preflight.LinkState.CONFLICT
    assert link.resolve() == existing.resolve()


def test_link_manager_creates_missing_link_when_fixing(tmp_path: Path) -> None:
    target = tmp_path / "target"
    link = tmp_path / "link"
    target.mkdir()
    requirement = preflight.LinkRequirement("test link", link, target, preflight.LinkKind.DIRECTORY)

    outcome = preflight.LinkManager(preflight.LinuxProfile()).ensure(requirement, no_fix=False)

    assert outcome.state is preflight.LinkState.CREATED
    assert link.resolve() == target.resolve()


def test_link_manager_reports_missing_when_no_fix(tmp_path: Path) -> None:
    target = tmp_path / "target"
    link = tmp_path / "link"
    target.mkdir()
    requirement = preflight.LinkRequirement("test link", link, target, preflight.LinkKind.DIRECTORY)

    outcome = preflight.LinkManager(preflight.LinuxProfile()).ensure(requirement, no_fix=True)

    assert outcome.state is preflight.LinkState.MISSING
    assert not link.exists()


def test_windows_junction_detection_uses_reparse_tag(monkeypatch, tmp_path: Path) -> None:
    class Stat:
        st_reparse_tag = preflight.JUNCTION_REPARSE_TAG

    monkeypatch.setattr(preflight.os, "name", "nt")
    monkeypatch.setattr(preflight.os, "lstat", lambda path: Stat())

    assert preflight.WindowsProfile().is_junction(tmp_path)
```

- [ ] **Step 2: Run and verify FAIL**

```bash
python -m pytest tests/test_preflight.py -k "link_manager or junction" -v
```

Expected: failure because `LinkManager.ensure()` still returns the scaffold outcome.

- [ ] **Step 3: Implement OS profiles and LinkManager**

Implementation rules:
- `LinkManager` owns existence checks, target comparison, parent creation, symlink creation, post-create verification, and partial-link cleanup.
- Existing wrong destinations return `LinkState.CONFLICT`.
- `LinkPolicy.VERIFY_ONLY` returns `LinkState.MISSING` when absent; it never creates.
- Windows symlink capability is probed by creating and deleting a temporary file symlink in `probe_dir`.
- POSIX symlink capability may return `True`; creation failures still become `CREATE_FAILED`.

- [ ] **Step 4: Run and verify PASS**

```bash
python -m pytest tests/test_preflight.py -k "link_manager or junction" -v
```

Expected: 5 PASS.

- [ ] **Step 5: Commit**

```bash
git add secret-agents/skills/ready-player-one/preflight.py secret-agents/skills/ready-player-one/tests/test_preflight.py
git commit -m "feat: add typed link manager"
```

---

### Task 6: Harness profiles and LinkLayoutCheck

**Files:**
- Modify: `secret-agents/skills/ready-player-one/preflight.py`
- Modify: `secret-agents/skills/ready-player-one/tests/test_preflight.py`

**Interfaces:**
- Produces:
  - `ClaudeProfile.link_layout_known() -> True`
  - `ClaudeProfile.link_requirements(context) -> tuple[LinkRequirement, ...]`
  - `CodexProfile.link_layout_known() -> True`
  - `CodexProfile.link_requirements(context) -> tuple[LinkRequirement, ...]`
  - `CopilotProfile.link_layout_known() -> False`
  - `LinkLayoutCheck(ReadinessCheck)` with `number = 2`
- Adds `LinkLayoutCheck()` to `CheckSuite.default()`.

- [ ] **Step 1: Add failing link layout tests**

```python
def test_codex_profile_requires_agents_and_codex_skill_links(tmp_path: Path) -> None:
    skills = tmp_path / "vault" / "secret-agents" / "skills"
    (skills / "ready-player-one").mkdir(parents=True)
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context = dataclasses.replace(context, harness=preflight.CodexProfile())

    labels = {requirement.label for requirement in context.harness.link_requirements(context)}

    assert "~/.agents/skills/ready-player-one" in labels
    assert "~/.codex/skills/ready-player-one" in labels
    assert "~/.codex/AGENTS.md" in labels


def test_link_layout_autofixes_missing_codex_skill_link(tmp_path: Path) -> None:
    skills = tmp_path / "vault" / "secret-agents" / "skills"
    (skills / "ready-player-one").mkdir(parents=True)
    (tmp_path / "vault" / "secret-agents" / "AGENTS.md").write_text("rules", encoding="utf-8")
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context = dataclasses.replace(
        context,
        options=preflight.PreflightOptions(no_fix=False, json_out=False),
        harness=preflight.CodexProfile(),
    )

    result = preflight.LinkLayoutCheck().run(context)

    assert result.status is preflight.Status.PASS
    assert (context.paths.codex_dir / "skills" / "ready-player-one").resolve() == (skills / "ready-player-one").resolve()


def test_link_layout_skips_when_harness_layout_unknown(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context = dataclasses.replace(context, harness=preflight.CopilotProfile())

    result = preflight.LinkLayoutCheck().run(context)

    assert result.status is preflight.Status.SKIP
```

- [ ] **Step 2: Run and verify FAIL**

```bash
python -m pytest tests/test_preflight.py -k "link_layout or codex_profile" -v
```

Expected: failure because profile requirements and `LinkLayoutCheck` are not implemented.

- [ ] **Step 3: Implement harness link requirements**

Required behavior:
- Every known harness includes shared `~/.agents/skills/<skill>` per-skill symlinks to each direct child in `context.paths.vault_skills`.
- Claude also requires `~/.claude/AGENTS.md -> <agent-root>/AGENTS.md` as a create-only file symlink.
- Claude verifies `~/.claude/skills -> <agent-root>/skills` as a whole-directory link with `LinkPolicy.VERIFY_ONLY`; missing/wrong entries get a manual command from `context.os_profile.manual_directory_link_command(...)`.
- Codex also requires `~/.codex/AGENTS.md -> <agent-root>/AGENTS.md` and `~/.codex/skills/<skill>` per-skill symlinks.
- Copilot returns unknown layout until its discovery paths are confirmed.

- [ ] **Step 4: Implement LinkLayoutCheck**

`LinkLayoutCheck.run()`:
- returns skip when `context.harness.link_layout_known()` is false.
- asks `context.harness.link_requirements(context)` for all requirements.
- passes each requirement to `context.link_manager.ensure(...)`.
- returns fail when any outcome is not ready.
- returns pass with autofix messages from created outcomes.

- [ ] **Step 5: Add LinkLayoutCheck to the suite**

```python
@classmethod
def default(cls) -> CheckSuite:
    return cls(checks=(VaultPurityCheck(), LinkLayoutCheck()))
```

- [ ] **Step 6: Run and verify PASS**

```bash
python -m pytest tests/test_preflight.py -k "link_layout or codex_profile" -v
```

Expected: 3 PASS.

- [ ] **Step 7: Commit**

```bash
git add secret-agents/skills/ready-player-one/preflight.py secret-agents/skills/ready-player-one/tests/test_preflight.py
git commit -m "feat: add polymorphic link layout check"
```

---

### Task 7: ForeignPacksCheck

**Files:**
- Modify: `secret-agents/skills/ready-player-one/preflight.py`
- Modify: `secret-agents/skills/ready-player-one/tests/test_preflight.py`

**Interfaces:**
- Produces `ForeignPacksCheck(ReadinessCheck)` with `number = 3`.
- Harness profiles implement `foreign_pack_check_known()` and `is_foreign_pack_installed(pack, context)`.
- Adds `ForeignPacksCheck()` to `CheckSuite.default()`.

- [ ] **Step 1: Add failing foreign pack tests**

```python
def test_foreign_packs_detects_missing_superpowers_for_claude(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({
        "mine": {"expect": "*"},
        "superpowers": {
            "expect": ["brainstorming", "writing-plans", "using-superpowers"],
            "install": {"claude": "/plugin install superpowers"},
        },
    }))
    context = dataclasses.replace(context, harness=preflight.ClaudeProfile())

    result = preflight.ForeignPacksCheck().run(context)

    assert result.status is preflight.Status.FAIL
    assert any("/plugin install superpowers" in item for item in result.remediations)


def test_foreign_packs_passes_when_claude_plugin_cache_exists(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({
        "mine": {"expect": "*"},
        "superpowers": {
            "expect": ["brainstorming", "writing-plans", "using-superpowers"],
            "install": {"claude": "/plugin install superpowers"},
        },
    }))
    plugin_skills = context.paths.claude_dir / "plugins" / "cache" / "claude-plugins-official" / "superpowers" / "6.3.0" / "skills"
    (plugin_skills / "brainstorming").mkdir(parents=True)
    context = dataclasses.replace(context, harness=preflight.ClaudeProfile())

    result = preflight.ForeignPacksCheck().run(context)

    assert result.status is preflight.Status.PASS


def test_foreign_packs_skips_when_manifest_missing(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.missing())

    result = preflight.ForeignPacksCheck().run(context)

    assert result.status is preflight.Status.SKIP
```

- [ ] **Step 2: Run and verify FAIL**

```bash
python -m pytest tests/test_preflight.py -k "foreign_packs" -v
```

Expected: failure because `ForeignPacksCheck` is not implemented.

- [ ] **Step 3: Implement foreign pack behavior**

Required behavior:
- Claude knows `superpowers -> claude-plugins-official`; plugin cache existence is enough.
- Unknown Claude marketplace packs fall back to checking a threshold of expected skills in `~/.agents/skills`.
- Codex checks `~/.agents/skills` and `~/.codex/skills` for expected skill names.
- Copilot returns unknown and the check skips.
- Threshold is `min(3, len(pack.expected_skill_names))`.

- [ ] **Step 4: Add ForeignPacksCheck to the suite**

```python
@classmethod
def default(cls) -> CheckSuite:
    return cls(checks=(VaultPurityCheck(), LinkLayoutCheck(), ForeignPacksCheck()))
```

- [ ] **Step 5: Run and verify PASS**

```bash
python -m pytest tests/test_preflight.py -k "foreign_packs" -v
```

Expected: 3 PASS.

- [ ] **Step 6: Commit**

```bash
git add secret-agents/skills/ready-player-one/preflight.py secret-agents/skills/ready-player-one/tests/test_preflight.py
git commit -m "feat: add foreign pack check"
```

---

### Task 8: PermissionTrustCheck

**Files:**
- Modify: `secret-agents/skills/ready-player-one/preflight.py`
- Modify: `secret-agents/skills/ready-player-one/tests/test_preflight.py`

**Interfaces:**
- Produces:
  - `JsonSettingsFile`
  - `CodexConfigFile`
  - `PermissionTrustCheck(ReadinessCheck)` with `number = 5`
  - real `ClaudeProfile.check_trust(context)`
  - real `CodexProfile.check_trust(context)`
  - skip `CopilotProfile.check_trust(context)`
- Adds `PermissionTrustCheck()` to `CheckSuite.default()`.

- [ ] **Step 1: Add failing permission/trust tests**

```python
def test_claude_trust_fails_when_global_has_dont_ask_only(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context = dataclasses.replace(context, harness=preflight.ClaudeProfile())
    (context.paths.claude_dir).mkdir(parents=True)
    (context.paths.claude_dir / "settings.json").write_text(
        '{"permissions": {"defaultMode": "dontAsk"}}',
        encoding="utf-8",
    )
    (context.paths.cwd / ".claude").mkdir()
    (context.paths.cwd / ".claude" / "settings.json").write_text(
        '{"permissions": {"defaultMode": "dontAsk"}}',
        encoding="utf-8",
    )

    result = preflight.PermissionTrustCheck().run(context)

    assert result.status is preflight.Status.FAIL


def test_claude_trust_passes_when_global_has_bypass_and_prompt_skip(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context = dataclasses.replace(context, harness=preflight.ClaudeProfile())
    context.paths.claude_dir.mkdir(parents=True)
    (context.paths.claude_dir / "settings.json").write_text(
        '{"permissions": {"defaultMode": "bypassPermissions"}, "skipDangerousModePermissionPrompt": true}',
        encoding="utf-8",
    )
    (context.paths.cwd / ".claude").mkdir()
    (context.paths.cwd / ".claude" / "settings.json").write_text(
        '{"permissions": {"defaultMode": "dontAsk"}}',
        encoding="utf-8",
    )

    result = preflight.PermissionTrustCheck().run(context)

    assert result.status is preflight.Status.PASS


def test_claude_trust_autofixes_global_settings_additively(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context = dataclasses.replace(
        context,
        options=preflight.PreflightOptions(no_fix=False, json_out=False),
        harness=preflight.ClaudeProfile(),
    )
    context.paths.claude_dir.mkdir(parents=True)
    (context.paths.claude_dir / "settings.json").write_text('{"other": "kept"}', encoding="utf-8")
    (context.paths.cwd / ".claude").mkdir()
    (context.paths.cwd / ".claude" / "settings.json").write_text(
        '{"permissions": {"defaultMode": "dontAsk"}}',
        encoding="utf-8",
    )

    result = preflight.PermissionTrustCheck().run(context)
    data = json.loads((context.paths.claude_dir / "settings.json").read_text(encoding="utf-8"))

    assert result.status is preflight.Status.PASS
    assert data["permissions"]["defaultMode"] == "bypassPermissions"
    assert data["skipDangerousModePermissionPrompt"] is True
    assert data["other"] == "kept"


def test_codex_trust_uses_tomllib_and_appends_missing_project(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context = dataclasses.replace(
        context,
        options=preflight.PreflightOptions(no_fix=False, json_out=False),
        harness=preflight.CodexProfile(),
    )
    context.paths.codex_dir.mkdir(parents=True)
    (context.paths.codex_dir / "config.toml").write_text("", encoding="utf-8")

    result = preflight.PermissionTrustCheck().run(context)
    text = (context.paths.codex_dir / "config.toml").read_text(encoding="utf-8")

    assert result.status is preflight.Status.PASS
    assert "trust_level = \"trusted\"" in text
```

- [ ] **Step 2: Run and verify FAIL**

```bash
python -m pytest tests/test_preflight.py -k "trust or permission" -v
```

Expected: failure because trust behavior still returns the scaffold skip.

- [ ] **Step 3: Implement JsonSettingsFile**

Required behavior:
- Missing or unreadable JSON reads as `{}` because settings files are expected runtime configuration.
- `write_additive(updates)` preserves unrelated keys.
- Nested dictionaries merge one level deep for `permissions.defaultMode`.

- [ ] **Step 4: Implement ClaudeProfile.check_trust**

Required behavior:
- Global `~/.claude/settings.json` must have `permissions.defaultMode == "bypassPermissions"`.
- Global settings must have `skipDangerousModePermissionPrompt == true`.
- Project `.claude/settings.json` accepts `permissions.defaultMode` of `dontAsk` or `bypassPermissions`.
- Autofix writes global `bypassPermissions`, global `skipDangerousModePermissionPrompt: true`, and missing project default mode additively.

- [ ] **Step 5: Implement CodexConfigFile and CodexProfile.check_trust**

Required behavior:
- Read `~/.codex/config.toml` with `tomllib`.
- Treat the current project as trusted only when `projects[<cwd>]["trust_level"] == "trusted"`.
- In autofix mode, append:

```toml
[projects.'<cwd>']
trust_level = "trusted"
```

- [ ] **Step 6: Implement PermissionTrustCheck and add it to the suite**

```python
class PermissionTrustCheck(ReadinessCheck):
    number = 5

    def run(self, context: PreflightContext) -> CheckResult:
        return context.harness.check_trust(context)
```

`CheckSuite.default()` becomes:

```python
return cls(checks=(VaultPurityCheck(), LinkLayoutCheck(), ForeignPacksCheck(), PermissionTrustCheck()))
```

- [ ] **Step 7: Run and verify PASS**

```bash
python -m pytest tests/test_preflight.py -k "trust or permission" -v
```

Expected: 4 PASS.

- [ ] **Step 8: Commit**

```bash
git add secret-agents/skills/ready-player-one/preflight.py secret-agents/skills/ready-player-one/tests/test_preflight.py
git commit -m "feat: add polymorphic permission trust check"
```

---

### Task 9: VersionCacheCheck and UvCheck

**Files:**
- Modify: `secret-agents/skills/ready-player-one/preflight.py`
- Modify: `secret-agents/skills/ready-player-one/tests/test_preflight.py`

**Interfaces:**
- Produces:
  - `Clock.now() -> datetime`
  - `VersionCacheCheck(ReadinessCheck)` with `number = 6`
  - `UvRunner.run() -> UvRunResult`
  - `UvCheck(ReadinessCheck)` with `number = 7`
- Completes `CheckSuite.default()` with all script-owned checks.

- [ ] **Step 1: Add failing version and uv tests**

```python
def test_version_cache_warns_when_missing(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))

    result = preflight.VersionCacheCheck(preflight.Clock()).run(context)

    assert result.status is preflight.Status.WARN
    assert any("update-agent-stack" in item for item in result.remediations)


def test_version_cache_passes_when_fresh(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context.paths.versions_cache.parent.mkdir(parents=True)
    context.paths.versions_cache.write_text(
        '{"checked_at": "2026-08-30T00:00:00+00:00", "components": {"claude-cli": {"installed": "2.1.200"}}}',
        encoding="utf-8",
    )

    result = preflight.VersionCacheCheck(preflight.FixedClock(datetime(2026, 8, 30, tzinfo=timezone.utc))).run(context)

    assert result.status is preflight.Status.PASS
    assert "claude-cli" in result.message


def test_version_cache_warns_when_stale(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    context.paths.versions_cache.parent.mkdir(parents=True)
    context.paths.versions_cache.write_text(
        '{"checked_at": "2026-01-01T00:00:00+00:00", "components": {}}',
        encoding="utf-8",
    )

    result = preflight.VersionCacheCheck(preflight.FixedClock(datetime(2026, 8, 30, tzinfo=timezone.utc))).run(context)

    assert result.status is preflight.Status.WARN


def test_uv_skips_when_project_has_no_uv_files(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))

    result = preflight.UvCheck(preflight.UvRunner()).run(context)

    assert result.status is preflight.Status.SKIP


def test_uv_runs_when_pyproject_exists(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    (context.paths.cwd / "pyproject.toml").write_text("[project]\nname = \"test\"", encoding="utf-8")

    result = preflight.UvCheck(preflight.FixedUvRunner(preflight.UvRunResult(True, ""))).run(context)

    assert result.status is preflight.Status.PASS


def test_uv_failure_reports_os_remediations(tmp_path: Path) -> None:
    context = _context_for_vault(tmp_path, preflight.PackManifest.from_document({"mine": {"expect": "*"}}))
    (context.paths.cwd / "pyproject.toml").write_text("[project]\nname = \"test\"", encoding="utf-8")

    result = preflight.UvCheck(preflight.FixedUvRunner(preflight.UvRunResult(False, "uv not found"))).run(context)

    assert result.status is preflight.Status.FAIL
    assert any("uv self update" in item for item in result.remediations)
```

- [ ] **Step 2: Run and verify FAIL**

```bash
python -m pytest tests/test_preflight.py -k "version_cache or uv" -v
```

Expected: failure because these classes are not implemented.

- [ ] **Step 3: Implement Clock and VersionCacheCheck**

Required behavior:
- Missing, unreadable, malformed, or stale cache returns `Status.WARN`, never `Status.FAIL`.
- Stale means checked more than `VERSION_CACHE_MAX_AGE_DAYS` ago.
- Remediation is `Run: /update-agent-stack`.

- [ ] **Step 4: Implement UvRunner and UvCheck**

Required behavior:
- Skip when neither `pyproject.toml` nor `uv.lock` exists in `context.paths.cwd`.
- Run `uv run python -c "print('uv ok')"` with a 30-second timeout.
- Pass when return code is zero and stdout contains `uv ok`.
- Failure remediation comes from `context.os_profile.uv_remediations()`.

- [ ] **Step 5: Complete CheckSuite.default()**

```python
return cls(checks=(
    VaultPurityCheck(),
    LinkLayoutCheck(),
    ForeignPacksCheck(),
    PermissionTrustCheck(),
    VersionCacheCheck(Clock()),
    UvCheck(UvRunner()),
))
```

- [ ] **Step 6: Run and verify PASS**

```bash
python -m pytest tests/test_preflight.py -k "version_cache or uv" -v
```

Expected: 6 PASS.

- [ ] **Step 7: Commit**

```bash
git add secret-agents/skills/ready-player-one/preflight.py secret-agents/skills/ready-player-one/tests/test_preflight.py
git commit -m "feat: add version cache and uv checks"
```

---

### Task 10: Integration, SKILL.md rewrite, delete agent-preflight, README

**Files:**
- Modify: `secret-agents/skills/ready-player-one/SKILL.md`
- Modify: `secret-agents/skills/ready-player-one/tests/test_preflight.py`
- Delete: `secret-agents/skills/agent-preflight/`
- Modify: `secret-agents/skills/README.md`
- Modify: `secret-agents/skills/README.html`

**Interfaces:**
- Produces complete deployable `ready-player-one`.

- [ ] **Step 1: Add integration test**

```python
def test_full_run_produces_valid_json_summary() -> None:
    result = _run("--json", "--no-fix")
    assert result.returncode in (0, 1)
    match = re.search(r"```json\n(.*?)```", result.stdout, re.DOTALL)
    assert match, f"No JSON block in output:\n{result.stdout}"
    data = json.loads(match.group(1))
    assert data["verdict"] in ("ready", "NOT READY")
    valid_nums = {0, 1, 2, 3, 5, 6, 7}
    for check in data["checks"]:
        assert check["num"] in valid_nums
        assert "status" in check
        assert "message" in check
        assert check["status"] in ("✅", "❌", "⏭️", "⚠️")
```

- [ ] **Step 2: Run integration test**

```bash
python -m pytest tests/test_preflight.py::test_full_run_produces_valid_json_summary -v
```

Expected: PASS.

- [ ] **Step 3: Run full ready-player-one test suite**

```bash
python -m pytest tests/ -v
```

Expected: all tests PASS.

- [ ] **Step 4: Rewrite SKILL.md**

```markdown
---
name: ready-player-one
description: Pre-flight environment check before executing a batched prompt or complex task. Detects harness (claude/codex/copilot) and OS (win/lin/mac), runs harness-specific checks, and outputs "ready" or a tailored remediation list. No partial passes — every check must pass before you proceed.
---

# ready-player-one

Binary verdict before expensive batched prompts. Run it, relay the output, stop at the verdict.

## Behavior

**Step 1 — Run the preflight script**

Find `preflight.py` at `<skill base dir>/preflight.py`. Run it:

```
python "<skill base dir>/preflight.py" --json
```

Relay its complete output verbatim. The script owns checks 0-3 and 5-7.

If check 0 fails with "pointer file missing": ask the user for the vault's absolute path, write it as one line to `~/.agents/root`, then re-run the script.

**Step 2 — Check 4: Session skills diff**

Load `<vault>/secret-agents/packs.json`. For each pack in the manifest:
- `mine.expect: "*"` — every child directory of `<vault>/secret-agents/skills` must be session-visible.
- Foreign packs — each skill name in `expect` must be session-visible.

For each missing skill: read its `SKILL.md` file directly into context. Print:

```
⚠️ Check 4: loaded <skill-name> into session (fresh session registers it properly)
```

If a skill's `SKILL.md` cannot be found, print:

```
❌ Check 4: <skill-name> not found — reinstall its pack then start a fresh session
```

**Step 3 — Emit verdict**

If any `❌` remains after steps 1 and 2: print `NOT READY` followed by numbered remediations. Do not proceed with the batched prompt.

If all checks passed (`✅`, `⏭️`, or `⚠️`, with no `❌`): print `ready`. The batched prompt may run.

## Notes

- This skill is offline. For version updates, run `/update-agent-stack`.
- `⚠️` on check 6 does not block `ready`; offline machines must still reach ready.
- A fresh session registers newly added skills; the in-session read in step 2 is a stopgap.
```

- [ ] **Step 5: Delete agent-preflight**

```bash
git rm -r secret-agents/skills/agent-preflight/
```

- [ ] **Step 6: Update skills README**

Run `/update-skills-readme` to regenerate `secret-agents/skills/README.md` and `secret-agents/skills/README.html`.

- [ ] **Step 7: Commit everything**

```bash
git add secret-agents/skills/ready-player-one/SKILL.md secret-agents/skills/ready-player-one/tests/test_preflight.py secret-agents/skills/README.md secret-agents/skills/README.html
git commit -m "feat: rewrite ready-player-one preflight"
```

## Post-implementation verification

After all tasks are committed, start a fresh session and run `/ready-player-one`. Expected result on this machine before migration: check 2 may flag `~/.claude/skills` pointing to an old path. That is correct behavior; fix it with the runbook migration section and rerun.
