# Quality-Gate De-contamination & AGENTS.md Generalization: Follow-ups

**Date:** 2026-08-29
**Context:** A builder2 session compared `Projects/builder2/AGENTS.md` against this repo's `AGENTS.md`, generalized two rules into the shared agreement, and de-contaminated `skills/python-quality-gate` (it carried ugs-project baggage — a defect this repo's own skills README portability matrix had already flagged). This doc records what changed, what content was removed and must be relocated, and the remaining work.

---

## 1. What changed this session (uncommitted in this repo)

- `AGENTS.md` → revision **2026-08-29c**. Two Code Style rules added, generalized from builder2:
  - Pick unit shape deliberately (class vs free function); constructor-injected classes are as testable as free functions — testability is never a reason to avoid one.
  - Place each helper with its consumer: one consumer → belongs to that unit (static when stateless); two or more → module-level, owned by none.
- `skills/python-quality-gate/SKILL.md` → rewritten. Now runs the *repository-documented* gate when one exists (repo AGENTS.md, CLAUDE.md, README, or CI config), falling back to the four-tool default with source/test paths discovered from the repo layout. Removed all ugs-project content (see §2). Added: zero-file mypy scan counts as gate failure; format-only-failure fast path (`ruff format`, then re-run the full gate).
- `skills/README.md` / `README.html` → factual refresh for python-quality-gate (inventory one-liner, What-it-does, Copilot example, portability note now "Content fully portable"); re-rendered clean (`verified: 17 skills documented, anchors OK`). Architect's review blocks were preserved verbatim per no-`review` mode — see §3.
- **Mirrored** the rewritten SKILL.md into the live tree at `C:\git\worky\Agent\skills\python-quality-gate\` (harnesses load that tree via the `~/.claude/skills` junction, not this repo — see §3 migration item). That tree's README was also regenerated; its render guard exposed undocumented `jira-ht`/`jira-human-ticket-create` sections, which were ported from this repo's README.

## 2. Removed content to relocate into the ugs project's own AGENTS.md

The following was deleted from the shared skill and exists nowhere else. It belongs in the ugs repository's guidance (per this repo's rule: repo-specific conventions live in that repo's AGENTS.md).

> If `uv run` is available and `ugs.exe` is not locked, you may substitute `uv run` for `python -m` — they are equivalent. On Windows with an active process holding the binary, `python -m` is the safe fallback.
>
> Common patterns seen on this project:
> - ruff B008 (`QModelIndex()` as default arg) → use `None` sentinel with `0 if parent is not None and parent.isValid() else ...`
> - mypy `T | None` from `findChild` → add `assert widget is not None` guard before use
> - mypy on `QCoreApplication.instance()` → split into two lines with assertion

## 3. Remaining tasks

- [ ] Commit the pending changes in this repo (AGENTS.md, python-quality-gate SKILL.md, skills README.md/README.html, this doc).
- [ ] Relocate §2 content into the ugs project's AGENTS.md, then delete §2 from this doc.
- [ ] Rerun `/update-skills-readme review` on a frontier-class model: the preserved python-quality-gate Architect's review still criticizes weaknesses the rewrite fixed (hard-coded `src/ tests/`, ugs.exe baggage, missing format fast path, silent mypy no-op).
- [ ] Optional rigor: pressure-test the rewritten skill per superpowers writing-skills TDD (baseline a repo with a documented five-command gate — e.g. builder2 — and verify an agent runs the documented gate rather than the four-tool default).
- [ ] Finish the platform-links migration: repoint the `~/.claude/skills` junction (currently → `C:\git\worky\Agent\skills`, a stale copy whose AGENTS.md sits at revision 2026-07-12) at this canonical tree, and reconcile the skill-name divergence between trees (e.g. `clean-code-architecture-guards` ↔ `architecture-guards`, `unreal-reset-build-env` ↔ `reset-unreal-build-environment`, `report-status` ↔ `status-report-create`, `unreal-ugs-release` ↔ `ugs-pcb-release`, `report-receipt` ↔ `work-receipt-create`). **Until this lands, every shared-skill edit must be mirrored into both trees or live sessions keep loading the old copy.**
- [ ] Pre-existing, unrelated: untracked `tests/test_receipts.py` fails collection (`ImportError: cannot import name 'InstallReceipt' from 'secret_agents_setup.models'`) — in-progress work by a prior session; resolve or remove.

## 4. Handoff prompt

Paste into a fresh session working in `C:\git\handbag-of-holding\secret-agents`:

> Read `docs\todo\quality-gate-decontamination-followups.md` and work its §3 checklist top to bottom, checking off items as they complete. Uncommitted working-tree changes from the originating session are already present — review them with `git diff`, then commit them as the first item. Constraints: bump the `AGENTS.md` revision stamp on any edit to it; `skills/README.md` is the source of truth and `README.html` is rendered — never hand-edit the HTML, regenerate via `uv run skills\update-skills-readme\scripts\render_html.py` and require its `verified:` line; preserve Architect's review blocks verbatim except during an explicit `review` regeneration. Verify with `python -m pytest --tb=short -q --ignore=tests/test_receipts.py` (61 tests passed at handoff; `test_receipts.py` is known-broken pre-existing work). The junction repoint and skill-name reconciliation change what live harness sessions load — present a plan for that item and get approval before switching links. Relocating §2 requires knowing the ugs repository's location; ask if it isn't discoverable.

