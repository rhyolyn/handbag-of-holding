# Cross-Platform Harness Setup Design

**Date:** 2026-08-28

**Status:** Approved design

**Canonical source:** `handbag-of-holding/secret-agents`

## Summary

`handbag-of-holding/secret-agents` becomes the single editable source for shared agent guidance, skills, runbooks, and model-routing recommendations. The checkout may live anywhere on Windows, Linux, or macOS. A standard-library Python installer projects that source into each local harness's supported user-level discovery locations without scattering editable copies across project repositories, records enough state to uninstall safely, and refuses unsupported link strategies before changing managed destinations.

Local development uses links or Windows directory junctions into the canonical checkout. Future containerized agents receive immutable, versioned skill bundles baked into their images; bind mounts are permitted only as a development convenience. Container packaging is deliberately deferred until an agent runtime needs it.

## Goals

- Make `secret-agents` the only editable source of shared guidance and skills.
- Support Codex, Claude Code, GitHub Copilot in VS Code, and GitHub Copilot CLI on Windows, Linux, and macOS.
- Keep shared personal skills out of individual project repositories.
- Coexist safely with third-party personal skills already installed in harness-native directories.
- Provide deterministic, read-only validation that does not spend model calls.
- Make local installation reversible without deleting third-party content or losing conflict backups.
- Keep volatile model IDs in one dated reference with a repeatable refresh and staleness check.
- Preserve a clean path to immutable container distribution without building speculative packaging machinery now.

## Non-goals

- Making `secret-agents` an independent Git repository.
- Supporting cloud or container agents in the first installer version.
- Fetching or updating the canonical repository.
- Installing Python or configuring shell startup files.
- Silently copying guidance or skills when link creation is unavailable.
- Managing repository-specific `AGENTS.md`, `.claude/skills`, `.agents/skills`, or `.github/skills` content.

## Canonical root

The canonical root is the `secret-agents` directory inside the `handbag-of-holding` checkout. Its physical location is machine-local and has no prescribed parent path. In particular, the repository does not need to live directly under the user's home directory.

The root contains a small `.agent-root.json` marker with a schema version and stable identity. The installer validates the marker and the required `AGENTS.md`, `model-routing.json`, `skills`, and `runbooks` entries before planning any operation.

Root resolution uses this precedence:

1. An explicit `--agent-root PATH` argument.
2. `SECRET_AGENTS_ROOT`, when set.
3. The nearest ancestor of the running installer containing a valid `.agent-root.json`.
4. A controlled failure that explains how to specify the root.

The installer never performs a broad filesystem search and never contains machine-specific candidates such as `C:\git` or `D:\git`. This prevents a stale backup or another checkout from winning by search order.

## Repository layout

```text
secret-agents/
  .agent-root.json
  AGENTS.md
  model-routing.json
  skills/
    update-model-routing/
      SKILL.md
      agents/openai.yaml
      scripts/check_staleness.py
  runbooks/
    harness-setup/
      harness-setup.md
  scripts/
    harness_setup.py
  tests/
    test_harness_setup.py
```

The first version stays a standard-library Python 3 program. The implementation may be split into additional modules when distinct responsibilities make that useful, but the public entrypoint remains `scripts/harness_setup.py`.

## Command surface

```text
python scripts/harness_setup.py install --harness all
python scripts/harness_setup.py install --harness codex
python scripts/harness_setup.py install --harness claude --dry-run
python scripts/harness_setup.py check --harness all
python scripts/harness_setup.py uninstall --harness all
python scripts/harness_setup.py install --agent-root PATH
python scripts/harness_setup.py install --harness all --backup-conflicts
```

Supported harness selectors are `codex`, `claude`, `copilot`, and `all`; the selector defaults to `all`. `install` is idempotent and mutating. `uninstall` reverses only mutations recorded in the installation receipt. `check` and `--dry-run` are read-only. `--backup-conflicts` moves conflicting regular files to timestamped sibling backups before installation; it never deletes them.

There is no `package` command in the first version. Container packaging still lacks a concrete runtime consumer, while uninstall is part of the local installer's trust and reversibility contract.

## Model routing reference

`model-routing.json` is the only tracked source for exact Codex and Claude model IDs used by implementation plans and handoffs. It contains schema version `1`, `last_verified`, `stale_after_days` set to `31`, authoritative source URLs, and named `high-risk`, `balanced`, `routine`, and `economy` profiles. Plans refer to profile names rather than repeating model IDs. Before dispatch, an executor verifies that the selected IDs are present in the current harness-visible model allowlist and substitutes only a same-provider, same-or-higher-capability current model when the recorded ID is unavailable.

The `update-model-routing` skill refreshes the reference from current official OpenAI and Anthropic model documentation. Its deterministic `scripts/check_staleness.py` reads the reference without network access and prints `CURRENT` or `STALE` with the verification date and age. Age greater than `31` calendar days is stale and exits nonzero. `smart-plan` consumes named profiles from this reference and refuses to finalize a plan against a stale reference. The cross-platform CI workflow runs the age check on changes and on a weekly schedule so stale routing is reported even when neither skill is invoked manually.

## Local projections

The installer owns these user-level projections:

| Consumer | User-level path | Canonical target |
|---|---|---|
| Codex and local Copilot skills | `~/.agents/skills` | `<root>/skills` |
| Claude Code skills | `~/.claude/skills` | `<root>/skills` |
| Codex guidance | `~/.codex/AGENTS.md` | `<root>/AGENTS.md` |
| Claude Code guidance | `~/.claude/CLAUDE.md` | `<root>/AGENTS.md` |
| Copilot CLI guidance | `~/.copilot/copilot-instructions.md` | `<root>/AGENTS.md` |

These paths were verified on 2026-08-28 against current first-party documentation:

- Codex global guidance and personal skills: [Custom instructions with AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md) and [Codex skills](https://developers.openai.com/codex/skills).
- Claude Code user instructions and personal skills: [How Claude remembers your project](https://code.claude.com/docs/en/memory) and [Extend Claude with skills](https://code.claude.com/docs/en/slash-commands).
- Copilot CLI personal instructions and shared personal skills: [Adding custom instructions for GitHub Copilot CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-custom-instructions) and [Adding agent skills for GitHub Copilot CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills).

The installer treats these as dated external contracts. Documentation and integration tests must name the verification date and sources; deterministic tests prove projection behavior but do not claim that a harness consumed a path. Native `/memory`, `/skills`, or `/instructions` diagnostics remain the end-to-end confirmation surface.

VS Code can consume the personal skills under `~/.agents/skills` and the supported user-level guidance surfaces. Project-local skills remain appropriate only for workflows owned by a particular repository or required by a remote agent that cannot access the user's home directory.

Selected harness adapters are combined into one plan and deduplicated by destination path. For example, selecting both Codex and Copilot plans `~/.agents/skills` once.

All three guidance projections target the same `AGENTS.md` in v1. This deliberately assumes the shared working agreement is valid across Codex, Claude Code, and Copilot CLI. Harness adapters keep source selection data-driven so a later proven divergence can introduce harness-specific guidance without changing planning or execution contracts.

### Link strategy

- Linux and macOS use symbolic links.
- Windows uses directory junctions for skill directories by default.
- Windows uses file symbolic links for instruction files.
- Windows install performs a disposable file-symlink capability probe before mutating managed destinations. If Developer Mode or `SeCreateSymbolicLinkPrivilege` is unavailable, it reports the prerequisite and exits without partial installation.
- `check` and `--dry-run` never create probe artifacts; when a required Windows file link is absent, they report that install-time capability remains to be verified.
- Failure to create a required link is an actionable controlled failure. The installer does not fall back to unmanaged copies or hardlinks.

File hardlinks are not a safe default: they require source and destination on the same volume, and an editor that atomically replaces canonical `AGENTS.md` can leave the projected name attached to the old file identity. Copy fallback is also rejected because edits no longer propagate from the canonical source. A privileged or Developer-Mode-enabled file symlink continues to resolve after atomic replacement at the same canonical path; moving the checkout deliberately requires reinstall. Surfacing that prerequisite is preferable to silent drift.

When a skill destination is absent, the installer links the entire canonical `skills` directory so newly added canonical skills appear automatically. When the destination is an existing real directory containing other personal skills, the installer preserves it and creates one child link for each canonical skill. A same-name child owned by another source is a blocking collision.

## Installation transaction

Every install begins with a complete read-only preflight. Each intended projection is classified as:

- correct;
- missing;
- stale link or junction;
- compatible existing skill directory;
- skill-name collision;
- unrelated file or directory; or
- unsupported link capability.

If any selected target has a blocking condition, the installer reports the complete plan and makes no changes. This all-or-nothing preflight prevents a multi-harness request from leaving only some harnesses configured.

After preflight succeeds, installation:

1. Creates an in-memory rollback journal for every planned mutation.
2. Creates missing parent directories.
3. Replaces stale links without touching their targets.
4. Creates whole-directory or per-skill projections as planned.
5. Re-runs static validation and reports the final status.

If a mutation or final validation fails, the installer rolls back its changes in reverse order, including restoring any conflict backups it moved. A rollback failure is reported prominently with every path requiring manual recovery; it is never hidden behind the original error.

Correct projections are never rewritten. Existing regular instruction files are never overwritten implicitly. An explicitly requested conflict migration moves them to timestamped backups before creating the projection.

### Installation receipt and uninstall

A successful install atomically writes `~/.secret-agents/installations/handbag-secret-agents-v1.json`. The receipt records the root identity and installed root path, every whole-directory or per-skill projection created by the installer, parent directories created by the installer, and each conflict source-to-backup move with the backup's SHA-256 digest. Receipt replacement participates in the install transaction; a failed receipt write rolls back filesystem mutations.

`uninstall` performs complete read-only preflight from the receipt. It verifies that each recorded projection still resolves to the recorded canonical source, that backup paths still identify the recorded files, and that no destination has been replaced by unrelated content. Any ownership ambiguity blocks all removal. A valid uninstall removes installer-owned links, restores recorded conflict backups, removes only installer-created parents that are empty, and removes the receipt. Uninstall uses the same reverse-order journal and restores the installed state if removal fails. With no receipt, uninstall reports `not-installed`; it never claims ownership based only on a matching path.

## Validation and diagnostics

`check` validates the setup without launching a harness or model. It verifies:

- canonical-root marker and required layout;
- every selected projection's resolved target;
- absence of broken links and unexpected duplicate projections;
- the presence of `SKILL.md` in every canonical skill directory;
- required skill frontmatter and unique skill names;
- collisions between canonical and existing third-party personal skills; and
- whether a new harness session is required before discovery changes become visible.

The report uses stable statuses and exits nonzero when remediation is required. It also prints optional native confirmation steps, such as Claude `/skills` and `/memory`, Copilot `/skills` and `/instructions`, and the current Codex instruction/skill discovery diagnostic. These interactive checks are end-to-end confirmation, not part of deterministic validation.

## Container distribution

Production agents will not mount a developer checkout or clone `handbag-of-holding` at startup. A future bundle command will accept an agent's required skill names, validate those names, and emit an immutable staging directory or archive containing each complete skill directory, including its referenced scripts, assets, and references.

The bundle will record the source Git commit and content hashes. A container build copies the result into a fixed image path and configures or projects it into the runtime's supported skill-discovery path. Agent definitions depend on stable skill names rather than absolute source paths.

During local container development, a bind mount of `<root>/skills` is allowed for fast iteration. This is explicitly a development mode and is not the production deployment contract.

Container bundling remains deferred until the Jira-agent runtime and its deployment mechanism are concrete. The local installer must not encode assumptions that prevent this later flow: skill resources remain relative to their skill directory, skill names remain unique and stable, and canonical files do not contain checkout-specific absolute paths.

## Testing strategy

Tests use temporary canonical roots and temporary home directories. Production code receives the home path and link capability through explicit inputs so tests never mutate the real user profile.

Focused coverage includes:

- explicit, environment, and self-relative root resolution;
- invalid and ambiguous root markers;
- whole-directory installation into an absent destination;
- per-skill installation beside third-party skills;
- same-name collision refusal;
- correct and stale links;
- conflicting regular instruction files and backup migration;
- all-or-nothing preflight across multiple harnesses;
- `check` and `--dry-run` non-mutation;
- Unix symbolic-link behavior;
- Windows junction and file-link behavior; and
- Windows file-symlink capability refusal before managed-path mutation;
- atomic receipt persistence, ownership checks, uninstall, and backup restoration;
- current and stale model-routing age reports at the 31/32-day boundary;
- stable exit codes and actionable diagnostics.

Platform-specific link operations sit behind a narrow internal boundary so Windows behavior can be tested without requiring a Windows host for every unit test. Small platform integration tests exercise real links on each supported operating system.

## Runbook responsibilities

`runbooks/harness-setup/harness-setup.md` becomes a concise human entrypoint. It documents the canonical-root invariant, prerequisites, the install and check commands, the discovery-path matrix, and recovery instructions. Detailed path manipulation belongs in the tested Python installer rather than copied PowerShell, Bash, and zsh command blocks.

Always-on guidance contains only the routing rule needed during normal sessions. It does not repeat setup commands or load the runbook unless discovery is missing or repair is requested. Harness-specific details remain in the runbook or progressively loaded references, minimizing normal-session token cost.

Repository integration is fixed deliberately: the project lives at `secret-agents/` under the repository root and CI lives at `.github/workflows/secret-agents.yml`. Plan and Git commands run from the repository root unless a command explicitly declares `secret-agents` as its working directory. GitHub Actions path filters must name `secret-agents/**` literally; executable steps use one workflow-level project-directory value rather than repeating the subdirectory.

## Rejected alternatives

### Put the canonical repository directly under the home directory

Rejected because native harness discovery paths already provide a stable home-level interface. Requiring a particular checkout location couples source control organization to harness behavior and does not help container distribution.

### Search common filesystem roots

Rejected because multiple checkouts and backup mirrors are expected. Search order can silently select stale content. Explicit configuration and self-location are deterministic.

### Maintain separate setup skills for each harness

Rejected because harness setup is one user goal with shared root resolution, safety, and verification. Separate skills would duplicate policy and cannot solve first-time bootstrap discovery. One runbook and installer use data-driven harness adapters instead.

### Install shared skills into every project

Rejected because it creates divergent editable copies, repository noise, and unclear ownership. Project-local skills remain available for genuinely project-owned or remote-runtime workflows.

### Clone or fetch skills when a container starts

Rejected because it introduces mutable deployments, credentials, network dependency, and source-version drift. Production images use build-time immutable bundles.

### Implement container packaging now

Rejected under YAGNI. The design preserves a packaging boundary, but the required agent runtime, image layout, and deployment pipeline do not yet exist.

### Use hardlinks or copied instruction files on Windows

Rejected because hardlinks are volume-bound and can detach from a canonical file replaced atomically, while copied files immediately create a second editable source. The installer instead makes file-symlink capability an explicit, tested prerequisite and fails before changing managed destinations.
