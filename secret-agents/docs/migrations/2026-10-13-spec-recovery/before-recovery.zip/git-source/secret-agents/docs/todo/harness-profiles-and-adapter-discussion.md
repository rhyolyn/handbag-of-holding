# Harness Profiles & the "Adapters" Boundary — Discussion, Decision, and Handoff

**Date:** 2026-08-29
**Repo:** `handbag-of-holding` → `secret-agents/`
**Status:** Load-bearing move DONE (seam established). Full migration DEFERRED.
**Author of this note:** Claude (Opus 4.8) working session with rhyolyn

---

## 1. Problem this addresses

`secret-agents`' job is to set up the environment so one canonical skill set runs on
any supported harness (Codex, Claude, Copilot). Harness-specific knowledge is starting
to leak **into the skills themselves** as inline `if claude / if codex` branching.

Concrete examples already in the tree:
- **Model recommendations** — `skills/update-model-routing/SKILL.md` already branches on
  "Codex / OpenAI IDs vs `sources.codex`" in prose (see line ~31).
- **Cost analysis** — harness-specific token rates / cost logic embedded in skills.

Left alone, this trends toward `if claude … / if codex …` scattered across many skills.
The expensive future refactor is *finding and untangling* that sprawl. The owner wants a
direction to trend toward now so that later cleanup stays mechanical, **without reworking
any of it today**.

## 2. Root cause (the real issue, not the symptom)

The triggering question was cosmetic — "why is `adapters.py` named that when it does one
thing (`build_projections`)?" That's a symptom. The disease: **there is no single home for
"facts and behaviors that vary by harness,"** so each new per-harness fact lands wherever
it is first needed (a skill's prose, a script, a projection table). Fix the home and the
name resolves itself.

Verification done during the session: across all of `secret-agents/src/`, `Harness` was
branched on in **exactly one module** (the old `adapters.py`). So harness-specific *code*
was already centralized; the leak is into *skill content*, which is the thing to get ahead
of.

## 3. Decision: target concept = per-harness `HarnessProfile` registry

Elevate the abstraction from "an adapter that builds projections" to **one record per
harness that owns everything that varies by harness**. Projections become facet #1; the
owner's own examples slot in as future facets:

```
HarnessProfile(codex):
  projections  -> _PROFILES[codex].projections     # facet 1 (exists today)
  cost         -> token rates / cost-analysis data  # facet 2 (in skills today → migrate)
  models       -> recommended model IDs, routing     # facet 3 (in skills today → migrate)
  invocation   -> how skills are named/invoked        # facet 4 (future)
```

**Naming rationale:** most of what's anticipated is *data* (cost rates, model IDs), not
behavior. A registry of per-harness *facts* is a **profile**, not an "adapter" — the plural
"adapters" only earns its name if the facets become *callables* (transform functions, link
strategies). Hence the module is now `harness_profiles.py`, and `build_projections` is one
reader over `profile.projections`. If behavior-callables later dominate, revisit the name
then — it's cheap to rename again with history preserved.

## 4. The boundary rule that prevents the sprawl

**Skills never branch on harness. They consume resolved values.** One rule holds the line.
Two resolution modes; the split matters:

- **Bake at projection time — PREFER this for skill *content*.** When a skill is projected
  to a harness, harness-specific values are substituted so the *projected* `SKILL.md` is
  already specialized; the *canonical* skill carries a placeholder, not an `if`. This is the
  natural extension of what the projection layer already does (it projects content, not just
  links). Cost rates and model IDs are both data resolved this way — no runtime branching.
- **Runtime lookup — the EXCEPTION**, only for scripts that genuinely cannot be specialized
  ahead of time. A tiny `harness_profile()` accessor a skill script calls. Keep rare: every
  runtime lookup is a dependency from skills back into the package.

## 5. What was actually done this session (the load-bearing move)

Only #1 below is load-bearing for "avoid a massive refactor later": give the knowledge a
single named home so it stops accreting in scattered places. Everything else is deferred.

**Done & verified:**
- `git mv src/secret_agents_setup/adapters.py → harness_profiles.py` (history preserved).
- `git mv tests/test_adapters.py → tests/test_harness_profiles.py`; import updated.
- Introduced `@dataclass(frozen=True) class HarnessProfile` with a single field
  `projections: tuple[_ProjectionSpec, ...]`. Replaced the bare
  `_PROJECTION_SPECS: dict[Harness, tuple[...]]` with
  `_PROFILES: dict[Harness, HarnessProfile]`. `_selected_specs` now reads
  `_PROFILES[harness].projections`.
- Public API unchanged: `build_projections(root, home, harnesses) -> tuple[Projection, ...]`.
- Module docstring rewritten to state the intent: profiles are the home for per-harness
  facts; add a field here rather than branching on `Harness` in skills/planning.

**Verification:**
- `tests/test_harness_profiles.py`: 6/6 pass (dedup, ordering, shared-source contracts hold).
- `ruff check` clean on the changed source + test.
- Behavior preserved — this was a pure structural/rename change, no contract change.
- Pre-existing, unrelated failures NOT caused by this change and left alone: `test_skills_readme`
  (needs the `markdown` package, not installed), a Windows link-probe test in `test_links`,
  a repo-wide `mypy` error from a numpy stub under Python 3.14, and pre-existing `E501`
  line-length debt in `catalog.py`/`links.py`. The renamed test file also has pre-existing
  ruff-format collapse suggestions in its *bodies* — left out of this diff to keep the rename
  focused; fold them in whenever that test file is next touched.

**Not done (deliberately deferred):** no `HarnessProfile` callables, no runtime
`harness_profile()` API, no migration of cost/model logic out of skills, no CI guard.

## 6. Migration path (incremental, do when convenient — not a big-bang)

1. **DONE — establish the seam.** `harness_profiles.py` + `HarnessProfile`. New per-harness
   facts now have an obvious destination.
2. **Write down the rule** in one place (package README or `CLAUDE.md`): "No harness
   conditionals in skills; harness-specific values are resolved via the harness profile."
3. **Migrate model recommendations** → add `models` facet to `HarnessProfile`; make
   `update-model-routing` consume resolved values instead of branching in prose.
4. **Migrate cost analysis** → add `cost` facet; same treatment.
5. **Add a projection-time content-resolution pass** if/when a skill's *body* (not just its
   file location) needs harness-specific substitution. This is the bigger design step; only
   take it when a real skill needs it.
6. **Enforce with a CI guard when worth it.** The repo already leans on architecture guards
   (`skills/architecture-guards`). A grep-based guard that fails on `if.*claude|if.*codex`
   inside `skills/` is the natural tripwire — add it *after* the cost/model cleanup so it
   doesn't fail on day one, and it keeps the boundary from re-eroding.

## 7. Open questions for the next session

- **Content resolution mechanism:** how does "bake at projection time" substitute into skill
  *bodies*? Placeholder syntax? A per-harness values file the projection step reads? This is
  the crux of step 5 and is currently unspecified.
- **Where do cost/model facts live as data?** Inline in `HarnessProfile` (Python), or in the
  existing `model-routing.json` / pricing JSON that skills already read, with `HarnessProfile`
  pointing at them? Leaning toward the profile referencing existing JSON sources rather than
  duplicating them.
- **Runtime accessor shape:** if a `harness_profile()` runtime API is ever needed, how does a
  skill script discover which harness it's running under? (Env var set at projection time?
  A marker file in the projected dir?)
- **Naming recheck:** if facets trend toward callables rather than data, reconsider
  `harness_profiles.py` vs an `adapters`/`strategies` framing.

## 8. Handoff prompt (paste into a fresh session to resume)

> **Context:** In `handbag-of-holding/secret-agents/`, harness-specific knowledge (cost
> analysis, model recommendations) is leaking into skill content as inline `if claude / if
> codex` branching. We already made the load-bearing move: renamed `adapters.py` →
> `harness_profiles.py` and introduced a `HarnessProfile` frozen dataclass whose only field
> today is `projections`. The intent is that `HarnessProfile` becomes the single home for
> everything that varies by harness (projections, cost, models, invocation), and that
> **skills never branch on harness** — they consume values resolved either at projection time
> (preferred, for content) or via a small runtime accessor (exception). Full context:
> `C:\git\worky\Projects\builder_planning\harness-profiles-and-adapter-discussion.md`.
>
> **Task:** Pick up at migration step 3 — add a `models` facet to `HarnessProfile` and make
> the `update-model-routing` skill consume resolved per-harness model values instead of
> branching in its prose. Before writing code, resolve open question "Where do cost/model
> facts live as data?" (inline in the profile vs the profile pointing at the existing
> `model-routing.json`). Use the brainstorming skill to settle the data-location decision and
> the projection-time content-resolution mechanism, present a short design, and get approval
> before implementing. Keep `build_projections`' public contract unchanged; follow the repo's
> Python quality gate (mypy, ruff check, ruff format, pytest) before committing.

---

*This note is a discussion/decision record, not an approved implementation spec. Steps 3–6
still require brainstorming + approval per the repo's workflow before any code is written.*
