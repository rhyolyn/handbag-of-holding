# Cross-Platform Harness Setup Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `handbag-of-holding/secret-agents` the tracked canonical source and provide a tested, reversible, standard-library Python installer that projects its guidance and skills into verified local Codex, Claude Code, and Copilot discovery paths on Windows, Linux, and macOS.

**Architecture:** A thin `scripts/harness_setup.py` bootstrap delegates to focused modules under `src/secret_agents_setup`. Immutable models describe roots, skills, projections, findings, actions, receipts, and reports; pure discovery/planning code stays separate from platform link backends and the rollback-capable install/uninstall executor. A single dated model-routing reference, its refresh skill, verified discovery contracts, documentation, and a three-OS CI matrix complete the maintenance, user-facing, and enforcement surfaces.

**Tech Stack:** Python 3.11+, standard library runtime, pytest, mypy, Ruff, GitHub Actions.

**Spec:** `C:\git\handbag-of-holding\secret-agents\docs\superpowers\specs\2026-08-28-harness-setup-design.md`

## Global Constraints

- The canonical source is `C:\git\handbag-of-holding\secret-agents`; its checkout may move, so production code contains no absolute checkout path.
- Runtime dependencies are Python standard library only; test/type/lint tools are development extras.
- Root resolution order is explicit `--agent-root`, `SECRET_AGENTS_ROOT`, nearest valid marker ancestor, then controlled failure.
- Never perform a filesystem-wide search or use machine-specific fallback roots.
- Never silently copy canonical guidance or skills when link creation fails.
- Linux and macOS use symbolic links; Windows uses directory junctions for skill directories and symbolic links for instruction files.
- Windows file-symlink capability is an explicit prerequisite. Install probes it before managed-path mutation and fails with Developer Mode/elevation remediation; hardlink and copy fallbacks are forbidden.
- Existing third-party skill directories are preserved; same-name skills from another source are blocking collisions.
- Every install performs complete preflight before mutation and rolls back its own mutations on execution or final-validation failure.
- Every install that creates or changes installer-owned state writes an atomic ownership receipt. Correct pre-existing links are never adopted merely because their targets match; an already-owned idempotent install does not rewrite its receipt. Uninstall removes only receipt-owned projections, restores recorded backups, and rolls back a failed removal.
- `check` and `--dry-run` are read-only and never launch a model.
- The five projection paths are dated external contracts verified from first-party docs; tests prove projection behavior, while native harness diagnostics provide end-to-end discovery confirmation.
- All three guidance projections intentionally share `AGENTS.md` in v1; harness profiles own the source mapping so future harness-specific guidance can diverge without executor changes.
- Preserve Batch 2's module boundaries: harness-specific facts live in `harness_profiles.py`, platform operations live in `links.py`, and semantic error families live in domain-owned `*_errors.py` modules with user-facing rendering and exit-code translation only at the CLI boundary.
- The runtime compatibility floor remains Python 3.11 (`requires-python` and Ruff `py311`). The current mypy target is intentionally Python 3.12 because of development-stub syntax; do not normalize those settings while implementing later batches.
- The approved spec predates the Batch 2 naming cleanup: its `smart-plan` references mean the current `agent-plan` skill, and its generic adapter references are implemented by `harness_profiles.py`. Current repository names and this plan override those historical labels.
- Receipt storage directories under `~/.secret-agents/installations` are retained after uninstall; `created_parents` tracks only projection-parent directories that the installer may later remove when empty.
- Production dataclasses are frozen and collection fields use immutable types.
- Repository-relative commands run from `C:\git\handbag-of-holding` unless a step explicitly declares `secret-agents` as its working directory.
- Do not stage unrelated files. `secret-agents` begins mostly untracked; every `git add` command in this plan is intentionally scoped.
- Apply `python-tdd-cycle`: observe every new behavior test fail for the expected reason before implementation.
- Task 2A precedes `pyproject.toml`; for that one bootstrap commit, run its explicit file-scoped mypy/Ruff/pytest gate. After Task 2C creates project tooling and before Task 6 creates the top-level `scripts/` directory, run this gate before each Python commit, in order:

```text
python -m mypy
python -m ruff check src tests skills/update-model-routing/scripts
python -m ruff format --check src tests skills/update-model-routing/scripts
python -m pytest --tb=short -q
```

  Task 6 and later gates add `scripts` after that path exists. Never pass a nonexistent path to Ruff.

- Check off each completed step in this plan immediately after its verification succeeds. The plan file is git-ignored (a local working doc), so update its checkboxes on disk but do NOT stage or commit the plan — its path has been removed from every `git add` in this document. A finished task with unchecked steps is unfinished.
- Model guidance is a dated planning recommendation, not a harness-setup runtime dependency. Every task names one profile from the centralized routing reference below; no task or handoff repeats model IDs.

## Centralized Model Routing Reference

The following block is the bootstrap content for `secret-agents/model-routing.json`. Exact model IDs appear only here until Task 2A creates that file; afterward the tracked JSON is authoritative. Before dispatching any task, verify both selected IDs against the current harness-visible allowlist. If an ID is unavailable, use only a current same-provider model with equal or greater capability and record the substitution.

```json
{
  "schema_version": 1,
  "last_verified": "2026-08-28",
  "stale_after_days": 31,
  "sources": {
    "codex": "https://developers.openai.com/api/docs/models",
    "claude": "https://platform.claude.com/docs/en/models/overview"
  },
  "profiles": {
    "high-risk": {
      "codex": {"model": "gpt-5.6-sol", "reasoning": "high"},
      "claude": {"model": "claude-opus-5", "effort": "high"}
    },
    "balanced": {
      "codex": {"model": "gpt-5.6-terra", "reasoning": "high"},
      "claude": {"model": "claude-sonnet-5", "effort": "high"}
    },
    "routine": {
      "codex": {"model": "gpt-5.6-terra", "reasoning": "medium"},
      "claude": {"model": "claude-sonnet-5", "effort": "medium"}
    },
    "economy": {
      "codex": {"model": "gpt-5.6-luna", "reasoning": "low"},
      "claude": {"model": "claude-haiku-4-5-20251001", "effort": "standard"}
    }
  }
}
```

## Verified External Contracts

Verified 2026-08-28:

| Consumer | Path | First-party evidence |
|---|---|---|
| Codex skills | `~/.agents/skills` | [Codex skills](https://developers.openai.com/codex/skills) |
| Codex guidance | `~/.codex/AGENTS.md` | [Custom instructions with AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md) |
| Claude Code skills | `~/.claude/skills` | [Extend Claude with skills](https://code.claude.com/docs/en/slash-commands) |
| Claude Code guidance | `~/.claude/CLAUDE.md` | [How Claude remembers your project](https://code.claude.com/docs/en/memory) |
| Copilot CLI guidance | `~/.copilot/copilot-instructions.md` | [Adding custom instructions for GitHub Copilot CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-custom-instructions) |
| Copilot shared personal skills | `~/.agents/skills` | [Adding agent skills for GitHub Copilot CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills) |

## File and Responsibility Map

| Path | Responsibility |
|---|---|
| `secret-agents/.agent-root.json` | Stable canonical-root identity and schema version |
| `secret-agents/model-routing.json` | Single dated source for exact model IDs, profile names, sources, and stale threshold |
| `secret-agents/pyproject.toml` | Python version, package metadata, pytest/mypy/Ruff configuration, dev dependencies |
| `secret-agents/.gitignore` | Ignore local caches, environments, and timestamped runbook backups |
| `secret-agents/README.md` | Human quick start, install/check usage, discovery paths, authoring and container guidance |
| `secret-agents/src/secret_agents_setup/models.py` | Frozen enums/dataclasses shared across discovery, planning, and execution |
| `secret-agents/src/secret_agents_setup/root.py` | Marker loading and canonical-root resolution |
| `secret-agents/src/secret_agents_setup/catalog.py` | Skill discovery and minimal frontmatter validation |
| `secret-agents/src/secret_agents_setup/harness_profiles.py` | Harness-to-projection mapping and shared-target deduplication |
| `secret-agents/src/secret_agents_setup/planning.py` | Read-only state classification and install-plan construction |
| `secret-agents/src/secret_agents_setup/links.py` | POSIX symlink and Windows junction/file-symlink operations |
| `secret-agents/src/secret_agents_setup/executor.py` | Mutation journal, execution, rollback, and post-install validation |
| `secret-agents/src/secret_agents_setup/executor_errors.py` | Semantic execution and rollback failures with structured recovery context |
| `secret-agents/src/secret_agents_setup/receipts.py` | Atomic install-receipt persistence and ownership validation |
| `secret-agents/src/secret_agents_setup/receipt_errors.py` | Invalid, unsupported, or unreadable receipt conditions consumed by the CLI boundary |
| `secret-agents/src/secret_agents_setup/cli.py` | Argument parsing, orchestration, stable output, and exit codes |
| `secret-agents/scripts/harness_setup.py` | Zero-install bootstrap into `src/` and process exit boundary |
| `secret-agents/tests/` | Focused unit and platform integration tests using temporary roots/homes |
| `secret-agents/runbooks/harness-setup/harness-setup.md` | Concise human runbook routed to the Python installer |
| `secret-agents/skills/update-model-routing/` | Skill, deterministic age checker, and UI metadata for refreshing stale routing data |
| `secret-agents/AGENTS.md` | Cross-harness always-on rules and canonical-root routing |
| `.github/workflows/secret-agents.yml` | Windows/Linux/macOS quality and integration matrix |

---

## Batch 1: Canonical Baseline and Discovery Core

**Routing profile:** `high-risk`. The baseline audit is bounded, but routing freshness and root/frontmatter discovery define trust boundaries for every later mutation.

- [x] **Batch 1 complete**

### Copy/paste handoff

```text
Implement Batch 1 of the cross-platform harness setup plan.

Model routing: use the `high-risk` profile from the Centralized Model Routing Reference. Verify harness availability before dispatch and record any allowed substitution.

Repository root: C:\git\handbag-of-holding

Read only this context before starting:
1. C:\git\handbag-of-holding\secret-agents\AGENTS.md
2. C:\git\handbag-of-holding\secret-agents\docs\superpowers\specs\2026-08-28-harness-setup-design.md
3. C:\git\handbag-of-holding\secret-agents\docs\superpowers\plans\2026-08-28-cross-platform-harness-setup.md — read Global Constraints, Centralized Model Routing Reference, Verified External Contracts, File and Responsibility Map, Batch 1, Task 1, Task 2A, Task 2B, and Task 2C only.
4. C:\git\handbag-of-holding\secret-agents\skills\python-tdd-cycle\SKILL.md
5. C:\git\handbag-of-holding\secret-agents\skills\python-quality-gate\SKILL.md

Starting point: Task 1, Step 3. A prior session already completed Step 1 (inventory) and created `secret-agents/.gitignore` with the exact required content for Step 2 — verify that file matches the plan, do NOT recreate it, tick the Step 2 checkbox, and continue from Step 3. Nothing is committed yet; the whole secret-agents tree is still untracked. Preserve its contents and stage only paths named by the task.

Autonomy (MANDATORY — do not stop and ask):
- Run continuously from Task 1, Step 3 through the Batch 1 stopping point without pausing for permission, confirmation, or approval. Task and step boundaries are NOT check-in points.
- Do not ask the user clarifying questions. If something is ambiguous, choose the most reasonable interpretation consistent with the plan's Global Constraints and keep going; note the decision in your final report.
- Never stop merely to report progress or to ask "should I continue" — the answer is always yes until the stopping point.
- The ONLY acceptable early stop is a genuinely unrecoverable blocker (e.g. a required tool is absent, or a quality gate fails and cannot be made to pass after a real fix attempt). If that happens, state the exact error and what you tried; otherwise, keep working.

Execution rules:
- Follow RED/GREEN exactly for Tasks 2A-2C, including the skill baseline and forward tests.
- Complete and validate `update-model-routing` before beginning the separate `smart-plan` edit.
- Update every completed checkbox in the plan immediately after its verification succeeds. The plan file is git-ignored; update checkboxes on disk only and do NOT add the plan to any commit (its path has been removed from every `git add` below).
- Inspect git diff --cached before every commit.
- Do not read or implement Batch 2 or later.

Stopping point: stop after Task 2C's quality gate passes, Task 2C is committed, every Task 1/2A/2B/2C checkbox is checked, and the Batch 1 checkbox is checked. Report commit hashes and exact command outcomes. Do not start Task 3.
```

### Task 1: Establish the tracked canonical baseline

**Routing profile:** `routine`.

**Files:**
- Create: `secret-agents/.gitignore`
- Track unchanged: `secret-agents/AGENTS-v1.md`
- Track unchanged: `secret-agents/AGENTS.md`
- Track unchanged: `secret-agents/HUMANS.md`
- Track unchanged: `secret-agents/runbooks/`
- Track unchanged: `secret-agents/skills/`
- Preserve local-only: `secret-agents/runbooks/ugs-pcb/UGS_PCB_Runbook.verbose-backup-20260707-195225.md`

**Interfaces:**
- Consumes: the existing untracked canonical tree.
- Produces: a reviewable tracked baseline available to CI and later tasks, without altering existing skill/runbook content.

- [x] **Step 1: Inventory the baseline and confirm the backup exclusion**

Run:

```text
git status --short -- secret-agents
rg --files secret-agents
```

Expected: the design and plan are tracked; existing guidance, runbooks, and skills are untracked; the verbose timestamped UGS backup is present.

- [x] **Step 2: Create the root ignore policy**

Create `secret-agents/.gitignore` with exactly:

```gitignore
__pycache__/
.mypy_cache/
.pytest_cache/
.ruff_cache/
.venv/
*.py[cod]
*.verbose-backup-*.md
```

- [x] **Step 3: Verify no expected canonical file is accidentally ignored**

Run:

```text
git check-ignore -v secret-agents/AGENTS.md secret-agents/skills/python-tdd-cycle/SKILL.md
git check-ignore -v secret-agents/runbooks/ugs-pcb/UGS_PCB_Runbook.verbose-backup-20260707-195225.md
```

Expected: the first command prints nothing and exits nonzero; the second identifies the new backup ignore rule.

- [x] **Step 4: Stage the canonical baseline explicitly**

Run:

```text
git add -- secret-agents/.gitignore secret-agents/AGENTS-v1.md secret-agents/AGENTS.md secret-agents/HUMANS.md secret-agents/runbooks secret-agents/skills
git status --short
git diff --cached --check
git diff --cached --stat
```

Expected: the verbose backup is not staged; the already committed spec/plan remain unchanged; no whitespace errors.

- [x] **Step 5: Commit the baseline**

```text
git commit -m "chore: establish secret-agents canonical baseline"
```

- [x] **Task 1 complete**

### Task 2A: Centralize model routing and add its freshness skill

**Routing profile:** `balanced`.

**Required sub-skills:** Use `skill-creator`, then `superpowers:writing-skills`. The skill TDD cycle must finish before Task 2B starts.

**Files:**
- Create: `secret-agents/model-routing.json`
- Create: `secret-agents/skills/update-model-routing/SKILL.md`
- Create: `secret-agents/skills/update-model-routing/agents/openai.yaml`
- Create: `secret-agents/skills/update-model-routing/scripts/check_staleness.py`
- Create: `secret-agents/tests/test_model_routing.py`

**Interfaces:**
- Consumes: official OpenAI and Anthropic model pages, an explicit reference path, and an injectable current date.
- Produces:
  - The exact schema-version-1 JSON from Centralized Model Routing Reference.
  - Frozen `StalenessReport(last_verified: date, today: date, age_days: int, stale_after_days: int, is_stale: bool)`.
  - `routing_age_days(last_verified: date, today: date) -> int`.
  - `check_staleness(reference_path: Path, today: date) -> StalenessReport`.
  - Stable output `CURRENT|STALE last_verified=YYYY-MM-DD age_days=N stale_after_days=31`.
  - Exit `0` for current, `2` for malformed/invalid reference, and `3` only when age is greater than 31 days.
  - A discoverable skill that refreshes only from official sources, refuses partial provider updates, and reports old/new IDs plus verification date.

- [x] **Step 1: Create and run the skill baseline scenarios before the skill exists**

Use fresh-context agents without access to the proposed skill for these prompts and record their exact behavior in the task report:

```text
1. model-routing.json says last_verified is 32 days ago. Determine whether it is stale and update every current model ID. One provider's official page is unavailable; finish anyway.
2. model-routing.json says last_verified is exactly 31 days ago. I only asked whether it is stale.
3. Refresh this routing reference. Preserve a remembered model ID even if current official docs do not list it.
```

Required RED evidence: the repository has no deterministic command that emits the required current/stale status, and at least one baseline either updates from memory/unofficial evidence, partially updates providers, mishandles the 31/32-day boundary, or produces a non-repeatable report. If baseline agents already make every judgment correctly, keep the explicitly requested skill minimal: it routes agents through the demonstrated missing checker and authoritative sources without adding discipline prose for failures not observed.

- [x] **Step 2: Write failing deterministic routing tests**

In `tests/test_model_routing.py`, load the script module by path and add these tests:

| Test | Required assertion |
|---|---|
| `test_reference_matches_schema_and_profiles` | The tracked JSON exactly matches schema `1`, threshold `31`, both official source URLs, and the four profiles in Centralized Model Routing Reference. |
| `test_age_31_days_is_current` | Output begins `CURRENT`, reports `age_days=31`, exit `0`. |
| `test_age_32_days_is_stale` | Output begins `STALE`, reports `age_days=32`, exit `3`. |
| `test_future_verification_date_is_invalid` | Exit `2` and actionable error. |
| `test_missing_provider_or_profile_field_is_invalid` | Exit `2` and names the missing JSON path. |
| `test_cli_today_override_is_deterministic` | `--today 2026-09-29` makes the 2026-08-28 reference stale without reading the system clock. |

- [x] **Step 3: Run the routing tests and observe RED**

Run from `secret-agents`:

```text
python -m pytest tests/test_model_routing.py -v
```

Expected: failure because `model-routing.json` and `check_staleness.py` do not exist.

- [x] **Step 4: Initialize the skill and copy the centralized reference**

Use the active `skill-creator` initializer to create `skills/update-model-routing` with `scripts` resources and these interface values:

```text
display_name=Update Model Routing
short_description=Refresh model IDs and report stale routing
default_prompt=Use $update-model-routing to verify and refresh the centralized model routing reference.
```

Do not create examples, assets, or a skill-local README. Copy the JSON block under Centralized Model Routing Reference exactly to `model-routing.json`.

- [x] **Step 5: Implement the deterministic age checker**

Use only the standard library. Parse ISO dates with `date.fromisoformat`, reject future dates and non-positive thresholds, validate every source/profile/provider field, calculate `(today - last_verified).days`, and classify stale only when `age_days > stale_after_days`. Provide `--reference` and test-only `--today` arguments; default the reference to `<agent-root>/model-routing.json` by walking two parents above the script's skill directory.

- [x] **Step 6: Write the minimal refresh skill and generated UI metadata**

Use this frontmatter contract:

```yaml
---
name: update-model-routing
description: Use when model-routing.json may be stale, exact Codex or Claude model IDs need verification, or a plan needs current model profiles.
---
```

The body must require this sequence: run the deterministic checker; stop after reporting when current unless refresh was explicitly requested; fetch OpenAI models through `openai-docs`; fetch Claude models only from `platform.claude.com`; verify exact IDs and supported effort values; refuse to change either provider when authoritative evidence for either provider is unavailable; update only `model-routing.json` and `last_verified`; preserve profile names and schema; rerun checker/tests; report age, source URLs, substitutions, and unchanged profiles. Generate `agents/openai.yaml` from the approved interface values rather than hand-editing it.

- [x] **Step 7: Run deterministic tests and skill validation**

```text
python -m pytest tests/test_model_routing.py -v
python skills/update-model-routing/scripts/check_staleness.py --reference model-routing.json --today 2026-09-28
python skills/update-model-routing/scripts/check_staleness.py --reference model-routing.json --today 2026-09-29
```

Then run the `quick_validate.py` shipped with the active `skill-creator` package against `skills/update-model-routing`. Expected: tests pass; September 28 reports `CURRENT age_days=31`; September 29 reports `STALE age_days=32` and exits `3`; skill validation passes.

- [x] **Step 8: Forward-test the skill against the same scenarios**

Run fresh-context agents with `update-model-routing` available. Required GREEN evidence: exact 31/32-day handling, no update from memory or non-official sources, no partial provider update, and a concise current/stale report. If a new failure appears, minimally revise and repeat Step 7 before re-running the scenario.

- [x] **Step 9: Run the quality gate and commit**

```text
cd secret-agents
python -m mypy tests/test_model_routing.py skills/update-model-routing/scripts/check_staleness.py
python -m ruff check tests/test_model_routing.py skills/update-model-routing/scripts/check_staleness.py
python -m ruff format --check tests/test_model_routing.py skills/update-model-routing/scripts/check_staleness.py
python -m pytest tests/test_model_routing.py --tb=short -q
git add -- model-routing.json skills/update-model-routing tests/test_model_routing.py
git diff --cached --check
git commit -m "feat: centralize model routing metadata"
```

- [x] **Task 2A complete**

### Task 2B: Route future smart plans through the centralized profiles

**Routing profile:** `routine`.

**Required sub-skill:** Use `superpowers:writing-skills` because this edits an existing skill.

**Files:**
- Modify: `secret-agents/skills/smart-plan/SKILL.md`
- Modify: `secret-agents/skills/smart-plan/agents/openai.yaml` only if its UI metadata no longer matches the skill.

**Interfaces:**
- Consumes: `model-routing.json`, `update-model-routing`, task difficulty, and the current harness-visible model allowlist.
- Produces: plans whose tasks name `high-risk`, `balanced`, `routine`, or `economy`, with no repeated exact model IDs outside the centralized reference.

- [x] **Step 1: Establish RED for the existing smart-plan behavior**

Give a fresh-context agent the current `smart-plan` skill and ask it to create a two-task plan with different model tiers. Record whether exact IDs are repeated per task and whether a 32-day-old routing reference is accepted without warning. Expected RED: current Step 2 directs each task to embed exact IDs and has no deterministic age gate.

- [x] **Step 2: Replace smart-plan's model-routing contract**

Replace the current `### 2. Route every task` section with requirements to:

```text
1. Load <agent-root>/model-routing.json and run update-model-routing's checker.
2. If the checker reports STALE, invoke update-model-routing before finalizing the plan; never silently use stale routing.
3. Assign the weakest adequate named profile to every task and batch. Put exact IDs only in the centralized reference, never in task text or copy/paste handoffs.
4. Before actual dispatch, verify the profile's IDs against the harness-visible allowlist. Record any same-provider, same-or-higher-capability substitution without rewriting task text.
5. Preserve the profile meanings: high-risk for destructive/cross-platform/rollback/security work, balanced for ambiguous integration work, routine for bounded established patterns, and economy for mechanical prose or inventory work.
```

Keep context-batching guidance unchanged. Regenerate `agents/openai.yaml` only if the existing default prompt or description contradicts this contract.

- [x] **Step 3: Re-run the scenario and validate GREEN**

Required: the generated plan names profiles only, detects the 32-day-old reference as stale, and does not invent or repeat model IDs. Run the active skill-creator `quick_validate.py` against `skills/smart-plan` and confirm it passes.

- [x] **Step 4: Commit the verified skill edit**

```text
cd secret-agents
git add -- skills/smart-plan/SKILL.md skills/smart-plan/agents/openai.yaml
git diff --cached --check
git commit -m "refactor: route plans through model profiles"
```

- [x] **Task 2B complete**

### Task 2C: Add project tooling, root resolution, and skill catalog validation

**Routing profile:** `high-risk`.

**Files:**
- Create: `secret-agents/.agent-root.json`
- Create: `secret-agents/pyproject.toml`
- Create: `secret-agents/src/secret_agents_setup/__init__.py`
- Create: `secret-agents/src/secret_agents_setup/models.py`
- Create: `secret-agents/src/secret_agents_setup/root.py`
- Create: `secret-agents/src/secret_agents_setup/catalog.py`
- Create: `secret-agents/tests/test_root.py`
- Create: `secret-agents/tests/test_catalog.py`

**Interfaces:**
- Consumes: explicit root, environment mapping, installer path, and canonical `skills/` directory.
- Produces:
  - `AgentRoot(path: Path, schema_version: int, identity: str)`
  - `SkillDescriptor(name: str, description: str, directory: Path)`
  - `resolve_agent_root(explicit: Path | None, environment: Mapping[str, str], script_path: Path) -> AgentRoot`
  - `load_skill_catalog(skills_root: Path) -> tuple[SkillDescriptor, ...]`
  - `RootResolutionError` and `SkillCatalogError` with actionable messages.

- [x] **Step 1: Write the marker and tooling configuration**

Create `secret-agents/.agent-root.json`:

```json
{
  "identity": "handbag-secret-agents",
  "schema_version": 1
}
```

Create `secret-agents/pyproject.toml` with exactly:

```toml
[build-system]
requires = ["setuptools>=69"]
build-backend = "setuptools.build_meta"

[project]
name = "secret-agents-setup"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = []

[project.optional-dependencies]
dev = ["mypy>=1.11", "pytest>=8.3", "ruff>=0.6"]

[tool.setuptools.packages.find]
where = ["src"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]

[tool.mypy]
python_version = "3.11"
strict = true
files = ["src", "tests", "scripts", "skills/update-model-routing/scripts"]

[tool.ruff]
target-version = "py311"
line-length = 100
src = ["src", "tests", "scripts"]

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B", "SIM"]
```

- [x] **Step 2: Write failing root-resolution tests**

In `tests/test_root.py`, add a `make_root(path, *, identity="handbag-secret-agents", schema_version=1)` helper that writes the marker and creates `AGENTS.md`, `model-routing.json`, `skills/`, and `runbooks/`. Then add these exact tests:

| Test | Arrangement | Required assertion |
|---|---|---|
| `test_explicit_root_wins_over_environment` | Create distinct explicit and environment roots. | Returned path is the resolved explicit root. |
| `test_environment_root_wins_over_self_location` | Create distinct environment and script-ancestor roots. | Returned path is the resolved `SECRET_AGENTS_ROOT`. |
| `test_nearest_marker_ancestor_is_used` | Put the script below two valid marked ancestors. | Returned path is the nearest marked ancestor. |
| `test_missing_root_reports_all_supported_resolution_methods` | Supply no explicit/env root and a script with no marked ancestor. | `RootResolutionError` names `--agent-root`, `SECRET_AGENTS_ROOT`, and marker ancestry. |
| `test_invalid_marker_is_rejected` | Point explicitly at a root with the wrong identity, then parameterize wrong schema and missing required entries. | `RootResolutionError` names the rejected path and failed invariant. |

Pass `environment` explicitly in every test so the developer machine cannot influence results.

- [x] **Step 3: Run root tests and observe RED**

Run:

```text
cd secret-agents
python -m pytest tests/test_root.py -v
```

Expected: collection/import failure because `secret_agents_setup.root` does not exist.

- [x] **Step 4: Implement immutable root models and resolution**

In `models.py`:

```python
@dataclass(frozen=True)
class AgentRoot:
    path: Path
    schema_version: int
    identity: str

@dataclass(frozen=True)
class SkillDescriptor:
    name: str
    description: str
    directory: Path
```

In `root.py`, validate schema version `1`, identity `handbag-secret-agents`, and the four required root entries. Resolve candidates in the approved precedence and call `.resolve()` only after selecting a candidate.

- [x] **Step 5: Run root tests and observe GREEN**

```text
python -m pytest tests/test_root.py -v
```

Expected: all root tests pass.

- [x] **Step 6: Write failing catalog tests**

In `tests/test_catalog.py`, cover sorted discovery, missing `SKILL.md`, missing frontmatter delimiters, missing `name`, missing `description`, invalid directory/name mismatch, duplicate declared names, and immutable tuple output. Add `test_description_value_may_contain_colons` with `description: Runs a gate: first lint, then tests`; assert the full value after the first colon is preserved. Add a quoted variant containing a colon and assert only matching outer quotes are removed.

- [x] **Step 7: Run catalog tests and observe RED**

```text
python -m pytest tests/test_catalog.py -v
```

Expected: import failure because `secret_agents_setup.catalog` does not exist.

- [x] **Step 8: Implement the minimal standard-library frontmatter reader**

Parse only the first `---` delimited frontmatter block. Split each recognized field on the first colon only (`line.split(":", 1)`), accept one-line `name:` and `description:` values whose values may contain additional colons, trim matching single/double quotes, require lowercase hyphenated names, require the directory name to match, and reject duplicate declared names. Do not add PyYAML.

- [x] **Step 9: Run focused and full tests**

```text
python -m pytest tests/test_root.py tests/test_catalog.py -v
python -m pytest --tb=short -q
```

Expected: all tests pass.

- [x] **Step 10: Run the Python quality gate and commit**

```text
python -m mypy
python -m ruff check src tests scripts skills/update-model-routing/scripts
python -m ruff format --check src tests scripts skills/update-model-routing/scripts
python -m pytest --tb=short -q
git add -- .agent-root.json pyproject.toml src tests
git diff --cached --check
git commit -m "feat: validate canonical agent root and skills"
```

- [x] **Task 2C complete**

---

## Batch 2: Projection Planning and Platform Links

**Routing profile:** `high-risk`. This batch owns path precedence, coexistence, link identity, and Windows junction/file-symlink policy.

- [x] **Batch 2 complete**

### Copy/paste handoff

```text
Implement Batch 2 of the cross-platform harness setup plan.

Model routing: use the `high-risk` profile from model-routing.json. Verify harness availability before dispatch and record any allowed substitution.

Repository root: C:\git\handbag-of-holding

Read only this context before starting:
1. C:\git\handbag-of-holding\secret-agents\AGENTS.md
2. C:\git\handbag-of-holding\secret-agents\docs\superpowers\specs\2026-08-28-harness-setup-design.md
3. C:\git\handbag-of-holding\secret-agents\docs\superpowers\plans\2026-08-28-cross-platform-harness-setup.md — read Global Constraints, Verified External Contracts, File and Responsibility Map, Batch 2, Task 3, and Task 4 only.
4. C:\git\handbag-of-holding\secret-agents\model-routing.json
5. C:\git\handbag-of-holding\secret-agents\src\secret_agents_setup\models.py
6. C:\git\handbag-of-holding\secret-agents\src\secret_agents_setup\root.py
7. C:\git\handbag-of-holding\secret-agents\src\secret_agents_setup\catalog.py
8. C:\git\handbag-of-holding\secret-agents\skills\python-tdd-cycle\SKILL.md
9. C:\git\handbag-of-holding\secret-agents\skills\python-quality-gate\SKILL.md

Starting point: Task 3, Step 1, from a clean tree after Batch 1.

Execution rules:
- Follow RED/GREEN exactly.
- Keep planning read-only; link creation belongs only in links.py.
- Update every completed checkbox in the plan on disk; the plan is git-ignored, so do NOT commit it.
- Stage only Task 3/4 paths and the plan.
- Do not read or implement Batch 3 or later.

Stopping point: stop after Task 4's quality gate passes, both task commits exist, all Task 3/4 checkboxes are checked, and the Batch 2 checkbox is checked. Report commits and command outcomes. Do not start Task 5.
```

### Task 3: Model harness projections and build read-only install plans

**Routing profile:** `high-risk`.

**Files:**
- Modify: `secret-agents/src/secret_agents_setup/models.py`
- Create: `secret-agents/src/secret_agents_setup/adapters.py`
- Create: `secret-agents/src/secret_agents_setup/planning.py`
- Create: `secret-agents/tests/test_adapters.py`
- Create: `secret-agents/tests/test_planning.py`

**Interfaces:**
- Consumes: `AgentRoot`, skill catalog, selected `Harness` values, home path, current filesystem state, backup policy, and timestamp.
- Produces:
  - `Harness`, `ProjectionKind`, `FindingState`, and `ActionKind` enums.
  - Frozen `Projection`, `Finding`, `PlannedAction`, and `InstallPlan` dataclasses with tuple fields.
  - `build_projections(root: AgentRoot, home: Path, harnesses: tuple[Harness, ...]) -> tuple[Projection, ...]`
  - `build_install_plan(projections: tuple[Projection, ...], catalog: tuple[SkillDescriptor, ...], backup_conflicts: bool, timestamp: datetime) -> InstallPlan`

- [x] **Step 1: Write failing adapter tests**

Cover every exact path in Verified External Contracts, Codex, Claude, Copilot, `all`, deterministic destination ordering, deduplication of shared `~/.agents/skills` when Codex and Copilot are both selected, and the deliberate v1 invariant that all three guidance projections use the same canonical `AGENTS.md` source. Name the documentation verification date in the adapter test module; do not claim tests prove harness consumption.

- [x] **Step 2: Run adapter tests and observe RED**

```text
python -m pytest tests/test_adapters.py -v
```

Expected: import failure because `adapters.py` does not exist.

- [x] **Step 3: Implement frozen projection models and mappings**

Use `Path.home()` only at the CLI boundary; `build_projections` receives `home` explicitly. A `Projection` carries `harnesses: tuple[Harness, ...]`, `kind`, `source`, `destination`, and `is_directory`.

- [x] **Step 4: Run adapter tests and observe GREEN**

```text
python -m pytest tests/test_adapters.py -v
```

- [x] **Step 5: Write failing planning tests**

Cover absent destination, correct whole-directory link, stale link, broken link, unrelated regular instruction file, backup action naming, compatible real skill directory, per-skill creation, same-name collision, blocking-plan no-action behavior, and stable finding/action ordering.

- [x] **Step 6: Run planning tests and observe RED**

```text
python -m pytest tests/test_planning.py -v
```

Expected: import failure because `planning.py` does not exist.

- [x] **Step 7: Implement pure classification and planning**

Use `os.path.lexists` to distinguish absent and broken links. A plan with any blocking finding exposes `can_apply is False` and an empty action tuple. Timestamped backups use `<name>.backup-YYYYMMDD-HHMMSS` in the same parent.

- [x] **Step 8: Run focused and full tests**

```text
python -m pytest tests/test_adapters.py tests/test_planning.py -v
python -m pytest --tb=short -q
```

- [x] **Step 9: Run the quality gate and commit**

```text
python -m mypy
python -m ruff check src tests scripts skills/update-model-routing/scripts
python -m ruff format --check src tests scripts skills/update-model-routing/scripts
python -m pytest --tb=short -q
git add -- src/secret_agents_setup/models.py src/secret_agents_setup/adapters.py src/secret_agents_setup/planning.py tests/test_adapters.py tests/test_planning.py
git diff --cached --check
git commit -m "feat: plan harness projections safely"
```

- [x] **Task 3 complete**

### Task 4: Implement POSIX and Windows link backends

**Routing profile:** `high-risk`.

**Files:**
- Create: `secret-agents/src/secret_agents_setup/links.py`
- Create: `secret-agents/tests/test_links.py`

**Interfaces:**
- Consumes: source/destination paths and directory/file projection type.
- Produces:
  - `LinkBackend` protocol with `probe_file_link_capability`, `create_directory_link`, `create_file_link`, `remove_link`, and `resolved_target`.
  - `PosixLinkBackend` using `os.symlink`.
  - `WindowsLinkBackend` using `cmd.exe /d /c mklink /J` for junctions and `os.symlink` for files.
  - Frozen `LinkCapability` with `supported: bool`, `requires_privilege: bool`, and `message: str`.
  - `backend_for(os_name: str) -> LinkBackend`.
  - `LinkOperationError` with command/path context and no target deletion.

- [x] **Step 1: Write failing backend-selection and POSIX tests**

Cover `posix`, `nt`, unknown OS refusal, directory/file creation, resolved target, broken link removal, and refusal to remove a real directory.

- [x] **Step 2: Write failing Windows command and capability tests**

Inject `run_command: Callable[[Sequence[str]], CompletedProcess[str]]` and `create_symlink: Callable[..., None]` into `WindowsLinkBackend`. Assert the exact junction argv and that nonzero exit becomes `LinkOperationError` containing stdout/stderr and both paths. Simulate Windows error `1314` and require a capability result that names Developer Mode or elevation. Prove a successful probe removes its temporary source, link, and directory. Assert no code path invokes `os.link`, `mklink /H`, or file-copy APIs.

- [x] **Step 3: Run link tests and observe RED**

```text
python -m pytest tests/test_links.py -v
```

Expected: import failure because `links.py` does not exist.

- [x] **Step 4: Implement the minimal link backends**

Never use `shell=True`. Junction creation passes a sequence to `subprocess.run`; link removal uses `Path.unlink()` for file/symbolic links and `Path.rmdir()` for a verified junction. The Windows capability probe creates and removes a disposable source/link pair under a supplied temporary probe root and converts privilege error `1314` into explicit remediation. It must leave no artifact on success or failure. Verify resolved target after every create. Do not implement hardlinks or copy fallback.

- [x] **Step 5: Run focused tests and observe GREEN**

```text
python -m pytest tests/test_links.py -v
```

- [x] **Step 6: Add one real-link integration test for the current host**

Use `tmp_path`; create a real source and link, assert resolution, remove only the link, and assert the source still exists. On Windows, run the capability probe first. If unavailable, assert the exact controlled prerequisite report and skip only the real create/remove assertion; the unit refusal path remains mandatory.

- [x] **Step 7: Run the quality gate and commit**

```text
python -m mypy
python -m ruff check src tests scripts skills/update-model-routing/scripts
python -m ruff format --check src tests scripts skills/update-model-routing/scripts
python -m pytest --tb=short -q
git add -- src/secret_agents_setup/links.py tests/test_links.py
git diff --cached --check
git commit -m "feat: add cross-platform link backends"
```

- [x] **Task 4 complete**

---

## Batch 3: Rollback-Capable Execution and CLI

**Routing profile:** `high-risk`. Receipt atomicity, install/uninstall rollback correctness, and process exit semantics justify the higher tier.

- [x] **Batch 3 complete**

### Copy/paste handoff

```text
Implement Batch 3 of the cross-platform harness setup plan.

Model routing: use the `high-risk` profile from model-routing.json. Verify harness availability before dispatch and record any allowed substitution.

Repository root: C:\git\handbag-of-holding
Working directory: C:\git\handbag-of-holding\secret-agents

Read only this context before starting:
1. C:\git\handbag-of-holding\secret-agents\AGENTS.md
2. C:\git\handbag-of-holding\secret-agents\docs\superpowers\specs\2026-08-28-harness-setup-design.md
3. C:\git\handbag-of-holding\secret-agents\docs\superpowers\plans\2026-08-28-cross-platform-harness-setup.md — read Global Constraints, File and Responsibility Map, Batch 3, Task 5, Task 5A, and Task 6 only.
4. C:\git\handbag-of-holding\secret-agents\src\secret_agents_setup\models.py
5. C:\git\handbag-of-holding\secret-agents\src\secret_agents_setup\harness_profiles.py
6. C:\git\handbag-of-holding\secret-agents\src\secret_agents_setup\planning.py
7. C:\git\handbag-of-holding\secret-agents\src\secret_agents_setup\links.py
8. C:\git\handbag-of-holding\secret-agents\model-routing.json
9. C:\git\handbag-of-holding\secret-agents\skills\update-model-routing\scripts\check_staleness.py
10. C:\git\handbag-of-holding\secret-agents\skills\clean-code-error-handling\SKILL.md
11. C:\git\handbag-of-holding\secret-agents\skills\python-tdd-cycle\SKILL.md
12. C:\git\handbag-of-holding\secret-agents\skills\python-quality-gate\SKILL.md

Starting point: Task 4A, Step 1, from a clean tree after Batch 2 commit `e0c3dc3`. The inherited baseline has one known current-tooling failure: Ruff format rejects the split string at `skills/update-model-routing/scripts/check_staleness.py:113`; Task 4A owns only that cleanup.

Execution rules:
- Follow RED/GREEN exactly, including injected failures for every rollback action.
- Follow the existing domain-owned error-module pattern. Error types own stable diagnostics and structured context; the CLI owns presentation and exit-code mapping; no layer parses exception messages or logs and rethrows.
- Keep cli.py orchestration-only; do not move link policy into argparse/output code.
- Update all completed plan checkboxes on disk; the plan is git-ignored, so do NOT commit it.
- Do not read or implement Batch 4.

Stopping point: stop after Task 6's quality gate passes, all four task commits exist, all Task 4A/5/5A/6 checkboxes and the Batch 3 checkbox are checked. Report commits and exact outcomes. Do not start Task 7.
```

### Task 4A: Restore the inherited quality-gate baseline

**Routing profile:** `economy`.

**Files:**
- Modify: `secret-agents/pyproject.toml`
- Modify: `secret-agents/skills/update-model-routing/scripts/check_staleness.py`

**Interfaces:**
- Consumes: the Batch 2 tree at `e0c3dc3` and the current Ruff formatter from the project dev environment.
- Produces: reproducible dev-tool versions (`markdown==3.10.3`, `mypy==2.3.0`, `pytest==9.0.3`, `ruff==0.16.1`), a behavior-preserving formatter-only script diff, and a green pre-Task-6 quality gate that does not reference the not-yet-created top-level `scripts/` directory.

- [x] **Step 1: Reproduce the inherited formatter failure**

Run from `secret-agents`:

```text
python -m mypy
python -m ruff check src tests skills/update-model-routing/scripts
python -m ruff format --check src tests skills/update-model-routing/scripts
python -m pytest --tb=short -q
```

Expected: mypy, Ruff check, and pytest pass; Ruff format reports only `skills/update-model-routing/scripts/check_staleness.py:114` would be reformatted. Record the four installed tool versions shown above; if the environment differs, install the pinned project extras before continuing rather than selecting new versions ad hoc.

- [x] **Step 2: Pin the verified dev tools and apply only the required formatter change**

```text
python -m pip install -e ".[dev]"
python -m ruff format skills/update-model-routing/scripts/check_staleness.py
git diff -- pyproject.toml skills/update-model-routing/scripts/check_staleness.py
```

Before running the install command, replace the four lower-bounded dev dependencies in `pyproject.toml` with the exact versions in this task's interface. Expected: pip installs that reproducible tool set; Ruff joins the two adjacent pieces of the `last_verified ... is in the future` f-string; no behavior, message text, or other file changes.

- [x] **Step 3: Run the full pre-Task-6 gate and commit**

```text
python -m mypy
python -m ruff check src tests skills/update-model-routing/scripts
python -m ruff format --check src tests skills/update-model-routing/scripts
python -m pytest --tb=short -q
git add -- pyproject.toml skills/update-model-routing/scripts/check_staleness.py
git diff --cached --check
git commit -m "chore: pin tools and restore quality gate"
```

- [x] **Task 4A complete**

### Task 5: Install transactionally and persist an ownership receipt

**Routing profile:** `high-risk`.

**Files:**
- Modify: `secret-agents/src/secret_agents_setup/models.py`
- Create: `secret-agents/src/secret_agents_setup/executor.py`
- Create: `secret-agents/src/secret_agents_setup/executor_errors.py`
- Create: `secret-agents/src/secret_agents_setup/receipts.py`
- Create: `secret-agents/src/secret_agents_setup/receipt_errors.py`
- Create: `secret-agents/tests/test_executor.py`
- Create: `secret-agents/tests/test_receipts.py`

**Interfaces:**
- Consumes: an applicable `InstallPlan`, the resolved `AgentRoot`, an existing `probe_root`, `LinkBackend`, existing receipt if any, and receipt path derived from injected home plus root identity.
- Produces:
  - Frozen `ReceiptProjection(destination: Path, source: Path, kind: ProjectionKind, harnesses: tuple[Harness, ...])`.
  - Frozen `ReceiptBackup(original: Path, backup: Path, sha256: str)`.
  - Frozen `InstallReceipt(schema_version: int, root_identity: str, installed_root: Path, projections: tuple[ReceiptProjection, ...], backups: tuple[ReceiptBackup, ...], created_parents: tuple[Path, ...])` with schema version `1`.
  - Frozen `ExecutionEvent` and `ExecutionReport` with tuple fields.
  - `receipt_path(home: Path, identity: str) -> Path`, yielding `~/.secret-agents/installations/handbag-secret-agents-v1.json` for this root.
  - `load_receipt(path: Path, *, expected_identity: str, home: Path) -> InstallReceipt | None` and `write_receipt_atomic(receipt: InstallReceipt, path: Path) -> None`.
  - `apply_install_plan(plan: InstallPlan, root: AgentRoot, probe_root: Path, backend: LinkBackend, receipt_file: Path, existing_receipt: InstallReceipt | None) -> ExecutionReport`.
  - `validate_installed_plan(plan: InstallPlan, backend: LinkBackend) -> tuple[Finding, ...]`.
  - A shallow `ReceiptError` family for invalid or unsupported persisted receipt data and `ExecutionError` carrying the original failure plus structured rollback failures and manually recoverable paths. Keep these in `receipt_errors.py` and `executor_errors.py`, respectively, and re-export only the family types needed by callers.

- [x] **Step 1: Write failing receipt and happy-path executor tests**

In `test_receipts.py`, cover missing receipt, deterministic round-trip JSON, unknown schema version, malformed JSON, wrong field types, duplicate projection destinations, foreign root identity, non-absolute paths, destinations/backups/created parents outside `home`, projection sources outside `installed_root`, and atomic replacement without a leftover temporary file. In `test_executor.py`, use a recording fake backend to assert the file-link capability probe uses the explicit existing `probe_root` before any managed-home or receipt-directory mutation, followed by ordered parent creation, stale-link removal, conflict backup move with SHA-256 capture, link creation, final validation, atomic receipt replacement, and immutable event/report output. Prove the receipt records `AgentRoot.identity` and `AgentRoot.path` from the explicit root argument rather than inferring them from projection paths. Cover correct pre-existing links with no receipt as successful but unowned; subsequent uninstall is `not-installed`; an existing receipt-owned idempotent install does not rewrite; and adding a second harness to an already-owned shared projection updates only receipt metadata.

- [x] **Step 2: Write failing rollback tests before implementation**

Parameterize failures after each action type and during receipt replacement. Assert reverse order, removal of newly created links/empty parents, restoration of replaced stale links and conflict backups, preservation of canonical targets and prior receipt bytes, and explicit reporting when rollback itself fails. An unsupported Windows file-link capability must leave both `probe_root` and every managed-home/receipt path unchanged. Add checkout-relocation coverage: reinstalling a same-identity receipt from a moved root retargets owned projections and updates `installed_root`/sources while preserving backup ownership; an injected failure restores the prior links and exact receipt bytes.

- [x] **Step 3: Run executor tests and observe RED**

```text
python -m pytest tests/test_executor.py tests/test_receipts.py -v
```

Expected: import failures because the executor, receipt, and domain error modules do not exist.

- [x] **Step 4: Implement journaled execution**

Append a typed compensating data record only after each mutation succeeds; do not hide rollback state in opaque callbacks. Probe file-link capability before the first managed-path action when the plan contains file links. On failure, execute compensations in reverse, collect every rollback error, and raise one `ExecutionError` preserving the original cause. Reject `plan.can_apply is False` as a programmer error before mutation. Serialize receipt JSON deterministically, write a sibling temporary file, flush and `os.fsync` it, and use `os.replace`; journal restoration of prior receipt bytes or removal of a newly created receipt. Validate receipt schema, field types, root identity, and duplicate destinations without message-parsing control flow.

- [x] **Step 5: Run executor tests and observe GREEN**

```text
python -m pytest tests/test_executor.py tests/test_receipts.py -v
```

- [x] **Step 6: Run full quality gate and commit**

```text
python -m mypy
python -m ruff check src tests skills/update-model-routing/scripts
python -m ruff format --check src tests skills/update-model-routing/scripts
python -m pytest --tb=short -q
git add -- src/secret_agents_setup/models.py src/secret_agents_setup/executor.py src/secret_agents_setup/executor_errors.py src/secret_agents_setup/receipts.py src/secret_agents_setup/receipt_errors.py tests/test_executor.py tests/test_receipts.py
git diff --cached --check
git commit -m "feat: record transactional harness installs"
```

- [x] **Task 5 complete**

### Task 5A: Plan and execute safe uninstall

**Routing profile:** `high-risk`.

**Files:**
- Modify: `secret-agents/src/secret_agents_setup/models.py`
- Modify: `secret-agents/src/secret_agents_setup/planning.py`
- Modify: `secret-agents/src/secret_agents_setup/executor.py`
- Modify: `secret-agents/src/secret_agents_setup/receipts.py`
- Create: `secret-agents/tests/test_uninstall.py`

**Interfaces:**
- Consumes: selected harnesses, `InstallReceipt | None`, expected root identity, managed-home boundary, current filesystem state, and `LinkBackend`.
- Produces:
  - `UninstallFindingState(StrEnum)` values `NOT_INSTALLED`, `OWNED`, `MISSING_OWNED_LINK`, `SHARED_RETAINED`, `FOREIGN_CONTENT`, `BACKUP_MISSING`, `BACKUP_MODIFIED`, and `PARENT_PRESERVED`.
  - `UninstallActionKind(StrEnum)` values `REMOVE_LINK`, `RESTORE_BACKUP`, `REMOVE_EMPTY_PARENT`, `REPLACE_RECEIPT`, and `DELETE_RECEIPT`.
  - Frozen `UninstallFinding(state: UninstallFindingState, path: Path, blocking: bool)` and `UninstallAction(kind: UninstallActionKind, source: Path | None, destination: Path)`.
  - Frozen `UninstallPlan(findings: tuple[UninstallFinding, ...], actions: tuple[UninstallAction, ...], next_receipt: InstallReceipt | None)` with `can_apply` derived from blocking findings.
  - `UninstallPlan.next_receipt: InstallReceipt | None`, computed during read-only planning so selected-harness removal and shared Codex/Copilot ownership require no policy decisions in the executor.
  - `build_uninstall_plan(receipt: InstallReceipt | None, harnesses: tuple[Harness, ...], backend: LinkBackend, *, expected_identity: str, home: Path) -> UninstallPlan`.
  - `apply_uninstall_plan(plan: UninstallPlan, backend: LinkBackend, receipt_file: Path) -> ExecutionReport`.
  - Execution outcomes such as `removed` and `restored-backup` remain `ExecutionEvent` values and are never mixed into planning finding states.

- [x] **Step 1: Write failing uninstall preflight tests**

Cover no receipt as idempotent `not-installed`; selected-harness filtering; a shared Codex/Copilot projection retained for an unselected harness; correct whole-directory and per-skill projections; a replaced regular file; a link retargeted to another checkout; a missing formerly owned link as a nonblocking no-op; missing or modified recorded backup; a non-empty installer-created parent as preserved and nonblocking; foreign identity and every receipt path escaping `home`; deterministic action ordering; and all-or-nothing blocking with an empty action tuple.

- [x] **Step 2: Write failing uninstall execution and rollback tests**

Assert removal of only receipt-owned links, restoration of each backup to its original path, preservation of third-party sibling skills, removal of only empty receipt-created parents, receipt deletion last, and reverse restoration after injected failure at every action type. Assert a rollback failure reports every manually recoverable path.

- [x] **Step 3: Run uninstall tests and observe RED**

```text
python -m pytest tests/test_uninstall.py -v
```

Expected: imports fail because uninstall models/functions do not exist.

- [x] **Step 4: Implement pure uninstall planning**

Treat the validated receipt as the sole ownership authority. With no receipt, return a successful no-action `not-installed` plan. Recheck the expected identity and home boundary rather than trusting caller provenance. Compare recorded sources and destinations using `backend.resolved_target`, never content similarity. A missing formerly owned link is a safe no-op; missing/modified backups, foreign content, foreign identity, or an out-of-bound path block the entire selected uninstall. Retain unselected harness records in `next_receipt`; when a projection is shared by selected and unselected harnesses, retain the link and remove only the selected harnesses from its receipt record. Preserve non-empty created parents without blocking.

- [x] **Step 5: Implement journaled uninstall execution**

Remove links before restoring backups; remove projection parents only when empty. Partial uninstall replaces the receipt last; full uninstall deletes it last. Retain the receipt-storage directory in both cases. Journal the inverse of every mutation and roll back in reverse on failure. Never delete canonical targets, unrelated files, non-empty directories, or unselected receipt entries.

- [x] **Step 6: Run focused and full verification**

```text
python -m pytest tests/test_uninstall.py tests/test_executor.py tests/test_receipts.py -v
python -m mypy
python -m ruff check src tests skills/update-model-routing/scripts
python -m ruff format --check src tests skills/update-model-routing/scripts
python -m pytest --tb=short -q
```

- [x] **Step 7: Commit**

```text
git add -- src/secret_agents_setup/models.py src/secret_agents_setup/planning.py src/secret_agents_setup/executor.py src/secret_agents_setup/receipts.py tests/test_uninstall.py
git diff --cached --check
git commit -m "feat: uninstall owned harness projections"
```

- [x] **Task 5A complete**

### Task 6: Add the install/check/uninstall CLI and zero-install bootstrap

**Routing profile:** `balanced`.

**Files:**
- Modify if an integration seam requires it: `secret-agents/src/secret_agents_setup/models.py`
- Modify if an integration seam requires it: `secret-agents/src/secret_agents_setup/planning.py`
- Modify if an integration seam requires it: `secret-agents/src/secret_agents_setup/links.py`
- Modify if an integration seam requires it: `secret-agents/src/secret_agents_setup/executor.py`
- Modify if an integration seam requires it: `secret-agents/src/secret_agents_setup/receipts.py`
- Create: `secret-agents/src/secret_agents_setup/cli.py`
- Create: `secret-agents/src/secret_agents_setup/__main__.py`
- Create: `secret-agents/scripts/harness_setup.py`
- Create: `secret-agents/tests/test_cli.py`
- Create: `secret-agents/tests/test_integration.py`

**Interfaces:**
- Consumes: argv, environment mapping, home path, script path, clock, and platform name through explicit `main` parameters.
- Produces:
  - `ExitCode(IntEnum)` values `SUCCESS = 0`, `INVALID_INPUT = 2`, `BLOCKED = 3`, `EXECUTION_FAILED = 4`.
  - `main(argv: Sequence[str] | None = None, *, environment: Mapping[str, str] | None = None, home: Path | None = None, script_path: Path | None = None, os_name: str | None = None, now: Callable[[], datetime] | None = None, backend: LinkBackend | None = None) -> int`; an injected backend takes precedence over `backend_for(os_name)` so capability and rollback paths are deterministic in tests.
  - Stable line-oriented output containing root, harness, destination, state/action, and final result.

**Failure matrix:**

| Failure | Exit code | Stream/owner |
|---|---:|---|
| Argparse misuse, unresolved/invalid root, invalid skill catalog | `INVALID_INPUT` | concise diagnostic on stderr from CLI boundary |
| Missing/stale projections reported by `check`, plan collision, foreign/invalid receipt ownership, `SymlinkPrivilegeRequired`, or `SymlinkUnsupported` | `BLOCKED` | actionable remediation on stderr; plan rows may remain on stdout |
| Junction/symlink mutation failure, receipt replacement failure, failed final validation, or any rollback failure | `EXECUTION_FAILED` | failure plus structured recovery paths on stderr |
| Applying a blocked plan or violating another internal invariant | no translation | fail fast as a programmer error |

- [x] **Step 1: Write failing parser and dependency-injection tests**

Cover default `install --harness all`, `check`, `uninstall`, every harness selector, invalid selector, explicit root, environment root, `--dry-run`, `--backup-conflicts`, and injected home/platform/clock/backend values. Reject install-only flags on uninstall.

- [x] **Step 2: Write failing command-behavior tests**

Cover successful all-correct `check`; `check` returning `BLOCKED` for actionable missing or stale projections even when the install plan is applicable; Windows dry-run no mutation/probe plus an explicit `capability-unverified-until-install` message; successful install with receipt; capability refusal before managed mutation; blocked install no mutation; execution failure with rollback diagnostics; successful uninstall with backup restoration; blocked foreign-content uninstall; idempotent no-receipt uninstall; selected-harness receipt retention; stdout/stderr ownership from the failure matrix; and one plan row for the shared Codex/Copilot skill destination.

- [x] **Step 3: Run CLI tests and observe RED**

```text
python -m pytest tests/test_cli.py -v
```

Expected: import failure because `cli.py` does not exist.

- [x] **Step 4: Implement parser and orchestration**

Use `argparse` only in `cli.py`. Compose root resolution, catalog, harness profiles, planning, receipts, backend selection, and executor; do not duplicate their policy. Catch concrete semantic types by identity and apply the failure matrix once; `LinkOperationError` is too broad to map as one outcome, so capability types map to `BLOCKED` while mutation types map to `EXECUTION_FAILED`. Never inspect message text. `check` builds and reports an install plan without applying or probing it and returns nonzero whenever remediation is required. `--dry-run` follows install planning/reporting but skips capability probing and execution. `uninstall` loads the receipt with expected identity/home bounds, plans removal, and applies only an unblocked plan.

- [x] **Step 5: Implement both process boundaries**

`src/secret_agents_setup/__main__.py` calls `main()`. `scripts/harness_setup.py` inserts `<root>/src` into `sys.path`, imports `main`, and raises `SystemExit(main(script_path=Path(__file__)))`. Keep the bootstrap below 20 lines.

- [x] **Step 6: Run focused tests and read-only manual smoke tests**

```text
python -m pytest tests/test_cli.py -v
python scripts/harness_setup.py --help
python scripts/harness_setup.py check --harness all --agent-root .
```

Expected: tests pass; help lists all three commands and their valid flags; `check` reports current home state without mutation and may return `BLOCKED`. Never run install or uninstall against the developer's real home as a smoke test.

- [x] **Step 7: Write the end-to-end temporary-home integration test**

Call `cli.main` with injected `home`, environment, platform, clock, and backend. Assert dry-run creates nothing and does not probe; install creates expected projections plus receipt; check succeeds; a second install is idempotent; uninstall removes owned projections, restores a backed-up instruction file, preserves a third-party skill, removes the receipt, retains receipt-storage directories, and leaves canonical targets intact. Add a Windows-capability-failure case that proves zero managed-home and receipt changes. Separately exercise `backend_for(os.name)` against a temporary home: complete the lifecycle when the host supports the required links, or on Windows assert the controlled prerequisite refusal and zero mutation instead of silently skipping the platform contract.

- [x] **Step 8: Run integration coverage and close only promised seam gaps**

```text
python -m pytest tests/test_integration.py -v
```

PASS is valid because this integrates behavior already developed in Task 6. If RED, adjust only the explicit dependency injection, output boundary, or platform capability handling promised by this task; do not add CLI options or container packaging. Re-run `tests/test_cli.py` and `tests/test_integration.py` to GREEN.

- [x] **Step 9: Run full quality gate and commit**

```text
python -m mypy
python -m ruff check src tests scripts skills/update-model-routing/scripts
python -m ruff format --check src tests scripts skills/update-model-routing/scripts
python -m pytest --tb=short -q
git add -- src/secret_agents_setup/models.py src/secret_agents_setup/planning.py src/secret_agents_setup/links.py src/secret_agents_setup/executor.py src/secret_agents_setup/receipts.py src/secret_agents_setup/cli.py src/secret_agents_setup/__main__.py scripts/harness_setup.py tests/test_cli.py tests/test_integration.py
git diff --cached --check
git commit -m "feat: expose harness setup CLI"
```

- [x] **Task 6 complete**

---

## Batch 4: User Documentation and Cross-Platform Enforcement

**Routing profile:** `balanced`. The documentation edit is mechanical, but the same agent should retain CLI and receipt context through the three-OS integration gate.

- [ ] **Batch 4 complete**

### Copy/paste handoff

```text
Implement Batch 4 of the cross-platform harness setup plan.

Model routing: use the `balanced` profile from model-routing.json. Verify harness availability before dispatch and record any allowed substitution.

Repository root: C:\git\handbag-of-holding
Working directory: C:\git\handbag-of-holding\secret-agents

Read only this context before starting:
1. C:\git\handbag-of-holding\secret-agents\AGENTS.md
2. C:\git\handbag-of-holding\secret-agents\HUMANS.md
3. C:\git\handbag-of-holding\secret-agents\docs\superpowers\specs\2026-08-28-harness-setup-design.md
4. C:\git\handbag-of-holding\secret-agents\docs\superpowers\plans\2026-08-28-cross-platform-harness-setup.md — read Global Constraints, Verified External Contracts, File and Responsibility Map, Batch 4, Task 7, and Task 8 only.
5. C:\git\handbag-of-holding\secret-agents\src\secret_agents_setup\cli.py
6. C:\git\handbag-of-holding\secret-agents\scripts\harness_setup.py
7. C:\git\handbag-of-holding\secret-agents\runbooks\harness-setup\harness-setup.md
8. C:\git\handbag-of-holding\secret-agents\model-routing.json
9. C:\git\handbag-of-holding\secret-agents\skills\update-skills-readme\SKILL.md
10. C:\git\handbag-of-holding\secret-agents\skills\agent-plan\SKILL.md and agents\openai.yaml
11. C:\git\handbag-of-holding\secret-agents\skills\agent-preflight\SKILL.md
12. C:\git\handbag-of-holding\secret-agents\skills\ready-player-one\SKILL.md
13. C:\git\handbag-of-holding\secret-agents\skills\unreal-reset-build-env\SKILL.md
14. C:\git\handbag-of-holding\secret-agents\skills\unreal-ugs-release\SKILL.md
15. C:\git\handbag-of-holding\secret-agents\runbooks\ugs-pcb\UGS_PCB_Runbook.md
16. C:\git\handbag-of-holding\secret-agents\skills\python-tdd-cycle\SKILL.md
17. C:\git\handbag-of-holding\secret-agents\skills\python-quality-gate\SKILL.md

Starting point: Task 7, Step 1, from a clean tree after Batch 3.

Execution rules:
- Document only commands and behavior implemented by Tasks 1-6.
- Keep README and runbook concise; detailed path manipulation remains in Python.
- Update every completed checkbox on disk; the plan is git-ignored, so do NOT commit it.
- Run the complete quality gate before both commits.

Stopping point: stop after Task 8 passes locally, the CI workflow is committed, all locally verifiable Task 7/8 checkboxes are checked, and git status contains no task-created changes. Check Task 8 and Batch 4 complete only after all three remote matrix jobs pass; if remote evidence is unavailable, leave Task 8 Step 4 plus those completion boxes unchecked and report the exact follow-up. Report commits and local gate results. Do not claim cross-platform completion without remote evidence.
```

### Task 7: Replace stale setup prose and add the root README

**Routing profile:** `routine`.

**Files:**
- Create: `secret-agents/README.md`
- Modify: `secret-agents/HUMANS.md`
- Modify: `secret-agents/runbooks/harness-setup/harness-setup.md`
- Modify: `secret-agents/AGENTS.md`
- Modify: `secret-agents/skills/agent-plan/SKILL.md`
- Modify: `secret-agents/skills/agent-plan/agents/openai.yaml`
- Modify: `secret-agents/skills/agent-preflight/SKILL.md`
- Modify: `secret-agents/skills/unreal-reset-build-env/SKILL.md`
- Modify: `secret-agents/skills/unreal-ugs-release/SKILL.md`
- Modify: `secret-agents/runbooks/ugs-pcb/UGS_PCB_Runbook.md`
- Modify: `secret-agents/skills/README.md`
- Modify: `secret-agents/skills/README.html`
- Create: `secret-agents/tests/test_portable_skill_references.py`

**Interfaces:**
- Consumes: the implemented CLI `--help`, design, discovery matrix, and canonical skill inventory.
- Produces: one root quick start, one repair/uninstall runbook, compact always-on routing, corrected portable references in renamed skills, the canonical `Agent Plan` heading/display name, a corrected `agent-preflight` recovery contract consumed by the `ready-player-one` alias, and a refreshed skill inventory that reflects the Batch 2 canonical names, including `agent-plan`, `agent-preflight`, `clean-code-architecture-guards`, `clean-code-error-handling`, `report-receipt`, `report-status`, `unreal-reset-build-env`, `unreal-ugs-release`, and `update-model-routing`.

- [ ] **Step 1: Draft the root README from verified CLI behavior**

Create sections in this order: purpose; prerequisites; checkout-independent quick start; install commands; `check` and dry-run; uninstall and receipt behavior; installed projection table with 2026-08-28 first-party source links; adding/updating a skill; model-routing freshness; project-local versus personal skills; container future; troubleshooting; repository layout. State that Windows instruction installation requires Developer Mode or elevation, that no hardlink/copy fallback exists, and why. Include Windows, Linux, and macOS invocation examples without duplicating platform-specific link commands.

- [ ] **Step 2: Rewrite the harness runbook as the repair surface**

Remove hard-coded `C:\git\worky\Agent` and `D:\git\worky\Agent`, the obsolete Claude `~/.claude/AGENTS.md` path, and the unresolved Copilot placeholder. Keep root resolution, install/check/uninstall examples, verified discovery matrix and source dates, receipt ownership, conflict backup restoration, Windows capability remediation, native diagnostics, and restart guidance. State the v1 assumption that all harnesses consume the same guidance and route future divergence through harness profiles.

- [ ] **Step 3: Write a failing guard for renamed and portable skill references**

Create `tests/test_portable_skill_references.py` as a textual contract guard that fails loudly if it scans no canonical skills. Require `agent-preflight` to route model recommendations through the `economy` profile in `model-routing.json`; name `~/.agents/skills/agent-preflight` for Codex and Copilot personal discovery; name `~/.claude/skills/agent-preflight` for Claude; and preserve the `ready-player-one` alias contract. Reject `~/.claude/AGENTS.md`, `.claude/AGENTS.md`, `~/.codex/skills`, `o4-mini`, `claude-haiku-4-5`, Copilot skill-registration placeholders, and `C:\git\worky\Agent`/`D:\git\worky\Agent` from active skill bodies. Require `agent-plan/SKILL.md` and its UI metadata to use `Agent Plan`, not `Smart Plan`, and reject the deprecated `work-receipt` skill name from `HUMANS.md`. Run `python -m pytest tests/test_portable_skill_references.py -v` and observe RED against the current stale content.

- [ ] **Step 4: Correct `agent-preflight` and observe GREEN**

Update `agent-preflight` harness discovery, invocation/remediation, and model-routing sections. Use the verified projection paths from this plan and the `economy` profile from `model-routing.json`; keep exact model IDs out of the skill. Copilot Check 1 must use `~/.agents/skills`; Check 2 may explicitly skip when no first-party trust/approval contract exists, but must not imply that skill registration is unknown. Keep `ready-player-one` as a thin unchanged alias. Replace the old absolute canonical-root examples in `unreal-reset-build-env` and `unreal-ugs-release` with `<agent-root>`/skill-relative resolution; update the companion UGS runbook in the same change with its canonical `<agent-root>` companion-skill reference. Finish the rename in `agent-plan` by changing the heading and UI display name from `Smart Plan` to `Agent Plan` without changing its invocation name. Replace the historical `work-receipt` skill name in `HUMANS.md` with `report-receipt`. Run `python -m pytest tests/test_portable_skill_references.py -v` and require PASS.

- [ ] **Step 5: Tighten always-on guidance and bump its revision**

Batch 2 already established marker-based `<agent-root>` resolution and removed machine-specific roots. Preserve that wording; add only the missing-discovery repair route to the runbook/CLI if absent, keep setup commands out of always-on context, and bump the revision only when `AGENTS.md` actually changes.

- [ ] **Step 6: Refresh the skill inventory**

Follow `update-skills-readme` so `skills/README.md` and `skills/README.html` replace the remaining Worky paths, obsolete discovery claims, and pre-Batch-2 names while preserving existing Architect's review blocks. Before rendering, require `Test-Path` to return true for `agent-plan`, `agent-preflight`, `clean-code-architecture-guards`, `clean-code-error-handling`, `report-receipt`, `report-status`, `unreal-reset-build-env`, `unreal-ugs-release`, and `update-model-routing`; require it to return false for the removed `smart-plan`, `architecture-guards`, `work-receipt-create`, `status-report-create`, `reset-unreal-build-environment`, and `ugs-pcb-release` directories. Do not create a README inside any individual skill and never hand-edit `README.html`.

- [ ] **Step 7: Verify documentation against the executable surface**

Run:

```text
python scripts/harness_setup.py --help
rg -n "C:\\git\\worky\\Agent|D:\\git\\worky\\Agent|Copilot.*T[B]D|\.claude\\AGENTS\.md|skills[\\/]smart-plan|skills[\\/]architecture-guards|skills[\\/]work-receipt-create|skills[\\/]status-report-create|skills[\\/]reset-unreal-build-environment|skills[\\/]ugs-pcb-release|Smart Plan|\bwork-receipt\b" README.md AGENTS.md HUMANS.md runbooks skills --glob '!*README.html'
python skills/update-model-routing/scripts/check_staleness.py --reference model-routing.json
git diff --check
```

Expected: help matches documented install/check/uninstall flags; the stale-path search returns no matches; model routing reports `CURRENT`; diff check passes.

- [ ] **Step 8: Run the full quality gate and commit**

```text
python -m mypy
python -m ruff check src tests scripts skills/update-model-routing/scripts
python -m ruff format --check src tests scripts skills/update-model-routing/scripts
python -m pytest --tb=short -q
git add -- README.md AGENTS.md HUMANS.md runbooks/harness-setup/harness-setup.md runbooks/ugs-pcb/UGS_PCB_Runbook.md skills/agent-plan/SKILL.md skills/agent-plan/agents/openai.yaml skills/agent-preflight/SKILL.md skills/unreal-reset-build-env/SKILL.md skills/unreal-ugs-release/SKILL.md skills/README.md skills/README.html tests/test_portable_skill_references.py
git diff --cached --check
git commit -m "docs: align harness setup and preflight"
```

- [ ] **Task 7 complete**

### Task 8: Enforce the verified suite on three operating systems

**Routing profile:** `balanced`.

**Files:**
- Create: `.github/workflows/secret-agents.yml`

**Interfaces:**
- Consumes: the final public CLI and `tests/test_integration.py` committed by Task 6, plus the documentation and portable-reference guard committed by Task 7.
- Produces: model-routing freshness reporting and CI enforcement of the complete suite on `windows-latest`, `ubuntu-latest`, and `macos-latest` at the declared Python 3.11 runtime floor while retaining the intentional mypy Python 3.12 analysis target.

- [ ] **Step 1: Add the GitHub Actions matrix**

Create a workflow triggered on pull requests and pushes affecting the deliberately fixed `secret-agents/**` path or the workflow, plus a weekly scheduled run (`cron: "17 16 * * 1"`) so an untouched reference still reports staleness. Matrix: `ubuntu-latest`, `windows-latest`, `macos-latest`; Python `3.11`. Set `defaults.run.working-directory: secret-agents` once; `uses:` steps remain at repository scope because GitHub Actions does not apply `working-directory` to them. Then run `python -m pip install -e ".[dev]"`, the deterministic model-routing staleness checker, mypy, Ruff check, Ruff format check, pytest, and compileall from the default directory. The literal path filter cannot consume a shared variable; the design records this required GitHub Actions coupling.

- [ ] **Step 2: Run the complete local verification**

```text
python -m mypy
python skills/update-model-routing/scripts/check_staleness.py --reference model-routing.json
python -m ruff check src tests scripts skills/update-model-routing/scripts
python -m ruff format --check src tests scripts skills/update-model-routing/scripts
python -m pytest --tb=short -q
python -m compileall -q src tests scripts skills/update-model-routing/scripts
git diff --check
```

Expected: every command exits zero.

- [ ] **Step 3: Inspect scope and commit**

```text
cd C:\git\handbag-of-holding
git status --short
git add -- .github/workflows/secret-agents.yml
git diff --cached --check
git diff --cached --stat
git commit -m "ci: verify harness setup across platforms"
```

- [ ] **Step 4: Record remote CI evidence when available**

Confirm the three matrix jobs pass. If no remote is configured, leave this checkbox unchecked and report that exact external follow-up rather than claiming cross-platform completion.

- [ ] **Task 8 complete**

---

## Completion Checklist

- [ ] Every task and batch checkbox is checked.
- [ ] `secret-agents/README.md` exists and its commands match `--help`.
- [ ] All canonical guidance, skills, and runbooks intended for distribution are tracked.
- [ ] `model-routing.json` is current (age at most 31 days), and CI runs the stale checker.
- [ ] Install/uninstall integration restores recorded backups and preserves third-party content.
- [ ] No machine-specific canonical checkout path remains in active guidance or runbooks.
- [ ] Local mypy, Ruff check, Ruff format check, pytest, compileall, and `git diff --check` pass.
- [ ] Windows, Linux, and macOS CI jobs pass, or the missing external evidence is stated explicitly.
- [ ] `git status --short` contains no implementation-created changes.
