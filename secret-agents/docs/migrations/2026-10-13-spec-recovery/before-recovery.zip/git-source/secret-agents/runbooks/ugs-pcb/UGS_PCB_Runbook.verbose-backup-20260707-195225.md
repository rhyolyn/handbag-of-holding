# UGS PCB Runbook

This runbook builds, validates, and submits UnrealGameSync precompiled editor binaries (PCB). It is written for humans to copy/paste step by step, and for agents to keep synchronized with the `ugs-pcb-release` skill.

This does **not** build the UnrealGameSync desktop application. This does **not** build a game package. Do not add `-game` or `-set:GameTargets=...` unless you intentionally need standalone game targets.

## Sync Rule

Canonical runbook path:

```text
D:\git\worky\Agent\runbooks\ugs-pcb\UGS_PCB_Runbook.md
```

This runbook and `D:\git\worky\Agent\skills\ugs-pcb-release\SKILL.md` must stay in sync.

When changing any command, default, validation check, troubleshooting step, or Perforce behavior:

1. Update this runbook.
2. Update the skill.
3. Verify both still describe the same process.

## How To Run This

Use this section if you want minimal decisions and copy/paste-safe execution. The bootstrap block auto-detects the workspace, repo root, project, editor target, UGS archive path, expected publishing stream, archive stream, and Perforce client.

### What You Must Set Manually

- Normally nothing.
- Optional only: set `$P4ClientOverride` inside the Bootstrap block if auto-detection cannot resolve the intended client.

Everything else in the Bootstrap block is safe to paste as-is from any directory inside the correct workspace.

### Copy/Paste Flow

1. Open plain PowerShell in the correct workspace or any subdirectory inside it.

```powershell
Get-Location
```

2. Paste and run this bootstrap block in the same PowerShell session. It uses your current directory and Perforce metadata; it does not know or care where this runbook file lives.

```powershell
$StartDir = (Resolve-Path ".").Path
$P4ClientOverride = ""

function Find-RepoRoot {
  param([string]$Path)

  $Current = (Resolve-Path $Path).Path
  while ($true) {
    if (Test-Path (Join-Path $Current "Engine\Build\BatchFiles\GetDotnetPath.bat")) {
      return $Current
    }

    $ChildRoot = Join-Path $Current "root"
    if (Test-Path (Join-Path $ChildRoot "Engine\Build\BatchFiles\GetDotnetPath.bat")) {
      return $ChildRoot
    }

    $Parent = Split-Path $Current -Parent
    if ([string]::IsNullOrWhiteSpace($Parent) -or $Parent -eq $Current) {
      throw "Could not resolve Unreal repo root from '$Path'. Start anywhere inside the mapped workspace."
    }
    $Current = $Parent
  }
}

function Get-FirstTaggedValue {
  param(
    [string[]]$Lines,
    [string]$TagName
  )

  $Line = $Lines | Where-Object { $_ -like "... $TagName *" } | Select-Object -First 1
  if ($Line) {
    return ($Line -replace "^\.\.\. $TagName ", "").Trim()
  }
  return ""
}

function Get-FirstClientSpecValue {
  param(
    [string[]]$Lines,
    [string]$FieldName
  )

  $Line = $Lines | Select-String "^$([regex]::Escape($FieldName)):\s+(.+)$" | Select-Object -First 1
  if ($Line) {
    return $Line.Matches[0].Groups[1].Value.Trim()
  }
  return ""
}

$Root = Find-RepoRoot $StartDir
$Workspace = Split-Path $Root -Parent

$Projects = @(Get-ChildItem (Join-Path $Root "Content") -Recurse -File -Filter "*.uproject" -ErrorAction SilentlyContinue)
if ($Projects.Count -eq 0) {
  throw "Could not find a .uproject under '$Root\Content'."
}
if ($Projects.Count -gt 1) {
  $PreferredProject = $Projects | Where-Object { $_.Name -eq "VisTest.uproject" } | Select-Object -First 1
  if (-not $PreferredProject) {
    throw "Found multiple .uproject files. Move to the intended project workspace or add a project selection rule. Found: $($Projects.FullName -join ', ')"
  }
  $Project = $PreferredProject.FullName
}
else {
  $Project = $Projects[0].FullName
}

$ProjectDir = Split-Path $Project -Parent
$ProjectName = [IO.Path]::GetFileNameWithoutExtension($Project)
$EditorTarget = "${ProjectName}Editor"
$UgsConfig = Join-Path $ProjectDir "Build\UnrealGameSync.ini"

if (-not (Test-Path -LiteralPath $UgsConfig)) {
  throw "Could not find UGS config at '$UgsConfig'."
}

$UgsConfigText = Get-Content -Raw -LiteralPath $UgsConfig
$ProjectDepotPath = ([regex]::Match($UgsConfigText, "(?m)^\[(//[^\]]+\.uproject)\]")).Groups[1].Value
$ExpectedArchivePath = ([regex]::Match($UgsConfigText, "(?m)^ZippedBinariesPath=(\S+)")).Groups[1].Value

if ([string]::IsNullOrWhiteSpace($ProjectDepotPath)) {
  throw "Could not parse project depot section from '$UgsConfig'."
}
if ([string]::IsNullOrWhiteSpace($ExpectedArchivePath)) {
  throw "Could not parse ZippedBinariesPath from '$UgsConfig'."
}

$ProjectDepotRootMarker = "/root/"
$ProjectDepotRootIndex = $ProjectDepotPath.IndexOf($ProjectDepotRootMarker)
if ($ProjectDepotRootIndex -lt 0) {
  throw "Project depot path '$ProjectDepotPath' does not contain '$ProjectDepotRootMarker'; cannot derive publishing stream."
}
$ExpectedClientStream = $ProjectDepotPath.Substring(0, $ProjectDepotRootIndex)
$ArchiveStream = $ExpectedArchivePath.Substring(0, $ExpectedArchivePath.LastIndexOf("/"))
$ExpectedZipName = Split-Path $ExpectedArchivePath -Leaf

Set-Location $Root

$RequestedP4Client = if ($null -eq $P4ClientOverride) { "" } else { "$P4ClientOverride" }
Remove-Item Env:\P4CLIENT -ErrorAction SilentlyContinue
if (-not [string]::IsNullOrWhiteSpace($RequestedP4Client)) {
  $env:P4CLIENT = $RequestedP4Client
}

if ([string]::IsNullOrWhiteSpace($RequestedP4Client)) {
  $CurrentPath = $Root.ToLowerInvariant()
  $ClientCandidates = @()
  $P4InfoWithoutClient = p4 -ztag info 2>$null
  $P4User = Get-FirstTaggedValue $P4InfoWithoutClient "userName"
  if ([string]::IsNullOrWhiteSpace($P4User)) {
    $P4User = $env:P4USER
  }
  if ([string]::IsNullOrWhiteSpace($P4User)) {
    $P4User = $env:USERNAME
  }

  foreach ($Line in (p4 clients -u $P4User 2>$null)) {
    if ($Line -match "^Client\s+(\S+)\s+\d{4}/\d{2}/\d{2}\s+root\s+(.+?)\s+'") {
      $ClientName = $Matches[1]
      $ClientRoot = $Matches[2].Trim()
      $ClientRootLower = $ClientRoot.ToLowerInvariant()

      $NormalizedClientRoot = $ClientRootLower.TrimEnd("\", "/")
      $CurrentIsUnderClientRoot = ($CurrentPath -eq $NormalizedClientRoot) -or $CurrentPath.StartsWith("$NormalizedClientRoot\")

      if ($CurrentIsUnderClientRoot) {
        $ClientSpec = p4 client -o $ClientName 2>$null
        $ClientStream = Get-FirstClientSpecValue $ClientSpec "Stream"

        $ClientCandidates += [pscustomobject]@{
          Name = $ClientName
          Root = $ClientRoot
          RootLength = $ClientRootLower.Length
          Stream = $ClientStream
        }
      }
    }
  }

  $BestClient = $ClientCandidates |
    Where-Object { $_.Stream -eq $ExpectedClientStream } |
    Sort-Object RootLength -Descending |
    Select-Object -First 1

  if (-not $BestClient) {
    $Nearby = $ClientCandidates |
      Sort-Object RootLength -Descending |
      Select-Object Name, Root, Stream

    throw "Could not resolve a client on '$ExpectedClientStream' for path '$Root'. Candidates for this path: $($Nearby | Out-String)"
  }

  $env:P4CLIENT = $BestClient.Name
}

$P4InfoLines = p4 -ztag info 2>$null
$DetectedClient = Get-FirstTaggedValue $P4InfoLines "clientName"
$DetectedStream = Get-FirstTaggedValue $P4InfoLines "clientStream"

if ([string]::IsNullOrWhiteSpace($DetectedClient)) {
  throw "Could not detect Perforce client from '$Root'. Run from a mapped workspace path or set `$P4ClientOverride explicitly."
}

if ([string]::IsNullOrWhiteSpace($DetectedStream)) {
  $ClientSpec = p4 client -o $DetectedClient 2>$null
  $DetectedStream = Get-FirstClientSpecValue $ClientSpec "Stream"
}

if ($DetectedStream -ne $ExpectedClientStream) {
  throw "Perforce client '$DetectedClient' is on stream '$DetectedStream' but expected '$ExpectedClientStream'."
}

$env:P4CLIENT = $DetectedClient

[pscustomobject]@{
  SelectedP4Client = $DetectedClient
  SelectedClientStream = $DetectedStream
  SelectedClientRoot = ((p4 info | Select-String "Client root:").ToString() -replace "^.*Client root:\s*", "")
  CurrentDirectory = (Get-Location).Path
  Root = $Root
  Project = $Project
  EditorTarget = $EditorTarget
  UgsConfig = $UgsConfig
  ProjectDepotPath = $ProjectDepotPath
  ExpectedArchivePath = $ExpectedArchivePath
  ArchiveStream = $ArchiveStream
  ExpectedZipName = $ExpectedZipName
} | Format-List
```

3. Validate repo and project paths.

```powershell
if ([string]::IsNullOrWhiteSpace($Project)) {
  throw "`$Project is not set. Rerun step 2 (the full Bootstrap And Autodetect block), then run this step again."
}

[pscustomobject]@{
  DotNetPathExists = (Test-Path ".\Engine\Build\BatchFiles\GetDotnetPath.bat")
  ProjectExists = (Test-Path -LiteralPath $Project)
} | Format-List
```

4. Validate Perforce context.

```powershell
p4 info | Select-String "Client name|Client root|Client stream|Current directory"
```

5. Continue only when all checks pass.

```powershell
$ClientStreamLine = p4 -ztag info 2>$null | Where-Object { $_ -like "... clientStream *" } | Select-Object -First 1
$ClientStream = if ($ClientStreamLine) { ($ClientStreamLine -replace "^\.\.\. clientStream ", "").Trim() } else { "" }

@{
  DotNetPathExists = (Test-Path ".\Engine\Build\BatchFiles\GetDotnetPath.bat")
  ProjectExists = (Test-Path -LiteralPath $Project)
  ClientStreamOk = ($ClientStream -eq $ExpectedClientStream)
}
```

6. Continue with section 1 (`Clean The Shell Environment`) and run each section block-by-block.

### Resolve Perforce Client From Location

If the bootstrap cannot find a matching client, run this diagnostic block and create/open a workspace on the reported `ExpectedClientStream`.

```powershell
Get-Location
p4 info | Select-String "User name|Client name|Client root|Client stream|Current directory"
p4 clients -u $P4User | Select-String ([regex]::Escape($ExpectedClientStream))
```

Do not proceed with `-p4` BuildGraph commands unless `p4 info` shows the expected client stream.

## Bootstrap And Autodetect

This block is the source of truth for the rest of the runbook. It derives the BuildGraph publish target from `Content\<Project>\Build\UnrealGameSync.ini`, because that is what UGS consumers actually sync.

For VisTest, the expected result is:

- Publishing stream: `//vistest-vp/main`
- UGS consumer stream: `//vistest-vp/main-content`
- UGS archive path: `//ue-laika/editor-binaries/++vistest-vp+main-VisTestEditor.zip`

If BuildGraph is run from a `main-content` client, it submits `++vistest-vp+main-content-VisTestEditor.zip`, which UGS does not consume for VisTest.

```powershell
$StartDir = (Resolve-Path ".").Path
$P4ClientOverride = ""

function Find-RepoRoot {
  param([string]$Path)

  $Current = (Resolve-Path $Path).Path
  while ($true) {
    if (Test-Path (Join-Path $Current "Engine\Build\BatchFiles\GetDotnetPath.bat")) {
      return $Current
    }

    $ChildRoot = Join-Path $Current "root"
    if (Test-Path (Join-Path $ChildRoot "Engine\Build\BatchFiles\GetDotnetPath.bat")) {
      return $ChildRoot
    }

    $Parent = Split-Path $Current -Parent
    if ([string]::IsNullOrWhiteSpace($Parent) -or $Parent -eq $Current) {
      throw "Could not resolve Unreal repo root from '$Path'. Start anywhere inside the mapped workspace."
    }
    $Current = $Parent
  }
}

function Get-FirstTaggedValue {
  param(
    [string[]]$Lines,
    [string]$TagName
  )

  $Line = $Lines | Where-Object { $_ -like "... $TagName *" } | Select-Object -First 1
  if ($Line) {
    return ($Line -replace "^\.\.\. $TagName ", "").Trim()
  }
  return ""
}

function Get-FirstClientSpecValue {
  param(
    [string[]]$Lines,
    [string]$FieldName
  )

  $Line = $Lines | Select-String "^$([regex]::Escape($FieldName)):\s+(.+)$" | Select-Object -First 1
  if ($Line) {
    return $Line.Matches[0].Groups[1].Value.Trim()
  }
  return ""
}

$Root = Find-RepoRoot $StartDir
$Workspace = Split-Path $Root -Parent

$Projects = @(Get-ChildItem (Join-Path $Root "Content") -Recurse -File -Filter "*.uproject" -ErrorAction SilentlyContinue)
if ($Projects.Count -eq 0) {
  throw "Could not find a .uproject under '$Root\Content'."
}
if ($Projects.Count -gt 1) {
  $PreferredProject = $Projects | Where-Object { $_.Name -eq "VisTest.uproject" } | Select-Object -First 1
  if (-not $PreferredProject) {
    throw "Found multiple .uproject files. Move to the intended project workspace or add a project selection rule. Found: $($Projects.FullName -join ', ')"
  }
  $Project = $PreferredProject.FullName
}
else {
  $Project = $Projects[0].FullName
}

$ProjectDir = Split-Path $Project -Parent
$ProjectName = [IO.Path]::GetFileNameWithoutExtension($Project)
$EditorTarget = "${ProjectName}Editor"
$UgsConfig = Join-Path $ProjectDir "Build\UnrealGameSync.ini"

if (-not (Test-Path -LiteralPath $UgsConfig)) {
  throw "Could not find UGS config at '$UgsConfig'."
}

$UgsConfigText = Get-Content -Raw -LiteralPath $UgsConfig
$ProjectDepotPath = ([regex]::Match($UgsConfigText, "(?m)^\[(//[^\]]+\.uproject)\]")).Groups[1].Value
$ExpectedArchivePath = ([regex]::Match($UgsConfigText, "(?m)^ZippedBinariesPath=(\S+)")).Groups[1].Value

if ([string]::IsNullOrWhiteSpace($ProjectDepotPath)) {
  throw "Could not parse project depot section from '$UgsConfig'."
}
if ([string]::IsNullOrWhiteSpace($ExpectedArchivePath)) {
  throw "Could not parse ZippedBinariesPath from '$UgsConfig'."
}

$ProjectDepotRootMarker = "/root/"
$ProjectDepotRootIndex = $ProjectDepotPath.IndexOf($ProjectDepotRootMarker)
if ($ProjectDepotRootIndex -lt 0) {
  throw "Project depot path '$ProjectDepotPath' does not contain '$ProjectDepotRootMarker'; cannot derive publishing stream."
}
$ExpectedClientStream = $ProjectDepotPath.Substring(0, $ProjectDepotRootIndex)
$ArchiveStream = $ExpectedArchivePath.Substring(0, $ExpectedArchivePath.LastIndexOf("/"))
$ExpectedZipName = Split-Path $ExpectedArchivePath -Leaf

Set-Location $Root

$RequestedP4Client = if ($null -eq $P4ClientOverride) { "" } else { "$P4ClientOverride" }
Remove-Item Env:\P4CLIENT -ErrorAction SilentlyContinue
if (-not [string]::IsNullOrWhiteSpace($RequestedP4Client)) {
  $env:P4CLIENT = $RequestedP4Client
}

if ([string]::IsNullOrWhiteSpace($RequestedP4Client)) {
  $CurrentPath = $Root.ToLowerInvariant()
  $ClientCandidates = @()
  $P4InfoWithoutClient = p4 -ztag info 2>$null
  $P4User = Get-FirstTaggedValue $P4InfoWithoutClient "userName"
  if ([string]::IsNullOrWhiteSpace($P4User)) {
    $P4User = $env:P4USER
  }
  if ([string]::IsNullOrWhiteSpace($P4User)) {
    $P4User = $env:USERNAME
  }

  foreach ($Line in (p4 clients -u $P4User 2>$null)) {
    if ($Line -match "^Client\s+(\S+)\s+\d{4}/\d{2}/\d{2}\s+root\s+(.+?)\s+'") {
      $ClientName = $Matches[1]
      $ClientRoot = $Matches[2].Trim()
      $ClientRootLower = $ClientRoot.ToLowerInvariant()

      $NormalizedClientRoot = $ClientRootLower.TrimEnd("\", "/")
      $CurrentIsUnderClientRoot = ($CurrentPath -eq $NormalizedClientRoot) -or $CurrentPath.StartsWith("$NormalizedClientRoot\")

      if ($CurrentIsUnderClientRoot) {
        $ClientSpec = p4 client -o $ClientName 2>$null
        $ClientStream = Get-FirstClientSpecValue $ClientSpec "Stream"

        $ClientCandidates += [pscustomobject]@{
          Name = $ClientName
          Root = $ClientRoot
          RootLength = $ClientRootLower.Length
          Stream = $ClientStream
        }
      }
    }
  }

  $BestClient = $ClientCandidates |
    Where-Object { $_.Stream -eq $ExpectedClientStream } |
    Sort-Object RootLength -Descending |
    Select-Object -First 1

  if (-not $BestClient) {
    $Nearby = $ClientCandidates |
      Sort-Object RootLength -Descending |
      Select-Object Name, Root, Stream

    throw "Could not resolve a client on '$ExpectedClientStream' for path '$Root'. Candidates for this path: $($Nearby | Out-String)"
  }

  $env:P4CLIENT = $BestClient.Name
}

$P4InfoLines = p4 -ztag info 2>$null
$DetectedClient = Get-FirstTaggedValue $P4InfoLines "clientName"
$DetectedStream = Get-FirstTaggedValue $P4InfoLines "clientStream"

if ([string]::IsNullOrWhiteSpace($DetectedClient)) {
  throw "Could not detect Perforce client from '$Root'. Run from a mapped workspace path or set `$P4ClientOverride explicitly."
}

if ([string]::IsNullOrWhiteSpace($DetectedStream)) {
  $ClientSpec = p4 client -o $DetectedClient 2>$null
  $DetectedStream = Get-FirstClientSpecValue $ClientSpec "Stream"
}

if ($DetectedStream -ne $ExpectedClientStream) {
  throw "Perforce client '$DetectedClient' is on stream '$DetectedStream' but expected '$ExpectedClientStream'."
}

$env:P4CLIENT = $DetectedClient

[pscustomobject]@{
  SelectedP4Client = $DetectedClient
  SelectedClientStream = $DetectedStream
  SelectedClientRoot = ((p4 info | Select-String "Client root:").ToString() -replace "^.*Client root:\s*", "")
  CurrentDirectory = (Get-Location).Path
  Root = $Root
  Project = $Project
  EditorTarget = $EditorTarget
  UgsConfig = $UgsConfig
  ProjectDepotPath = $ProjectDepotPath
  ExpectedArchivePath = $ExpectedArchivePath
  ArchiveStream = $ArchiveStream
  ExpectedZipName = $ExpectedZipName
} | Format-List
```

If `p4 info` shows an illegal placeholder client name, clear it immediately:

```powershell
Remove-Item Env:\P4CLIENT -ErrorAction SilentlyContinue
```

Then rerun the full Bootstrap block from the correct workspace location:

```powershell
p4 info | Select-String "Client name|Client root|Client stream|Current directory"
```

Quick path checks:

```powershell
Test-Path ".\Engine\Build\BatchFiles\GetDotnetPath.bat"
Test-Path $Project
```

Expected: both print `True`.

Verify Perforce context before any `-p4` command:

```powershell
p4 info | Select-String "Client name|Client root|Client stream|Current directory"
```

Expected for VisTest:

- `Client name`: a real Perforce client mapped to `//vistest-vp/main`
- `Client root`: your VisTest main workspace root
- `Client stream: //vistest-vp/main`

Stop if Perforce reports another client, root, or stream.

Verify the UGS consumer archive path before building:

```powershell
$UgsConfig = Join-Path $ProjectDir "Build\UnrealGameSync.ini"
$UgsConfigText = Get-Content -Raw $UgsConfig
$ConfiguredArchivePath = [regex]::Match($UgsConfigText, "ZippedBinariesPath=(\S+)").Groups[1].Value

[pscustomobject]@{
  UgsConfig = $UgsConfig
  ConfiguredArchivePath = $ConfiguredArchivePath
  ExpectedArchivePath = $ExpectedArchivePath
  MatchesExpected = $ConfiguredArchivePath -eq $ExpectedArchivePath
}
```

Expected for VisTest: `MatchesExpected` is `True`.

Stop if `ZippedBinariesPath` points somewhere else. The archive path in `UnrealGameSync.ini` is the path UGS consumers sync; BuildGraph must submit the PCB there.

## 1. Clean The Shell Environment

Use a plain PowerShell or `cmd.exe`, not a Visual Studio Developer Prompt.

Clear DotNet/MSBuild/Visual Studio variables that can pollute UBT/UAT:

```powershell
$EnvVarsToClear = @(
  "VisualStudioDir",
  "VSSKUEDITION",
  "PkgDefApplicationConfigFile",
  "VSAPPIDDIR",
  "VisualStudioEdition",
  "VisualStudioVersion",
  "COREHOST_TRACE",
  "COREHOST_TRACEFILE",
  "DOTNET_HOST_TRACE",
  "DOTNET_HOST_TRACEFILE",
  "DOTNET_ROOT",
  "DOTNET_ROOT(x86)",
  "DOTNET_MSBUILD_SDK_RESOLVER_SDKS_DIR",
  "DOTNET_MSBUILD_SDK_RESOLVER_SDKS_VER",
  "DOTNET_MSBUILD_SDK_RESOLVER_CLI_DIR",
  "MSBuildSDKsPath",
  "MSBuildExtensionsPath",
  "MSBuildExtensionsPath32",
  "MSBuildExtensionsPath64",
  "MSBUILD_EXE_PATH"
)

foreach ($Name in $EnvVarsToClear) {
  Remove-Item "Env:\$Name" -ErrorAction SilentlyContinue
}

$env:MSBUILDDISABLENODEREUSE = "1"
```

Stop stale build processes:

```powershell
Get-Process dotnet,msbuild,vbcscompiler,UnrealBuildTool,UbaServer,UbaSessionServer,UbaAgent -ErrorAction SilentlyContinue |
  Stop-Process -Force
```

Verify bundled DotNet:

```powershell
cmd /d /c "call Engine\Build\BatchFiles\GetDotnetPath.bat && dotnet --version"
```

Expected: the engine-bundled DotNet SDK version prints.

## 2. Optional: Refresh Build Tools

Use this only for a fresh workspace, after cleaning generated UBT/UAT state, or when UBT/UAT/project files look stale.

Do **not** delete all of `Engine\Binaries\DotNET`; it contains checked-in dependencies.

```powershell
python builder/src/build_build_tools.py --repo-root .
python builder/src/generate_project_files.py --repo-root .
```

Expected: `UnrealBuildTool.dll` and `AutomationTool.dll` exist or are rebuilt successfully.

## 3. Build The Editor Target

Default incremental editor build:

```powershell
& ".\Engine\Build\BatchFiles\Build.bat" $EditorTarget Win64 Development "-Project=$Project" -Progress -Unattended -WaitMutex
```

Expected:

- exit code `0`
- editor binaries under `Engine\Binaries\Win64`
- project editor modules under `$ProjectDir\Binaries\Win64`

For a release PCB, or after mixed BuildIds, missing modules, stale plugin DLLs, or loader failures, use the clean no-UBA build:

```powershell
& ".\Engine\Build\BatchFiles\Build.bat" $EditorTarget Win64 Development "-Project=$Project" -WaitMutex -NoUBA -NoUBALocalExecutor -Clean
& ".\Engine\Build\BatchFiles\Build.bat" $EditorTarget Win64 Development "-Project=$Project" -Progress -Unattended -WaitMutex -NoUBA -NoUBALocalExecutor
```

## 4. Rebuild ShaderCompileWorker

BuildGraph stages `ShaderCompileWorker.exe` and `XGEControlWorker.exe` into the PCB. Rebuild them before release PCB validation so UGS users do not hit shader protocol mismatch crashes.

Do not pass `-Project` or `-game` for these engine tools.

```powershell
& ".\Engine\Build\BatchFiles\Build.bat" ShaderCompileWorker Win64 Development -WaitMutex -NoUBA -NoUBALocalExecutor -Clean
& ".\Engine\Build\BatchFiles\Build.bat" ShaderCompileWorker Win64 Development -WaitMutex -NoUBA -NoUBALocalExecutor
```

Verify `ShaderCompileWorker.exe` and `XGEControlWorker.exe` match:

```powershell
$Scw = "$Root\Engine\Binaries\Win64\ShaderCompileWorker.exe"
$Xge = "$Root\Engine\Binaries\Win64\XGEControlWorker.exe"

Get-Item $Scw, $Xge | Select-Object FullName, Length, LastWriteTime
Get-FileHash $Scw, $Xge -Algorithm SHA256
```

Expected: same length, same hash, timestamp from the current build session.

## 5. Verify USD Runtime DLL Parity

Use this when `USDImporter` is enabled.

```powershell
$UsdSdkBin = Join-Path $Root "Engine\Plugins\Runtime\USDCore\Source\ThirdParty\USD\VS2015\x64\bin"
$Win64Bin = Join-Path $Root "Engine\Binaries\Win64"

$Mismatches = Get-ChildItem $UsdSdkBin -File -Filter "*.dll" | ForEach-Object {
  $Dest = Join-Path $Win64Bin $_.Name
  $DestItem = Get-Item $Dest -ErrorAction SilentlyContinue
  [pscustomobject]@{
    Name = $_.Name
    SourceLength = $_.Length
    DestLength = $DestItem.Length
    Matches = ($DestItem -and $_.Length -eq $DestItem.Length)
  }
} | Where-Object { -not $_.Matches }

$Mismatches
```

Expected: no rows.

If rows print, refresh the Win64 copies:

```powershell
Get-ChildItem $UsdSdkBin -File -Filter "*.dll" |
  Copy-Item -Destination $Win64Bin -Force
```

## 6. BuildGraph No-Submit PCB

Always make a local PCB with `-NoSubmit` before submitting. This creates the same local zip while blocking the Perforce submit step.

```powershell
& ".\Engine\Build\BatchFiles\RunUAT.bat" BuildGraph `
  -Script="Engine/Build/Graph/Examples/BuildEditorAndTools.xml" `
  -Target="Submit To Perforce For UGS" `
  "-set:EditorTarget=$EditorTarget" `
  "-set:UProjectPath=$Project" `
  "-set:ArchiveStream=$ArchiveStream" `
  '-set:EditorCompileArgs=-NoUBA -NoUBALocalExecutor' `
  '-set:ToolCompileArgs=-NoUBA -NoUBALocalExecutor' `
  -p4 -NoSubmit `
  -unattended -noturnkeyvariables `
  -UTF8Output
```

Expected local zip directory:

```text
$Root\LocalBuilds\ArchiveForUGS-Perforce
```

The local zip filename should match the leaf filename from `ZippedBinariesPath`:

```powershell
Join-Path "$Root\LocalBuilds\ArchiveForUGS-Perforce" $ExpectedZipName
```

For VisTest, this should resolve to `++vistest-vp+main-VisTestEditor.zip`. Stop if the newest zip name contains `++vistest-vp+main-content`; that means BuildGraph was run from the virtual stream client and is targeting the wrong UGS archive.

## 7. Validate The Local PCB Zip

Get the newest local PCB zip:

```powershell
$Zip = Get-ChildItem "$Root\LocalBuilds\ArchiveForUGS-Perforce" -File -Filter "*.zip" |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 1

$Zip.FullName
$Zip.Name -eq $ExpectedZipName
```

Expected: the second line prints `True`.

### Check BuildIds

```powershell
Add-Type -AssemblyName System.IO.Compression.FileSystem
$Archive = [System.IO.Compression.ZipFile]::OpenRead($Zip.FullName)
try {
  $BuildIds = @{}
  foreach ($Entry in $Archive.Entries) {
    if ($Entry.FullName -like "*UnrealEditor.modules") {
      $Reader = [System.IO.StreamReader]::new($Entry.Open())
      try {
        $Id = ($Reader.ReadToEnd() | ConvertFrom-Json).BuildId
        if (-not $BuildIds.ContainsKey($Id)) {
          $BuildIds[$Id] = 0
        }
        $BuildIds[$Id]++
      }
      finally {
        $Reader.Dispose()
      }
    }
  }
  $BuildIds.GetEnumerator() | Sort-Object Value -Descending
}
finally {
  $Archive.Dispose()
}
```

Expected: exactly one row. More than one BuildId means the PCB is internally mixed and must not be submitted.

### Check Worker Hashes

```powershell
$LocalScwHash = (Get-FileHash "$Root\Engine\Binaries\Win64\ShaderCompileWorker.exe" -Algorithm SHA256).Hash
$LocalXgeHash = (Get-FileHash "$Root\Engine\Binaries\Win64\XGEControlWorker.exe" -Algorithm SHA256).Hash

Add-Type -AssemblyName System.IO.Compression.FileSystem
$Archive = [System.IO.Compression.ZipFile]::OpenRead($Zip.FullName)
try {
  foreach ($Name in @(
    "Engine/Binaries/Win64/ShaderCompileWorker.exe",
    "Engine/Binaries/Win64/XGEControlWorker.exe"
  )) {
    $Entry = $Archive.Entries | Where-Object FullName -eq $Name | Select-Object -First 1
    $Stream = $Entry.Open()
    try {
      $Memory = [System.IO.MemoryStream]::new()
      $Stream.CopyTo($Memory)
      $Hash = [System.BitConverter]::ToString(
        [System.Security.Cryptography.SHA256]::Create().ComputeHash($Memory.ToArray())
      ).Replace("-", "")
      [pscustomobject]@{
        Entry = $Name
        Length = $Entry.Length
        LastWriteTime = $Entry.LastWriteTime.LocalDateTime
        HashMatchesLocal = $Hash -eq $(if ($Name -like "*XGE*") { $LocalXgeHash } else { $LocalScwHash })
      }
    }
    finally {
      $Stream.Dispose()
    }
  }
}
finally {
  $Archive.Dispose()
}
```

Expected: both `HashMatchesLocal` values are `True`.

### Check Required PCB Files

```powershell
Add-Type -AssemblyName System.IO.Compression.FileSystem
$Archive = [System.IO.Compression.ZipFile]::OpenRead($Zip.FullName)
try {
  foreach ($Name in @(
    "Engine/Build/PrecompiledBinaries.txt",
    "Engine/Binaries/Win64/UnrealEditor.version",
    "Engine/Binaries/Win64/UnrealEditor.modules",
    "Engine/Binaries/Win64/ShaderCompileWorker.exe",
    "Engine/Binaries/Win64/XGEControlWorker.exe"
  )) {
    [pscustomobject]@{
      Entry = $Name
      Present = [bool]($Archive.Entries | Where-Object FullName -eq $Name | Select-Object -First 1)
    }
  }
}
finally {
  $Archive.Dispose()
}
```

Expected: all `Present` values are `True`.

## 8. Smoke-Test Editor Module Loading

Run a headless editor smoke test from the same workspace before submitting:

```powershell
& "$Root\Engine\Binaries\Win64\UnrealEditor-Cmd.exe" "$Project" `
  -unattended -nop4 -NullRHI -NoSound -NoSplash `
  -stdout -FullStdOutLogOutput -ExecCmds="Quit"
```

If the command stays open after engine initialization, stop the editor process:

```powershell
Get-Process UnrealEditor,UnrealEditor-Cmd -ErrorAction SilentlyContinue |
  Stop-Process -Force
```

Search for load failures:

```powershell
Select-String -Path "$ProjectDir\Saved\Logs\$ProjectName.log" `
  -Pattern "BuildId .* != |Incompatible or missing module|Engine modules cannot|LogPluginManager: Error|Failed to load|Failed to preload|Missing import|Fatal error" `
  -Context 2,4
```

Expected: no BuildId mismatch, incompatible-module, plugin-load, missing-import, or fatal lines.

Benign examples:

- `aqProf.dll`
- `VtuneApi.dll`
- `WinPixGpuCapturer.dll`
- target-platform SDK warnings for SDKs not installed locally

## 9. Submit The Verified PCB

Only run this after the no-submit zip passes validation.

```powershell
& ".\Engine\Build\BatchFiles\RunUAT.bat" BuildGraph `
  -Script="Engine/Build/Graph/Examples/BuildEditorAndTools.xml" `
  -Target="Submit To Perforce For UGS" `
  "-set:EditorTarget=$EditorTarget" `
  "-set:UProjectPath=$Project" `
  "-set:ArchiveStream=$ArchiveStream" `
  '-set:EditorCompileArgs=-NoUBA -NoUBALocalExecutor' `
  '-set:ToolCompileArgs=-NoUBA -NoUBALocalExecutor' `
  -p4 -submit `
  -unattended -noturnkeyvariables `
  -UTF8Output
```

Expected:

- BuildGraph exits with code `0`.
- UAT reports `BUILD SUCCESSFUL`.
- Perforce submit creates a changelist.
- The submitted archive lands at the `ZippedBinariesPath` configured in `Content\VisTest\Build\UnrealGameSync.ini`.

## 10. Post-Submit Verification

Check the submitted archive head revision using the UGS-configured archive path:

```powershell
p4 files "$ExpectedArchivePath"
p4 fstat -Ol "$ExpectedArchivePath"
```

For VisTest, expected archive path:

```text
//ue-laika/editor-binaries/++vistest-vp+main-VisTestEditor.zip
```

Validate the submitted Perforce archive bytes match the final local zip:

```powershell
$Submitted = p4 fstat -Ol "$ExpectedArchivePath"
$LocalHash = (Get-FileHash $Zip.FullName -Algorithm MD5).Hash

$Submitted | Select-String "headRev|headChange|fileSize|digest"
$LocalHash
```

Expected: the Perforce `digest` equals `$LocalHash`.

Validate the final local zip again with the BuildId and worker hash checks above.

Then verify as a UGS consumer:

1. Create or clean a consumer workspace on `//vistest-vp/main-content`.
2. Sync the submitted precompiled binaries through UGS.
3. Launch the editor from UGS.
4. Confirm there are no missing-module errors.
5. Confirm shader compilation does not fail with a `ShaderCompileWorker` input-version mismatch.
6. Confirm `Content\VisTest\Saved\UnrealGameSync\Editor.zipmanifest` contains the same archive payload you validated, including enabled plugin binaries such as `AudioInsights`, `PixelStreaming2`, `SequenceValidator`, `TrackingAlignment`, and `EaseCurveTool`.

## Log Locations

Project editor logs:

```powershell
Get-ChildItem "$ProjectDir\Saved\Logs" -File |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 5 LastWriteTime, Length, FullName
```

Common logs:

```text
$ProjectDir\Saved\Logs\$ProjectName.log
$Root\Engine\Programs\AutomationTool\Saved\Logs\Log.txt
$Root\Engine\Programs\AutomationTool\Saved\Logs\p4.log
$Root\Engine\Programs\UnrealBuildTool\Log.txt
$Root\Engine\Programs\UnrealBuildTool\Log.uba
$Root\Engine\Programs\UnrealBuildTool\Log.json
```

UGS application logs:

```text
C:\Users\mmccusker\AppData\Local\UnrealGameSync\UnrealGameSync*.log
```

## Troubleshooting

### Missing Modules Or Mixed BuildIds

Do not submit. Clean-build the editor target, rebuild `ShaderCompileWorker`, rerun no-submit BuildGraph, and repeat zip validation.

If this happens only in a clean UGS consumer workspace, first verify archive alignment:

```powershell
Get-Content -Raw "$ProjectDir\Build\UnrealGameSync.ini"
p4 files "$ExpectedArchivePath"
Get-Content -Raw "$ConsumerRoot\Engine\Binaries\Win64\UnrealEditor.version"
```

For VisTest, UGS must consume `//ue-laika/editor-binaries/++vistest-vp+main-VisTestEditor.zip`. A valid zip submitted to `++vistest-vp+main-content-VisTestEditor.zip` does not fix UGS consumers because that is not the configured `ZippedBinariesPath`.

### ShaderCompileWorker Input Version Mismatch

Do not submit or reuse the current PCB. Rebuild `ShaderCompileWorker`, verify `XGEControlWorker` hash parity, rerun BuildGraph, and verify worker hashes inside the zip.

### USD Loader Errors

If logs mention `UnrealUSDWrapper.dll`, `GetLastError=127`, or missing USD imports, refresh USD runtime DLLs from the checked-in USD SDK and rerun validation.

### Wrong Perforce Client

Stop immediately. Do not run any `-p4` BuildGraph command. Rerun the Bootstrap block from the correct workspace location, or set `$P4ClientOverride` to a real client on `$ExpectedClientStream`, then verify:

```powershell
p4 info | Select-String "Client name|Client root|Client stream|Current directory"
```
