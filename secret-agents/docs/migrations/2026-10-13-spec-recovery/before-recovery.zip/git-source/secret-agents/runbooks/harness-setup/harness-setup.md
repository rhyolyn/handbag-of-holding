# Harness Setup Runbook

How to wire a machine and its harnesses to the canonical agent guidance and skills in this vault. Rewritten 2026-08-30 for the `handbag-of-holding` consolidation; design rationale in `docs/specs/2026-08-30-ready-player-one-design.md`. The always-on per-session rules (skill fallback, runbook lookup, symlink-not-copy) stay in `AGENTS.md` § Environment & Harness Adapters.

Run `/ready-player-one` after any step here — it verifies this layout and autofixes safe gaps.

## Principles

- The vault (`handbag-of-holding`, an Obsidian vault and public GitHub repo) is the canonical source; `<agent-root>` is its `secret-agents\` directory, identified by `.agent-root.json`. Obsidian syncs the vault across machines; git pushes happen from one designated machine only.
- The vault contains **only skills we author**. Foreign packs (superpowers, mattpocock-skills, …) are installed per machine via each pack's official mechanism — never copied into the vault, never linked from inside the vault (Obsidian sync flattens links into copies on other machines).
- Harness files are adapters pointing back at `<agent-root>`. Never copy shared guidance or skills where a link will work.
- **Mixing directories** (harness skill dirs that must hold both our skills and foreign content) are real directories containing per-skill links. Never make a mixing directory a whole-dir junction into the vault: third-party installers writing to that path would write through into the vault (this happened; it's why this rule exists).
- Prefer open-standard names (`AGENTS.md`, top-level `SKILL.md`) so content stays portable across harnesses.
- When adding a harness, add its adapter rules below instead of forking content.

## Per-machine bootstrap (new machine, in order)

1. Sync the vault to this machine via Obsidian. Note its local absolute path (differs per machine; drive letters on Windows, none on macOS/Linux).
2. Write the pointer file `~/.agents/root` — one line, the vault's absolute path. Everything else derives from it.
3. Create the adapter links for each harness installed on this machine (tables below) — or just run `/ready-player-one` in any working harness and let autofix create them.
4. Install foreign packs via their official mechanisms (commands in `secret-agents\packs.json`), including the pack's in-progress skills we rely on.
5. Set permissions/trust per harness (below).
6. Run `update-agent-stack` once to seed `~/.agents/versions.json`.
7. Run `/ready-player-one` until the verdict is `ready`.

## Adapter layout

`<root>` below = the vault path from the pointer file; `<agent-root>` = `<root>/secret-agents`. Windows junctions are acceptable for whole-directory links; per-skill links are symlinks (may require Developer Mode on Windows — no copy or hard-link fallbacks).

### Shared (all harnesses)

| Path | Kind | Target |
|------|------|--------|
| `~/.agents/root` | one-line file | absolute path of `<root>` |
| `~/.agents/skills/<skill>` | per-skill symlink (real parent dir) | `<agent-root>/skills/<skill>` |

`~/.agents/skills` is the path most likely to be targeted by cross-harness installers (`npx skills`, etc.) — it must be a real directory so those installs land beside our links instead of inside the vault.

### Claude Code

| Path | Kind | Target |
|------|------|--------|
| `~/.claude/AGENTS.md` | file symlink | `<agent-root>/AGENTS.md` |
| `~/.claude/skills` | whole-dir junction (allowed exception) | `<agent-root>/skills` |

The junction is allowed only because Claude's foreign content arrives via its plugin system. If a future pack has no Claude plugin route, first convert `~/.claude/skills` to a real dir with per-skill links, then install.

Foreign packs: `/plugin install superpowers` (claude-plugins-official), `/plugin install mattpocock-skills` (mattpocock marketplace, already registered in settings).

Permissions: `permissions.defaultMode` = `dontAsk` (or `bypassPermissions`) in **both** `~/.claude/settings.json` and the project's `.claude/settings.json` — agents spawned in worktrees fall back to global.

New/changed skills register at **session start**; a skill added mid-session needs a fresh session (ready-player-one can read it into the current session as a stopgap).

### Codex

| Path | Kind | Target |
|------|------|--------|
| `~/.codex/AGENTS.md` | file symlink | `<agent-root>/AGENTS.md` |
| `~/.codex/skills/<skill>` | per-skill symlink (real parent dir) | `<agent-root>/skills/<skill>` |

Foreign packs: superpowers via `/plugins` → search → install; mattpocock-skills via `npx skills@latest add mattpocock/skills`.

Trust: `[projects.'<project path>'] trust_level = "trusted"` in `~/.codex/config.toml` per project.

### Copilot

Discovery paths, instruction file location, and the trust/approval knob are **TBD — confirm during implementation** and fill in this section. Known: superpowers installs via `copilot plugin install superpowers@superpowers-marketplace`; mattpocock-skills via `npx skills`.

## One-time migration from `worky\Agent` (2026-08)

The former canonical root `C:\git\worky\Agent` (and `D:\git\worky\Agent`) is archived by the user and must not be referenced by any link. On each machine that was wired to it:

1. Repoint `~/.claude/skills` junction → `<agent-root>/skills`.
2. Replace the `~/.agents/skills` junction with a real dir + per-skill links (per the shared table).
3. Recreate `~/.codex/skills` per-skill links against `<agent-root>/skills` (the old set covered only a fraction of the skills).
4. Do **not** migrate skill files from worky: our skills already live in this repo under their current (renamed) names; everything else there was an accidental write-through copy of mattpocock-skills — superseded by official installs.
5. Run `/ready-player-one`.

## Verifying an adapter

Ask the agent: "what revision of the shared guidance is loaded?" A correct revision date from `AGENTS.md` proves the instruction link works; a wrong or missing answer means the link is broken on this harness — recreate it per the tables above, then ask for a full re-read. For skills, `/ready-player-one`'s session-diff is the authoritative probe.
