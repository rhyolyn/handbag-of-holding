# Reconcile the skill migration with the restored design

**Spec:** [Skills library integration](../specs/2026-10-10-skills-library-integration-design.md)

**Goal:** Restore the catalog-owned header, shorthand, generated-alias, query and installer contracts, retaining the unique Worky additions. Recover absent implementation/resources from `C:/git/handbag-of-holding` read-only. Do not alter machine adapters, run bootstrap, or install into live harness directories.

**Scope decision:** Repair migration deviations and failures that prevent reliable regeneration/verification. Preserve the existing installer implementation and its tests; do not redesign its historical transactional architecture. The restored 19-workflow design is extended by the three already-authorized Worky checkin workflows: `checkin-receipt-create` (`rcrc`), `checkin-receipt-range` (`rcrr`), and `checkin-rollup` (`rcr`), all Reporting. Existing aliases remain reserved.

- [ ] Snapshot the current vault and recovery source, restore missing source/tests/resources, and run the original catalog against the migrated files to capture failure. Claude: Sonnet-class; Codex: current session.
- [ ] Restore canonical bodies through explicit merges, human headers and generated ownership; regenerate 22 canonical workflows and 30 aliases with the catalog owner. Claude: Sonnet-class; Codex: current session.
- [ ] Reconcile installer/query/README instructions, guidance and migration records with the spec; preserve historical reviews and Worky data routing. Claude: Sonnet-class; Codex: current session.
- [ ] Run the Python gate, catalog/README checks, cold/warm query verification and independent migration review. Verify originals unchanged and Worky Agent remains absent. Claude: Opus-class review; Codex: current session.

## Verification

Run from `secret-agents`: `python -m mypy`, `python -m ruff check src tests skills/update-model-routing/scripts skills/query-all-skills/scripts`, `python -m ruff format --check src tests skills/update-model-routing/scripts skills/query-all-skills/scripts`, `python -m pytest --tb=short -q`; then catalog `check` and the README renderer. Any source fix receives a failing regression test first. Use a cache inside the recovery audit for catalog probes so machine configuration is unchanged.

## Merge decisions

- Remove migration-added `metadata.category/kind/alias_of`; the post-H1 header is the sole metadata source.
- Restore the original category names and stable shorthands, and reverse the incorrect `ready-player-one` → `agent-preflight` relationship.
- Keep Worky's Jira Epic-parent instructions, Perforce annual rollup behavior, three checkin workflows, Scout runbook, and reporting-vault path reference.
- Generated alias links must expose their own matching frontmatter names; installing an alias as a link to its canonical folder contradicts the spec.
- Preserve the original migration archive as historical evidence; supersede its obsolete schema checks and missing-resource claims.
