# Files Absent From the Scoped Vaults

The 2026-10-13 consolidation inspected every file, including hidden files, under `handbag-of-holding/secret-agents` and `worky/Agent`. These were pre-existing gaps, not migration losses. No outside checkout was searched or used to fill them.

| Missing item | Consequence |
|---|---|
| `src/secret_agents_setup/*`, `tests/*`, `scripts/harness_setup.py`, Python project configuration | Only empty source/test directories and design documents were present. The planned harness installer cannot be run or tested from this vault. |
| `skills/clean-code-error-handling/SKILL.md` | The existing directory has no skill body; references in shared guidance are retained as an explicitly unavailable dependency. |
| `skills/update-model-routing/SKILL.md`, `model-routing.json`, `skills/update-model-routing/scripts/check_staleness.py` | `agent-plan`'s centralized model-routing check is unavailable. Do not invent a passing result. |
| `skills/unreal-reset-build-env/scripts/Stop-UnrealBuildAndCleanEnv.ps1` | The reset skill's executable is absent; retain its procedure but report this missing prerequisite before execution. |
| `skills/query-all-skills/scripts/list_skills.py` | The inventory helper is absent. The canonical skill includes a direct enumeration fallback using skill frontmatter. |
| `skills/update-skills-readme/scripts/render_html.py` | The original renderer/guard is absent. Markdown and derived HTML can be refreshed using an available Markdown renderer plus the documented catalog checks. |
| `skills/update-claude-pricing-doc/output/claude-pricing.json` | No pricing cache was present. The pricing skill can regenerate it when explicitly needed. |
| `skills/*/agents/openai.yaml` | Several `agents/` directories were empty. No UI metadata was available to migrate. |

Worky report, checkin, and Jira templates live outside this migration's read scope. Their availability was not checked; consumers resolve them through [Worky data vault paths](worky-vault-paths.md).

The original directory shells are retained. Empty `Untitled` and cache directories are not skills. The skill catalog lists only directories with a real `SKILL.md`.

Next phase: recover absent implementation/resources from an explicitly authorized source, then update external harness adapters and Worky consumers. The current consolidation does not claim those workflows are operational.
