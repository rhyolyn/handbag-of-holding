# Secret Agents

The canonical source for shared agent guidance, skills, runbooks, designs, and any associated source and tests is this directory in handbag-of-holding.

- [Shared guidance](AGENTS.md)
- [Skill catalog and TOC](skills/README.md)
- [Human guide](HUMANS.md)
- [Harness setup runbook](runbooks/harness-setup/harness-setup.md)
- [Worky data vault paths](runbooks/worky-vault-paths.md)
- [Known missing resources](runbooks/migration-gaps.md)
- [Migration audit](docs/migrations/2026-10-13-worky-agent/README.md)

Each direct child of `skills/` with a `SKILL.md` is one discoverable skill. Use the existing canonical names; compatibility aliases forward all arguments to a canonical sibling skill without duplicating its workflow.

Every skill uses this header shape:

```yaml
---
name: example-skill
description: "Use when the task matches this skill's purpose."
metadata:
  category: agent
  kind: workflow
---
```

Categories are `agent`, `clean-code`, `jira`, `python`, `report`, and `unreal`. Kinds describe the existing catalog roles: `workflow`, `preflight`, `reference`, `gate`, `process`, `generator`, `utility`, `meta`, `script-wrapper`, or `alias`. Alias metadata additionally contains `alias_of: canonical-skill-name`. Keep supported invocation fields when a migrated skill already uses them. Quote descriptions so punctuation remains valid YAML.

When adding or changing a skill, update its category/kind, the catalog inventory, TOC, and usage section together. `README.html` is derived from `skills/README.md`. Empty directories without `SKILL.md` are not installed skills.

Worky owns its reports and templates; resolve those through the shared data-vault reference. External harness links and consumers are migrated separately. Historical plans and the recovery ZIP retain original paths as evidence, not current installation instructions.
