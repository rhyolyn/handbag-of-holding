---
name: install-skills
description: "Use when installing or refreshing linked projections of the canonical shared skills into a harness discovery directory."
argument-hint: "[--all | <skill-name> ...] [--source <dir>] [--target <dir>] [--update] [--help]"
user-invocable: true
metadata:
  category: agent
  kind: utility
---

# Install Skills

Expose canonical skills to a harness using links. The editable source remains in handbag-of-holding. Follow [harness setup](../../runbooks/harness-setup/harness-setup.md) for harness-specific paths; this skill does not discover or bootstrap unrelated infrastructure.

## Invocation / Flags

| Argument | Effect |
|---|---|
| *(none)* or `--all` | Select every direct child of the source containing `SKILL.md`. |
| `<skill-name> ...` | Select only the named skills. |
| `--source <dir>` | Override the source; default is the parent of this skill directory. |
| `--target <dir>` | Harness discovery directory. Resolve from the user's request or the confirmed adapter configuration; ask when unspecified or ambiguous. |
| `--update` | Verify selected existing links and add missing ones. Source edits already appear through correct links. |
| `--help` | Explain these flags and the link-only behavior, then stop without changing files. |

Examples: `@skill install-skills --target <discovery directory>`; `@skill install-skills run-unit-tests rut --target <discovery directory>`; `@skill install-skills --update --target <discovery directory>`.

## Procedure

1. Resolve source and target to absolute paths. When they are the same directory, report that it is already the source and make no changes. Reject a target nested inside a source skill.
2. Enumerate selected direct-child skill directories. Skip README files and directories without `SKILL.md`; report requested names that are absent. Validate YAML, folder/name agreement, category/kind, and direct alias targets before changing destinations. Include each alias's canonical target when selecting an alias.
3. Inspect each target entry before creating anything. A link to the intended source is already correct. A regular directory, unrelated file, or link to a different source is a conflict: report its path and obtain an explicit conflict-resolution choice. Never overwrite or recursively delete it as an update.
4. Create directory symbolic links on Linux/macOS, or directory junctions on Windows. Resolve absolute source paths before creating Windows junctions. If linking is unavailable, report the capability problem and stop; do not silently switch to copied skill bodies.
5. Verify each installed link resolves to its intended source and exposes the matching `SKILL.md`. Report name, source, destination, counts of created/already-correct/conflicting entries, and any failure. Leave unrelated installed skills intact. Do not stage or commit anything.

## Compatibility

The former Worky skill copied folders and defaulted the target to its own install directory. That behavior conflicts with handbag-of-holding's single editable source. `--update` now means link verification and addition; existing copied installations require an explicit migration decision. The original procedure is preserved in the migration recovery archive.

Machine-level installation is separate from the vault-content migration. Loading this skill's documentation is not an instruction to run it.
