---
name: update-skills-readme
description: "Use when a skill under the canonical secret-agents/skills is added, removed, or edited, when the skills README.md or README.html is missing or stale, or when the user invokes /update-skills-readme (optionally with \"review\")."
metadata:
  category: agent
  kind: meta
---

# Update Skills README

Keep `<skills root>\README.md` and `README.html` in sync with the skill set. The markdown is the source of truth; the HTML is rendered from it and never hand-edited.

## Paths & Model

- Skills root: `<skill base dir>\..` (the canonical root is `handbag-of-holding/secret-agents`).
- Optional renderer/guard: `<skill base dir>\scripts\render_html.py`; this helper was absent from both scoped vaults at migration. Use the fallback checks below when unavailable.
- Model: Sonnet-class without `review`; frontier-class when `review` is passed — reviews are judgment, not transcription.

## Arguments

- *(none)* — factual refresh: inventory, parameters, call formats, examples, categorized TOC, coverage matrix. Existing per-skill **Architect's review.** blocks are preserved verbatim.
- `review` — additionally regenerate every Architect's review (strengths, weaknesses, improvements) from a full read of each SKILL.md.

## Steps

1. **Inventory.** Every directory under the skills root containing a `SKILL.md`. Read each skill's frontmatter, including `metadata.category`, `metadata.kind`, and `metadata.alias_of`; read full bodies for skills that are new or changed since the README's generated date (all of them under `review`).
2. **Regenerate README.md** keeping its section contract: intro with generated date, Table of Contents, "How skills are wired and invoked", "Skill inventory" table, one `### <skill-name>` section per skill (What it does / When to use / Parameters / Examples for Claude, Codex, and Copilot / Architect's review), "Architect's overview" (harness coverage matrix, skill gaps, token-costly mistakes), "Maintaining this document".
   - Without `review`: copy each existing **Architect's review.** block unchanged; a skill with no existing review gets `> Review pending — rerun with "review".`
   - Verify factual claims (paths, wiring, file existence) with checks before asserting them; never carry a claim forward untested under `review`.
3. **Render + verify:** if the helper exists, run `uv run <skill base dir>\scripts\render_html.py`. The script exits 2 with named problems when a skill directory has no `### <name>` section or `#<name>` link, when any anchor is dead, or when it scans zero skills. Fix the README and re-run.
4. **Output.** Print the README.md path, the README.html path, then the actual verification result. Do not report a script result when only fallback checks ran.

## Common Mistakes

- Editing README.html directly — the next render silently discards the edit.
- Rendering before updating the markdown — the guard checks structure, not freshness; it will green stale prose.
- Running `review` on a small model — reviews come out generic praise; preserve them instead.
- Treating a guard failure as an obstacle — "missing section" means a skill is undocumented; document it, never weaken the script's checks to get to green.

## Fallback when the renderer is absent

Render `README.md` with an available Markdown renderer supporting tables and heading IDs (for example Python Markdown with `tables` and `toc`) into a complete UTF-8 `README.html` document. Keep generated HTML derived from Markdown. Run these checks independently of rendering:

- At least one direct child contains `SKILL.md`; zero skills is a failure.
- Every skill's YAML parses and its `name` matches its directory. `metadata.category` and `metadata.kind` are nonempty strings.
- Every alias has an existing direct canonical target, and the target is not another alias.
- Each skill has exactly one `### <name>` section, a TOC `#<name>` link, and an inventory row.
- Every local README link and fragment resolves, and the rendered HTML has matching heading IDs.
- Missing optional helpers or skill bodies remain listed in [migration gaps](../../runbooks/migration-gaps.md), not advertised as installed skills.

Preserve prior Architect's review text with a historical-review label when facts have changed. Do not present old machine-wiring observations as current verification.
