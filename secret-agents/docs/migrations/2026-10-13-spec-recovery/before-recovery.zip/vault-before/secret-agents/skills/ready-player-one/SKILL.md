---
name: ready-player-one
description: "Use when the user invokes ready-player-one as an alias for agent-preflight."
metadata:
  category: agent
  kind: alias
  alias_of: agent-preflight
---

# ready-player-one

This skill is a shorthand alias for `agent-preflight`.

## Behavior

1. Read [the canonical skill](../agent-preflight/SKILL.md).
2. Forward every argument unchanged, including any flags, `help`, or `--help`.
3. Follow that skill's workflow and output contract. If the canonical file is missing, report the missing path instead of inventing a replacement workflow.

## Examples

- `@skill ready-player-one`
- `/ready-player-one` with the same arguments supported by `agent-preflight`.
