# Handbag of Holding Agent Skills

The canonical shared collection lives in `handbag-of-holding/secret-agents/skills`. Each listed skill has a real `SKILL.md`; aliases forward to one canonical workflow. Edit these files in handbag-of-holding. Worky contains only a pointer to this collection.

*Updated 2026-10-13 during consolidation. Markdown is authoritative; `README.html` is derived. Historical Architect's reviews are preserved verbatim and are not fresh operational validation.*

## Table of Contents

- [How skills are wired and invoked](#how-skills-are-wired-and-invoked)
- [Skill inventory](#skill-inventory)

**agent**

- [agent-plan](#agent-plan)
- [agent-preflight](#agent-preflight)
- [install-skills](#install-skills)
- [qas](#qas)
- [query-all-skills](#query-all-skills)
- [ready-player-one](#ready-player-one)
- [update-claude-pricing-doc](#update-claude-pricing-doc)
- [update-skills-readme](#update-skills-readme)

**clean-code**

- [architecture-guards](#architecture-guards)
- [clean-code-architecture-guards](#clean-code-architecture-guards)

**jira**

- [jira-ht](#jira-ht)
- [jira-human-ticket-create](#jira-human-ticket-create)

**python**

- [python-quality-gate](#python-quality-gate)
- [python-tdd-cycle](#python-tdd-cycle)
- [run-unit-tests](#run-unit-tests)
- [rut](#rut)

**report**

- [checkin-receipt-create](#checkin-receipt-create)
- [checkin-receipt-range](#checkin-receipt-range)
- [checkin-rollup](#checkin-rollup)
- [report-receipt](#report-receipt)
- [report-rollup](#report-rollup)
- [report-status](#report-status)
- [status-report-create](#status-report-create)
- [work-receipt-create](#work-receipt-create)

**unreal**

- [reset-unreal-build-environment](#reset-unreal-build-environment)
- [run-mac-coverage](#run-mac-coverage)
- [ugs-pcb-release](#ugs-pcb-release)
- [unreal-reset-build-env](#unreal-reset-build-env)
- [unreal-ugs-release](#unreal-ugs-release)

- [Architect's overview](#architects-overview)
- [Maintaining this document](#maintaining-this-document)

## How skills are wired and invoked

Use the visible skill through your harness, or explicitly request `@skill <name>` and read its `SKILL.md`. Where the harness supports slash invocation, use `/<name>`. For file-based invocation, attach `<agent-root>/skills/<name>/SKILL.md`. Only skills that document `help` or `--help` guarantee that option.

Machine discovery and adapter wiring were not inspected or changed during this migration. Follow the [harness setup runbook](../runbooks/harness-setup/harness-setup.md) when updating those integrations in phase two. `worky/AGENTS.md` is the vault-level pointer.

All headers contain `name`, `description`, `metadata.category`, and `metadata.kind`. Aliases also contain `metadata.alias_of`. See the [authoring convention](../README.md). Report and Jira workflows resolve Worky inputs and outputs through [Worky data vault paths](../runbooks/worky-vault-paths.md).

## Skill inventory

| Skill | Category | Kind | Canonical target | Parameters |
|---|---|---|---|---|
| [agent-plan](#agent-plan) | agent | workflow | — | Planning request. |
| [agent-preflight](#agent-preflight) | agent | preflight | — | None; detects harness and OS. |
| [architecture-guards](#architecture-guards) | clean-code | alias | [clean-code-architecture-guards](#clean-code-architecture-guards) | The architectural rule to enforce. |
| [checkin-receipt-create](#checkin-receipt-create) | report | generator | — | One Perforce changelist number. |
| [checkin-receipt-range](#checkin-receipt-range) | report | workflow | — | `start YYYY/MM/DD end YYYY/MM/DD`. |
| [checkin-rollup](#checkin-rollup) | report | generator | — | `biweekly <end-date>`, `month YYYY-MM`, or `window <start>..<end>`. |
| [clean-code-architecture-guards](#clean-code-architecture-guards) | clean-code | reference | — | The architectural rule to enforce. |
| [install-skills](#install-skills) | agent | utility | — | `[--all \| <name> ...] [--source <dir>] [--target <dir>] [--update] [--help]`. |
| [jira-ht](#jira-ht) | jira | alias | [jira-human-ticket-create](#jira-human-ticket-create) | `help` or ticket title, context, and acceptance criteria. |
| [jira-human-ticket-create](#jira-human-ticket-create) | jira | workflow | — | `help` or ticket title, context, and acceptance criteria. |
| [python-quality-gate](#python-quality-gate) | python | gate | — | Python project context. |
| [python-tdd-cycle](#python-tdd-cycle) | python | process | — | Feature or fix in a pytest project. |
| [qas](#qas) | agent | alias | [query-all-skills](#query-all-skills) | `[--target <dir>] [--help]`. |
| [query-all-skills](#query-all-skills) | agent | utility | — | `[--target <dir>] [--help]`. |
| [ready-player-one](#ready-player-one) | agent | alias | [agent-preflight](#agent-preflight) | None; detects harness and OS. |
| [report-receipt](#report-receipt) | report | generator | — | Work details and optional verbatim text. |
| [report-rollup](#report-rollup) | report | generator | — | `month YYYY-MM` or `year YYYY`. |
| [report-status](#report-status) | report | generator | — | Optional `window YYYY-MM-DD..YYYY-MM-DD`. |
| [reset-unreal-build-environment](#reset-unreal-build-environment) | unreal | alias | [unreal-reset-build-env](#unreal-reset-build-env) | Helper flags including `-Root`, `-WhatIf`, and opt-in `-IncludeEditor`. |
| [run-mac-coverage](#run-mac-coverage) | unreal | workflow | — | `[--target <dir>] [--package <dir>] [--help]`. |
| [run-unit-tests](#run-unit-tests) | python | gate | — | `[--target <dir>] [--fix] [--help]`. |
| [rut](#rut) | python | alias | [run-unit-tests](#run-unit-tests) | `[--target <dir>] [--fix] [--help]`. |
| [status-report-create](#status-report-create) | report | alias | [report-status](#report-status) | Optional `window YYYY-MM-DD..YYYY-MM-DD`. |
| [ugs-pcb-release](#ugs-pcb-release) | unreal | alias | [unreal-ugs-release](#unreal-ugs-release) | Build profile and any explicitly authorized submit behavior. |
| [unreal-reset-build-env](#unreal-reset-build-env) | unreal | script-wrapper | — | Helper flags including `-Root`, `-WhatIf`, and opt-in `-IncludeEditor`. |
| [unreal-ugs-release](#unreal-ugs-release) | unreal | workflow | — | Build profile and any explicitly authorized submit behavior. |
| [update-claude-pricing-doc](#update-claude-pricing-doc) | agent | utility | — | No arguments. |
| [update-skills-readme](#update-skills-readme) | agent | meta | — | Optional `review`. |
| [work-receipt-create](#work-receipt-create) | report | alias | [report-receipt](#report-receipt) | Work details and optional verbatim text. |

---

### agent-plan

**What it does.** Builds resumable implementation plans with named model-routing profiles and task handoffs. The referenced routing file, update skill, and checker are absent in this scoped vault; the skill reports that prerequisite before claiming a freshness check.

**When to use.** Use when creating or revising an implementation plan that may span agents or sessions and needs explicit model routing, context-efficient batches, copy/paste handoffs, or durable progress tracking.

**Parameters.** Planning request.

**Examples.**

- Claude: `@skill agent-plan <task details>`
- Codex: `@skill agent-plan <task details>`
- Copilot: attach [SKILL.md](agent-plan/SKILL.md) and request `agent-plan <task details>`.

**Architect's review.**

> Review pending — rerun with "review".

### agent-preflight

**What it does.** Pre-flight environment check before executing a batched prompt or complex task. Detects harness (claude/codex/copilot) and OS (win/lin/mac), runs harness-specific checks, and outputs "ready" or a tailored remediation list. No partial passes — every check must pass before you proceed.

**When to use.** Pre-flight environment check before executing a batched prompt or complex task. Detects harness (claude/codex/copilot) and OS (win/lin/mac), runs harness-specific checks, and outputs "ready" or a tailored remediation list. No partial passes — every check must pass before you proceed.

**Parameters.** None; detects harness and OS.

**Examples.**

- Claude: `@skill agent-preflight <task details>`
- Codex: `@skill agent-preflight <task details>`
- Copilot: attach [SKILL.md](agent-preflight/SKILL.md) and request `agent-preflight <task details>`.

**Architect's review.**

> Review pending — rerun with "review".

### architecture-guards

**What it does.** Forwards all arguments to [clean-code-architecture-guards](#clean-code-architecture-guards); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes architecture-guards as an alias for clean-code-architecture-guards.

**Parameters.** The architectural rule to enforce.

**Examples.**

- Claude: `@skill architecture-guards <task details>`
- Codex: `@skill architecture-guards <task details>`
- Copilot: attach [SKILL.md](architecture-guards/SKILL.md) and request `architecture-guards <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* The four-property guard definition is genuinely excellent engineering doctrine — especially "fails loudly when it scans nothing," which kills the most expensive kind of green build. The planted-violation pattern means guards are themselves tested. Maps 1:1 onto AGENTS.md § Enforcement, so skill and standing rules can't drift apart. The per-ecosystem quick-reference table gives instant altitude before diving in.
- *Weaknesses:* The reference scanner exists only as an inline code block — every use re-types ~30 lines into a new repo instead of copying a shipped file. No CI-wiring example (the recipes end at the test; the "runs in CI" property is asserted, not demonstrated). Python gets a full implementation; Unreal and TS get prose.
- *Improvements:* Ship the scanner as `scripts/import_scanner.py` in the skill directory. Add one minimal CI snippet per ecosystem. Cross-link python-quality-gate as the local runner of these guards. Ironic gap worth closing: the skill set itself has no machine-checked guards (see [Skill gaps](#skill-gaps)).

### checkin-receipt-create

**What it does.** Writes one structured receipt for a single Perforce changelist to `Checkins/perforce/YYYY/YYYY-MM/CK-<cl>-<slug>.md`. Fetches the CL summary and full diffs via `p4 describe`, classifies noise CLs (stream creation, binary-archive, all-binary file lists) as stubs, counts diff lines added/removed, derives competency tags and initiative arc, fills the Checkin Receipt Template, and appends a cost-ledger row. Idempotent: skips existing receipts by CL number.

**When to use.** Use when the user asks to write a checkin receipt for a single Perforce changelist, or explicitly invokes @skill checkin-receipt-create with a CL number. Examines the changelist's description, file list, and diffs (not just the submit comment) and writes a structured receipt to Checkins/perforce/.

**Parameters.** One Perforce changelist number.

**Examples.**

- Claude: `@skill checkin-receipt-create 7399`
- Codex: `@skill checkin-receipt-create 7399`
- Copilot: attach [SKILL.md](checkin-receipt-create/SKILL.md) and request `checkin-receipt-create 7399`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### checkin-receipt-range

**What it does.** Mass-populates `Checkins/perforce/` by driving `checkin-receipt-create` for every submitted CL the logged-in Perforce user made within a date range. Lists CLs with `p4 changes -u <user>`, filters to submitted CLs in the window, processes oldest-first, chunks long ranges into monthly batches with progress reporting, skips failures gracefully, and idempotently re-runs over the same range (relying on `checkin-receipt-create`'s own idempotency to skip existing receipts).

**When to use.** Use when the user asks to backfill or generate checkin receipts for every Perforce changelist in a date range, or explicitly invokes @skill checkin-receipt-range with start and end dates. Drives checkin-receipt-create across all submitted CLs in the window, idempotently.

**Parameters.** `start YYYY/MM/DD end YYYY/MM/DD`.

**Examples.**

- Claude: `@skill checkin-receipt-range start 2026/01/01 end 2026/10/12`
- Codex: `@skill checkin-receipt-range start 2026/01/01 end 2026/10/12`
- Copilot: attach [SKILL.md](checkin-receipt-range/SKILL.md) and request `checkin-receipt-range start 2026/01/01 end 2026/10/12`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### checkin-rollup

**What it does.** Summarizes the vault's Perforce checkin receipts over a reporting window — bi-weekly, monthly, or custom — grouped by initiative arc. Outputs a rollup document to `Checkins/perforce/rollups/<label>.md` with a summary, per-arc completed-work bullets and impact line, ready-to-paste status bullet candidates, and a noise-CL count. Idempotent: skips if the rollup already exists. Appends a cost-ledger row.

**When to use.** Use when the user asks to summarize Perforce checkin receipts over a bi-weekly, monthly, or custom window, or explicitly invokes @skill checkin-rollup with a cadence argument. Groups checkin receipts by initiative arc and produces a summary with status-bullet candidates.

**Parameters.** `biweekly <end-date>`, `month YYYY-MM`, or `window <start>..<end>`.

**Examples.**

- Claude: `@skill checkin-rollup month 2026-10`
- Codex: `@skill checkin-rollup month 2026-10`
- Copilot: attach [SKILL.md](checkin-rollup/SKILL.md) and request `checkin-rollup month 2026-10`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### clean-code-architecture-guards

**What it does.** Use when establishing an architectural rule that must survive future sessions — layer boundaries, import direction, state ownership, size tripwires — or when such a rule exists only in prose, review feedback, or comments and has no failing check in CI.

**When to use.** Use when establishing an architectural rule that must survive future sessions — layer boundaries, import direction, state ownership, size tripwires — or when such a rule exists only in prose, review feedback, or comments and has no failing check in CI.

**Parameters.** The architectural rule to enforce.

**Examples.**

- Claude: `@skill clean-code-architecture-guards <task details>`
- Codex: `@skill clean-code-architecture-guards <task details>`
- Copilot: attach [SKILL.md](clean-code-architecture-guards/SKILL.md) and request `clean-code-architecture-guards <task details>`.

**Architect's review.**

> Review pending — rerun with "review".

### install-skills

**What it does.** Creates or verifies links from a chosen harness discovery directory to canonical skills. Existing copies or links to other sources are reported as conflicts. Source edits remain in handbag-of-holding.

**When to use.** Use when installing or refreshing linked projections of the canonical shared skills into a harness discovery directory.

**Parameters.** `[--all | <name> ...] [--source <dir>] [--target <dir>] [--update] [--help]`.

**Examples.**

- Claude: `@skill install-skills --help`
- Codex: `@skill install-skills --help`
- Copilot: attach [SKILL.md](install-skills/SKILL.md) and request `install-skills --help`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### jira-ht

**What it does.** Forwards all arguments to [jira-human-ticket-create](#jira-human-ticket-create); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes jira-ht as an alias for jira-human-ticket-create.

**Parameters.** `help` or ticket title, context, and acceptance criteria.

**Examples.**

- Claude: `@skill jira-ht help`
- Codex: `@skill jira-ht help`
- Copilot: attach [SKILL.md](jira-ht/SKILL.md) and request `jira-ht help`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### jira-human-ticket-create

**What it does.** Creates structured Jira tickets for human developers using Worky intake templates, including the migrated Epic-parent object syntax and verification procedure.

**When to use.** Use when creating Jira tickets intended for human developers, especially when the request includes a title and partial technical context and needs a structured template with minimal follow-up questions.

**Parameters.** `help` or ticket title, context, and acceptance criteria.

**Examples.**

- Claude: `@skill jira-human-ticket-create help`
- Codex: `@skill jira-human-ticket-create help`
- Copilot: attach [SKILL.md](jira-human-ticket-create/SKILL.md) and request `jira-human-ticket-create help`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### python-quality-gate

**What it does.** Runs the four-tool gate in strict order — `mypy`, `ruff check`, `ruff format --check`, `pytest` — and requires all four to exit clean before any commit. Includes exact pass-criteria strings, a never-suppress policy (`# type: ignore` / `# noqa` need explicit user approval), and observed fix patterns for common mypy/ruff findings.

**When to use.** Use before committing any Python change. Runs the four-tool gate in order — mypy, ruff check, ruff format --check, pytest — and requires all four to pass clean before the commit is allowed. Fix violations in code; never suppress.

**Parameters.** Python project context.

**Examples.**

- Claude: `@skill python-quality-gate <task details>`
- Codex: `@skill python-quality-gate <task details>`
- Copilot: attach [SKILL.md](python-quality-gate/SKILL.md) and request `python-quality-gate <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* Ordering (types → lint → format → tests) fails fast on the cheapest tools first. Exact expected output strings prevent "close enough" passes. The never-suppress policy with a surface-to-user escape hatch is the right default; the documented project fix patterns (B008 sentinel, `findChild` assertion) save real debugging time.
- *Weaknesses:* Hard-codes the `src/ tests/` layout, and the `ugs.exe` lock advice is project baggage in a shared skill — AGENTS.md's own admission test says repo-specific conventions belong in that repo's AGENTS.md. No mention of the write-mode `ruff format` fast path (fix then verify with `--check`). Assumes mypy is configured; silent no-op if a repo lacks `[tool.mypy]`.
- *Improvements:* Read paths from `pyproject.toml` or accept them as an argument. Move the ugs.exe fallback note to the ugs repo. Add "if format check fails: run `ruff format`, then re-run the full gate."

### python-tdd-cycle

**What it does.** Enforces the red-green loop for pytest projects: write the failing test, *observe* it fail, implement the minimum, observe green, then run the full suite before committing. Defines "done" as tests that were seen failing before implementation, with no skips or suppressions.

**When to use.** Use when implementing any new feature or fix in a Python project that uses pytest. Enforces the red-green loop: write failing tests first, confirm they fail, implement, confirm they pass, then run the full suite before committing.

**Parameters.** Feature or fix in a pytest project.

**Examples.**

- Claude: `@skill python-tdd-cycle <task details>`
- Codex: `@skill python-tdd-cycle <task details>`
- Copilot: attach [SKILL.md](python-tdd-cycle/SKILL.md) and request `python-tdd-cycle <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* "Confirm red" is the step every agent (and human) skips, and this skill makes it non-negotiable — a test that passes before implementation is declared wrong, which catches tautological tests. Narrow-file-then-full-suite laddering keeps iteration fast. Clean scope boundary with the commit workflow.
- *Weaknesses:* Same `ugs.exe` project leak as the quality gate. No guidance for the place TDD actually dies: hard-to-test seams (Qt widgets, filesystem, subprocess). On Claude it overlaps `superpowers:test-driven-development` with no statement of precedence — two skills claiming the same loop invites inconsistent behavior.
- *Improvements:* Add a short seams section (fake the boundary, test the logic). Declare precedence explicitly ("on Claude, superpowers TDD governs process; this skill supplies the pytest specifics"). Move the Windows/uv note to the ugs repo's AGENTS.md.

### qas

**What it does.** Forwards all arguments to [query-all-skills](#query-all-skills); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes qas as an alias for query-all-skills.

**Parameters.** `[--target <dir>] [--help]`.

**Examples.**

- Claude: `@skill qas --help`
- Codex: `@skill qas --help`
- Copilot: attach [SKILL.md](qas/SKILL.md) and request `qas --help`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### query-all-skills

**What it does.** Lists canonical skills with aliases grouped beside their targets. Reads the canonical skill directory by default, or `--target`; uses direct frontmatter enumeration when the optional helper is absent.

**When to use.** List all installed agent skills from the shared skills folder, showing each skill name and pairing any shorthand alias with its parent on the same line, then tell the user how to get usage for a skill. Use when the user asks to list skills, see all skills, what skills exist, or says 'qas'.

**Parameters.** `[--target <dir>] [--help]`.

**Examples.**

- Claude: `@skill query-all-skills --help`
- Codex: `@skill query-all-skills --help`
- Copilot: attach [SKILL.md](query-all-skills/SKILL.md) and request `query-all-skills --help`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### ready-player-one

**What it does.** Forwards all arguments to [agent-preflight](#agent-preflight); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes ready-player-one as an alias for agent-preflight.

**Parameters.** None; detects harness and OS.

**Examples.**

- Claude: `@skill ready-player-one <task details>`
- Codex: `@skill ready-player-one <task details>`
- Copilot: attach [SKILL.md](ready-player-one/SKILL.md) and request `ready-player-one <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* The strict output contract is the standout design decision — deterministic, diffable, no model editorializing. Remediation is specific (exact file, exact key, exact command) per OS *and* harness. The model-recommendation step is cost-awareness built into the process. Placeholders for unknown Copilot mechanics are honest rather than invented.
- *Weaknesses:* Field-tested 2026-07-12 and two cracks showed. (1) Check 2 demands the literal key in both project and global settings, but Claude settings inherit — global `dontAsk` with no project file is effectively `dontAsk`, yet the check fails; worse, the auto-mode classifier *denies agents writing that key* (self-escalation guard), so the skill prescribes a remediation an agent cannot perform and then forbids proceeding: an autonomous dead-end. (2) The "restart on haiku" advice is wrong when the preflight runs inline before a complex batch in the same session — a restart would throw away the correctly-chosen model. Also: the uv check runs even in repos where uv is irrelevant, and the dir-name exe heuristic is a permanent no-op in non-build repos (`worky.exe` will never exist).
- *Improvements:* Test effective permission mode (project value *or* inherited global) instead of file literals, and mark Check-2 remediation "human-only: classifier blocks agent self-service." Scope the model warning to standalone checklist runs. Gate Check 3 on project type (presence of `pyproject.toml`/`uv.lock`; build-artifact check only where a build exists). Fill the Copilot placeholders when the adapter lands.

### report-receipt

**What it does.** Use when the user asks to create or update a work receipt, WR, handoff note, status receipt, completion receipt, progress receipt, or explicitly invokes @skill report-receipt; especially when saving analysis, summarizing engineering work, or preserving text verbatim in a receipt.

**When to use.** Use when the user asks to create or update a work receipt, WR, handoff note, status receipt, completion receipt, progress receipt, or explicitly invokes @skill report-receipt; especially when saving analysis, summarizing engineering work, or preserving text verbatim in a receipt.

**Parameters.** Work details and optional verbatim text.

**Examples.**

- Claude: `@skill report-receipt <task details>`
- Codex: `@skill report-receipt <task details>`
- Copilot: attach [SKILL.md](report-receipt/SKILL.md) and request `report-receipt <task details>`.

**Architect's review.**

> Review pending — rerun with "review".

### report-rollup

**What it does.** Creates monthly summaries from status reports and living annual reviews from monthly Perforce checkin rollups. Monthly output is idempotent; annual reruns fold in newly available monthly evidence. Annual output is `<vault>/Reviews/Performance/YYYY/perforce-annual-YYYY.md`.

**When to use.** Use when rolling up status reports into a monthly report or Perforce monthly checkin rollups into an annual performance-review document, when a scheduled monthly-rollup run fires, or when the user invokes /report-rollup with "month YYYY-MM" or "year YYYY".

**Parameters.** `month YYYY-MM` or `year YYYY`.

**Examples.**

- Claude: `@skill report-rollup month 2026-10`
- Codex: `@skill report-rollup month 2026-10`
- Copilot: attach [SKILL.md](report-rollup/SKILL.md) and request `report-rollup month 2026-10`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* Idempotency (existing output → skip, never overwrite) makes scheduled re-fires safe. Draft flagging propagates data-quality state instead of laundering it. The audience split is real editorial guidance — the annual's "impact, scope, growth narratives, not a chronological log" is exactly what performance-review material needs. Empty window still writes a document: absence of work is information.
- *Weaknesses:* Pacific offsets are hand-managed prose ("-07:00 PDT, -08:00 PST") — a DST-transition bug waiting for a model to make it. The cost-ledger header contract is duplicated across three skills (this, status-report-create, work-receipt-create); a header change is a three-file edit today. Window math and source-selection rules have no executable test — precisely the "rule in prose" the vault's own architecture-guards skill warns about. No model recommendation despite being a scheduled, cost-sensitive run.
- *Improvements:* Extract a shared `scripts/` helper (window computation + ledger append) with pytest coverage, used by both report skills. Add a model line ("Sonnet-class; judgment is summarization"). Document the rerun-after-bad-output path (delete the file, rerun) since idempotency intentionally blocks regeneration.

### report-status

**What it does.** Use when generating a Tue/Thu status report from work receipts, when a scheduled status-report run fires, or when the user invokes /report-status (optionally with an explicit window override like "window 2026-07-07..2026-07-09").

**When to use.** Use when generating a Tue/Thu status report from work receipts, when a scheduled status-report run fires, or when the user invokes /report-status (optionally with an explicit window override like "window 2026-07-07..2026-07-09").

**Parameters.** Optional `window YYYY-MM-DD..YYYY-MM-DD`.

**Examples.**

- Claude: `@skill report-status window 2026-10-06..2026-10-08`
- Codex: `@skill report-status window 2026-10-06..2026-10-08`
- Copilot: attach [SKILL.md](report-status/SKILL.md) and request `report-status window 2026-10-06..2026-10-08`.

**Architect's review.**

> Review pending — rerun with "review".

### reset-unreal-build-environment

**What it does.** Forwards all arguments to [unreal-reset-build-env](#unreal-reset-build-env); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes reset-unreal-build-environment as an alias for unreal-reset-build-env.

**Parameters.** Helper flags including `-Root`, `-WhatIf`, and opt-in `-IncludeEditor`.

**Examples.**

- Claude: `@skill reset-unreal-build-environment <task details>`
- Codex: `@skill reset-unreal-build-environment <task details>`
- Copilot: attach [SKILL.md](reset-unreal-build-environment/SKILL.md) and request `reset-unreal-build-environment <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* Safe-by-default design: Perforce state preserved, editor untouched without `-IncludeEditor`, `-WhatIf` offered for shared machines. The Common Mistakes section names the real footgun — running the cleaner in a child shell cleans the *child's* environment, accomplishing nothing. Delegating enumeration to a script is correct; process-tree walking is exactly what prose instructions get wrong.
- *Weaknesses:* **The script does not exist in this checkout** — `scripts\Stop-UnrealBuildAndCleanEnv.ps1` is absent from the repo (verified 2026-07-12), so on this machine the skill is prose describing a tool that isn't there. It was presumably never committed from the work machine. Compounding it, the Quick Start hard-codes `D:\git\worky\...`, which fails on the `C:\git\worky` machine even after the script lands — harness-setup.md explicitly warns paths must resolve per machine.
- *Improvements:* **Commit the script** — it's the skill's entire engine. Replace the hard-coded skill path with the `<skill base dir>` convention its sibling skills already use. Add a post-run verification one-liner (list surviving Unreal/MSBuild processes) so "clean" is evidence, not assumption.

### run-mac-coverage

**What it does.** Full operating guide for running Scout C++ LLVM code coverage on a Mac using the `laika-build-unreal` coverage pipeline: get and install the package, verify prerequisites (xcrun LLVM tools, project file, disk space), run the full or skip-build pipeline, verify all four report types (HTML, LCOV, text, summary), and troubleshoot common failure modes (exit codes 1 and 2, 0% coverage, mismatched-data warnings, stale UBA sessions). Includes expected coverage baselines (validated 2026-10-09) and a full CLI reference for `run_mac_coverage`.

**When to use.** Use when running, validating, or debugging Scout Mac LLVM code coverage on a Mac test runner. Covers getting/installing the latest laika-build-unreal, running the coverage pipeline, verifying generated reports (HTML, LCOV, text, summary), and troubleshooting common failures.

**Parameters.** `[--target <dir>] [--package <dir>] [--help]`.

**Examples.**

- Claude: `@skill run-mac-coverage --help`
- Codex: `@skill run-mac-coverage --help`
- Copilot: attach [SKILL.md](run-mac-coverage/SKILL.md) and request `run-mac-coverage --help`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### run-unit-tests

**What it does.** Runs a Python project's unit tests inside a managed `.venv`, creating and fully provisioning it if missing (requirements.txt, dev/testing extras, pre-commit, ruff, mypy). Runs `pytest -q` and `pre-commit run --all-files` and reports a green/red verdict. With `--fix`, repairs failing tests and pre-commit violations (auto-fix first, then hand-edit), re-runs until clean, and produces a commit message if any files changed — without staging or committing anything. Works on any pytest + pre-commit Python project from a fresh clone.

**When to use.** Run a Python project's unit tests in a managed .venv. Creates the venv if missing, installs all test + pre-commit requirements (pytest, pre-commit, ruff, mypy, etc.), runs the full test suite and pre-commit, and (with --fix) repairs any failing tests or pre-commit violations. Use when the user asks to run unit tests, run the test suite, run pytest, check pre-commit, or says 'rut'.

**Parameters.** `[--target <dir>] [--fix] [--help]`.

**Examples.**

- Claude: `@skill run-unit-tests --help`
- Codex: `@skill run-unit-tests --help`
- Copilot: attach [SKILL.md](run-unit-tests/SKILL.md) and request `run-unit-tests --help`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### rut

**What it does.** Forwards all arguments to [run-unit-tests](#run-unit-tests); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes rut as an alias for run-unit-tests.

**Parameters.** `[--target <dir>] [--fix] [--help]`.

**Examples.**

- Claude: `@skill rut --help`
- Codex: `@skill rut --help`
- Copilot: attach [SKILL.md](rut/SKILL.md) and request `rut --help`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

> Review pending — rerun with "review".

### status-report-create

**What it does.** Forwards all arguments to [report-status](#report-status); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes status-report-create as an alias for report-status.

**Parameters.** Optional `window YYYY-MM-DD..YYYY-MM-DD`.

**Examples.**

- Claude: `@skill status-report-create window 2026-10-06..2026-10-08`
- Codex: `@skill status-report-create window 2026-10-06..2026-10-08`
- Copilot: attach [SKILL.md](status-report-create/SKILL.md) and request `status-report-create window 2026-10-06..2026-10-08`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* Deriving `window_start` from the last report instead of "today" is the best design decision in the report pipeline — catch-up runs after missed schedules are automatically correct, and re-runs are idempotent. Boundary semantics (the 06:00 comparisons, same-day receipt placement) are written out to the half-open-interval level. "No receipts" produces a real report — an empty period is information. The don't-invent-work rule keeps reports honest.
- *Weaknesses:* Same hand-rolled Pacific timezone risk and ledger-header duplication as report-rollup. The receipt boundary rules are subtle enough that a weaker scheduled model could plausibly re-derive them wrong — they're specified in prose with no executable check. No model recommendation for what is a recurring, headless, cost-sensitive job.
- *Improvements:* Same shared helper as report-rollup (window math + ledger append, pytest-covered, planted violations per architecture-guards). Add "Sonnet-class" to the skill text. Cross-link work-receipt-create as the upstream producer so receipt-quality issues get fixed at the source.

### ugs-pcb-release

**What it does.** Forwards all arguments to [unreal-ugs-release](#unreal-ugs-release); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes ugs-pcb-release as an alias for unreal-ugs-release.

**Parameters.** Build profile and any explicitly authorized submit behavior.

**Examples.**

- Claude: `@skill ugs-pcb-release <task details>`
- Codex: `@skill ugs-pcb-release <task details>`
- Copilot: attach [SKILL.md](ugs-pcb-release/SKILL.md) and request `ugs-pcb-release <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* This is evidence-based operations at its best — the Validation Evidence list converts "it should be ready" into fifteen checkable facts (version, single BuildId, worker hashes, digest match, clean consumer launch). The wrong-archive-name trap (`main-content` stream producing a valid-looking zip at the wrong depot path) is documented twice because it's the expensive failure, and the troubleshooting boundaries stop scope creep ("post-launch tool crashes are separate investigations").
- *Weaknesses:* Hard-codes `D:\git\worky\...` for the runbook path — on the C: machine the very first instruction ("read this first") points at a file that isn't there. VisTest constants live inside a nominally general skill; the profile table mitigates but drift is one edit away. It's the longest skill in the set and mandates also reading the runbook, so every invocation pays a double token toll even for a narrow question. The skill↔runbook sync rule is enforced by discipline alone — the exact "rule in prose" failure mode architecture-guards exists to prevent.
- *Improvements:* Resolve the runbook as `<skill base dir>\..\..\runbooks\ugs-pcb\` (portable across both machines). Split deep troubleshooting into `references/troubleshooting.md`, loaded on demand — progressive disclosure would cut routine-invocation cost substantially. Move the VisTest profile into a small data block (or per-project file) so project onboarding is additive. Add a mechanical sync check between runbook and skill command shapes, even a crude one.

### unreal-reset-build-env

**What it does.** Documents process cleanup and build-shell environment reset on Windows. Execution requires the missing `Stop-UnrealBuildAndCleanEnv.ps1` helper; see the known gaps before invoking commands.

**When to use.** Use when Unreal Engine builds, UGS builds, UBT/UAT/Build.bat/RunUAT.bat/GenerateProjectFiles, UBA, MSBuild, or Visual Studio shell state must be stopped or cleaned before starting a fresh Unreal build on Windows.

**Parameters.** Helper flags including `-Root`, `-WhatIf`, and opt-in `-IncludeEditor`.

**Examples.**

- Claude: `@skill unreal-reset-build-env <task details>`
- Codex: `@skill unreal-reset-build-env <task details>`
- Copilot: attach [SKILL.md](unreal-reset-build-env/SKILL.md) and request `unreal-reset-build-env <task details>`.

**Architect's review.**

> Review pending — rerun with "review".

### unreal-ugs-release

**What it does.** Use when building, validating, submitting, troubleshooting, or updating UnrealGameSync UGS precompiled editor binaries, PCB archives, BuildGraph Submit To Perforce For UGS flows, no-submit validation, shader worker mismatches, or UGS archive runbooks.

**When to use.** Use when building, validating, submitting, troubleshooting, or updating UnrealGameSync UGS precompiled editor binaries, PCB archives, BuildGraph Submit To Perforce For UGS flows, no-submit validation, shader worker mismatches, or UGS archive runbooks.

**Parameters.** Build profile and any explicitly authorized submit behavior.

**Examples.**

- Claude: `@skill unreal-ugs-release <task details>`
- Codex: `@skill unreal-ugs-release <task details>`
- Copilot: attach [SKILL.md](unreal-ugs-release/SKILL.md) and request `unreal-ugs-release <task details>`.

**Architect's review.**

> Review pending — rerun with "review".

### update-claude-pricing-doc

**What it does.** Refreshes `output\claude-pricing.json` — the cached per-model USD rates that work-receipt-create prices sessions with — by invoking the `claude-api` skill and extracting `input`/`output` rates per model. Fixed JSON shape; cache multipliers (0.1× read, 1.25× write) live in a note and are derived inline by the consumer.

**When to use.** Use when the user asks to refresh or update Claude API pricing, or when claude-pricing.json is stale (>1 week old). WebFetches the official Anthropic pricing docs page, extracts only per-model token rates, and writes them to output/claude-pricing.json. Cheap and context-light; never invokes the claude-api skill.

**Parameters.** No arguments.

**Examples.**

- Claude: `@skill update-claude-pricing-doc <task details>`
- Codex: `@skill update-claude-pricing-doc <task details>`
- Copilot: attach [SKILL.md](update-claude-pricing-doc/SKILL.md) and request `update-claude-pricing-doc <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* Textbook token-cost engineering: caching seven numbers means every receipt skips loading the full claude-api reference bundle, and the explicit "use Haiku — needs no reasoning" line is the model-selection discipline more skills should copy. Tight output contract (exact JSON shape, exact confirmation line), and the staleness protocol pairs cleanly with the consumer's warning.
- *Weaknesses:* The "When to Run" section cites `Agent/skills/output/claude-pricing.json` — a path that doesn't exist (missing the `update-claude-pricing-doc` segment); a literal-minded model would conclude the file is always absent and refresh every time. Harness-locked by its data source: `claude-api` is a Claude Code bundled skill, so Codex/Copilot cannot execute this even though the file it maintains is harness-neutral. Refresh is purely pull-based — nothing schedules it.
- *Improvements:* Fix the path typo (one line). Add a documented fallback source (docs URL) so other harnesses can refresh the cache. Either add it to the scheduler or let work-receipt-create auto-run it when stale instead of just warning.

### update-skills-readme

**What it does.** Refreshes the categorized catalog, inventory, usage sections, and derived HTML. Preserves historical reviews unless `review` is requested. Uses explicit catalog checks when the optional renderer is absent.

**When to use.** Use when a skill under the canonical secret-agents/skills is added, removed, or edited, when the skills README.md or README.html is missing or stale, or when the user invokes /update-skills-readme (optionally with "review").

**Parameters.** Optional `review`.

**Examples.**

- Claude: `@skill update-skills-readme <task details>`
- Codex: `@skill update-skills-readme <task details>`
- Copilot: attach [SKILL.md](update-skills-readme/SKILL.md) and request `update-skills-readme <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* Separating mechanical regeneration (default) from judgment regeneration (`review`) matches cost to need — inventory updates run on a cheap model, reviews only pay for reasoning when asked. HTML is derived output from a committed script, not hand-maintained. The generation pipeline was exercised at creation time (this document is its output), so the HTML path is proven, not aspirational.
- *Weaknesses:* New and unproven beyond first generation. It's another manual sync rule — nothing *forces* a skill edit to trigger regeneration, so this README can silently drift stale (same class of problem as the ugs pair). Review preservation keys off the `**Architect's review.**` heading structure; a future format change breaks the preserve-vs-regenerate split.
- *Improvements:* Add a cheap freshness check a session can run (compare newest SKILL.md mtime against README generation date; warn on drift). Consider a repo guard per architecture-guards once the vault gains a test harness.

### work-receipt-create

**What it does.** Forwards all arguments to [report-receipt](#report-receipt); the canonical sibling owns the procedure.

**When to use.** Use when the user invokes work-receipt-create as an alias for report-receipt.

**Parameters.** Work details and optional verbatim text.

**Examples.**

- Claude: `@skill work-receipt-create <task details>`
- Codex: `@skill work-receipt-create <task details>`
- Copilot: attach [SKILL.md](work-receipt-create/SKILL.md) and request `work-receipt-create <task details>`.

**Architect's review.**

*Historical review preserved from the pre-migration catalog; statements about paths, wiring, or behavior may predate the current skill.*

- *Strengths:* The most harness-complete skill in the set — per-harness model recommendations *and* separate, semantically correct cost recipes for Claude (sum `.jsonl` usage fields, cache read 0.1×/write 1.25×) and Codex (cumulative `token_count` snapshots — never summed; quota ≠ dollars; no invented public rates). The coaching loop is the standout: each receipt grades the previous receipt's advice before issuing new advice, which is how coaching compounds instead of repeating. Output discipline ("the file is the deliverable") keeps chat cheap. Even the model-switching warning (cache invalidation can cost more than the pricier model) is correct and non-obvious.
- *Weaknesses:* The transcript read is the skill set's single largest hidden token sink — "parse each line as JSON" on a long session means pulling megabytes through the context window to sum four integers. No Copilot cost recipe (model recommendation only), so one leg of the tri-harness story is shorter than the other two. The instruction ordering (write prompts *before* reading the transcript, cost *after*) is subtle and easy for a rushed session to violate. Filename discipline exists because it was learned the hard way (the vault's `.md.md` cleanup) — good rule, but only prose enforces it.
- *Improvements:* Add `scripts/sum_usage.py` (stdlib-only, uv-run) that totals usage fields outside the context window and prints the four numbers — turns the biggest token cost in the vault into approximately zero. Add a Copilot cost stanza when a usage surface exists. When pricing is stale, auto-run update-claude-pricing-doc rather than only warning.


---

## Architect's overview

### Harness coverage matrix

| Surface | Migration verification |
|---|---|
| Skill files | YAML, names, categories, kinds, direct alias targets and catalog coverage checked locally. |
| Worky pointer | Links to canonical guidance and catalog; machine adapters remain unchanged. |
| Claude / Codex / Copilot discovery | Not inspected or installed in this phase. |
| Operational workflows | Not run; Perforce, Jira, Unreal, reporting inputs, and machine setup have external prerequisites. |

### Skill gaps

See the [complete known-gaps register](../runbooks/migration-gaps.md). `clean-code-error-handling` and `update-model-routing` have empty directories but no skill bodies, so they are not advertised as installed skills. Source and test directories are empty; the harness implementation described in the August plan was not present in either scoped vault.

### Token-costly mistakes

Read the skill needed for the task and its relevant references. Keep aliases thin, preserve the canonical workflow once, and use the categorized TOC to select it. Treat preserved historical reviews as dated recommendations, not current machine inspection. Detailed original catalog analyses remain in the [migration recovery archive](../docs/migrations/2026-10-13-worky-agent/README.md).

## Maintaining this document

Use `@skill update-skills-readme` after skill changes. Preserve existing review text unless `review` is requested. Verify that every actual skill has an inventory row, a TOC anchor, and one usage section; each alias must resolve directly. Render HTML from this Markdown and check local links/anchors. If the optional original renderer is absent, use the documented fallback in [the maintenance skill](update-skills-readme/SKILL.md).
