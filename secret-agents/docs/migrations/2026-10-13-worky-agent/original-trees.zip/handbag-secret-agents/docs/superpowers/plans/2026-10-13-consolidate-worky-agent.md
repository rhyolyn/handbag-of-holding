# Consolidate Worky Agent into Handbag of Holding

**Goal:** Make `handbag-of-holding/secret-agents` the canonical collection and remove `worky/Agent` after verifying every source file is accounted for.

**Scope:** Read and change only the two requested collections, plus the user-approved `worky/AGENTS.md` pointer. Machine adapters, other Worky consumers, templates, receipts, and repositories remain for phase two. Execute in this session; these folders are not Git checkouts.

**Design:** Preserve destination names and newer shared guidance. Merge Worky's unique Jira Epic instructions and Perforce annual-rollup workflow. Old names become thin forwarding skills. Every skill retains `name`/`description` and gains `metadata.category`/`metadata.kind`; aliases also carry `metadata.alias_of`. Keep one TOC entry per installed skill. Preserve both original trees in a checksummed, non-discoverable recovery archive before edits.

**Rejected alternatives:** Overwriting duplicates would lose newer work; leaving duplicate executable skills would create competing owners; deriving the reporting vault from the relocated skill would incorrectly write receipts into handbag-of-holding. Preserve Worky as the reporting data location through an explicit portable vault-resolution reference inside the migrated collection.

## Checklist

- [x] Inventory and compare both trees, including hidden files and empty directories. Claude: Sonnet-class; Codex: current session. Result: substantive changes identified; no source or test files exist in either scoped tree.
- [ ] Save original bytes and SHA-256 manifest; migrate unique docs and skills; merge semantic differences. Claude: Sonnet-class; Codex: current session. Verify every Worky file has a mapped canonical destination and an archived original.
- [ ] Normalize skill headers, aliases, TOC and internal locations; add Worky pointer and document missing dependencies. Claude: Sonnet-class; Codex: current session. Verify YAML, names, alias targets, TOC anchors and relocation-sensitive references.
- [ ] Run preservation and catalog checks, review results, remove exactly `C:\Users\rhyol\obsidian\worky\Agent`, and rerun checks. Claude: Sonnet-class; Codex: current session. Verify source tree absent and every manifest destination present.

## Review focus

- A source file modified during migration must stop deletion, not silently lose edits.
- Canonical rename aliases must resolve directly without chains or duplicated bodies.
- Report and Jira template paths must continue to resolve against the reporting vault.
- Archived originals and historical plans may retain old paths; current guidance must use the canonical collection.
- Missing code, scripts, templates, and empty skill shells must be recorded honestly; relocation is not evidence of runtime readiness.

## Evidence and decisions

The user approved the Worky root pointer and category/kind metadata on 2026-10-13. Detailed mappings, hashes, conflicts, known missing files, and final checks live in `docs/migrations/2026-10-13-worky-agent/`.
